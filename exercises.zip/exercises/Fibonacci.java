package coding.exercises;

/**
 * Created by 329877575 on 2018/09/10.
 */
public class Fibonacci {
    public static void main(String[] args) {
        int num = 10;
        long startTime = System.nanoTime();
        for (int i = 1; i <= num; i++) {
            System.out.print(fibonacci(i) + " ");
        }
        long endTime = System.nanoTime();
        System.out.println("Run Time: " + (endTime - startTime));
        long startTime2 = System.nanoTime();
        printFibo2(10);
        long endTime2 = System.nanoTime();
        System.out.println("Run Time: " + (endTime2 - startTime2));
    }

    private static void printFibo(int limit) {
        int temp = 0, temp2 = 0, temp3;
        while (temp <= limit) {
            if (temp == 0) {
                temp = temp + 1;
                System.out.print(temp + " ");
            } else {
                temp3 = temp + temp2;
                System.out.print(temp3 + " ");
                temp2 = temp;
                temp = temp3;
            }
        }
    }

    private static void printFibo2(int limit) {
        int temp = 0, temp2 = 0, temp3;
        for (int i = 0; i < limit; i++)
            if (temp == 0) {
                temp = temp + 1;
                System.out.print(temp + " ");
            } else {
                temp3 = temp + temp2;
                System.out.print(temp3 + " ");
                temp2 = temp;
                temp = temp3;
            }
    }

    public static int fibonacci(int number) {
        if (number == 1 || number == 2) {
            return 1;
        }
        return fibonacci(number - 1) + fibonacci(number - 2);
    }
}
