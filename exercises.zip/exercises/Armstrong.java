package coding.exercises;

/**
 * Created by 329877575 on 2018/09/10.
 */
public class Armstrong {
    public static void main(String[] args) {
        checkArmstrong(370);
    }

    private static void checkArmstrong(int number) {
        String num = String.valueOf(number);
        int sum = 0;
        for (int i = 0; i < num.length(); i++) {
            sum = sum + (int) Math.pow(Double.parseDouble(num.substring(i, i + 1)), 3);
            if (sum > number) {
                System.out.println("Number " + number + " is not an Armstrong number");
                return;
            }
        }
        if (sum == number) {
            System.out.println("Number " + number + " is an Armstrong number");
        } else {
            System.out.println("Number " + number + " is not an Armstrong number");
        }

    }
}
