package coding.exercises;

/**
 * Created by 329877575 on 2018/09/05.
 */
public class Jewels {

    public static void main(String[] args) {
        System.out.println(numJewelsInStones("aAz", "aAAbbbbAAzaaa"));
    }

    public static int numJewelsInStones(String J, String S) {
        int count = 0;
        for (int i = 0; i < J.length(); i++) {
            CharSequence cs = J.subSequence(i, i + 1);
            if (S.contains(cs)) {
                count = count + S.split(cs.toString(), -1).length-1;
            }
        }
        return count;
    }

}
