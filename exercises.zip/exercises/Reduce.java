package coding.exercises;

/**
 * Created by 329877575 on 2018/09/05.
 */
public class Reduce {
    public static void main(String[] args) {
        System.out.println(reduceToOne(1000000000));
    }

    public static int reduceToOne(int num) {
        int count = 0;
        while (num > 1) {
            if (checkIfOdd(num)) {
                num = num + 1;
                count++;
            }
            System.out.println(num + "/2=" + (num / 2));
            num = num / 2;
            count++;
        }
        return count;
    }

    private static boolean checkIfOdd(int num) {
        if (num % 2 == 0) {
            System.out.print(num + " Number is Even ");
            return false;
        } else {
            System.out.println(num + " Number is ODD " + num + "+1=" + (num + 1));
            return true;
        }
    }
}
