package coding.exercises;

/**
 * Created by 329877575 on 2018/09/10.
 */
public class Prime {
    public static void main(String[] args) {
        checkPrime(12);
        isPrime(12);
    }

    private static void checkPrime(int number) {
        int flag = 0;
        for (int i = 2; i <= number; i++) {
            if (number % i == 0 && i != number) {
                System.out.println("number " + number + " is not prime");
                return;
            }
        }
        System.out.println("number " + number + " is prime");

    }

    public static void isPrime(int number) {
        int sqrt = (int) Math.sqrt(number) + 1;
        for (int i = 2; i < sqrt; i++) {
            if (number % i == 0) { // number is perfectly divisible - no prime
                System.out.println("number " + number + " is not prime");
                return;
            }
        }
        System.out.println("number " + number + " is prime");
    }
}

