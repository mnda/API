package coding.exercises;

/**
 * Created by 329877575 on 2018/09/10.
 */
public class Palindrome {
    public static void main(String[] args) {
        checkPalindrome(String.valueOf(123));
    }

    private static void checkPalindrome(String word) {
        for (int i = 0; i < word.length() / 2; i++) {
            if (word.toLowerCase().charAt(i) != word.toLowerCase().charAt(word.length() - 1 - i)) {
                System.out.println("Word " + word + " is not a palindrome");
                return;
            }
        }
        System.out.println("Word " + word + " is a palindrome");
    }

}

