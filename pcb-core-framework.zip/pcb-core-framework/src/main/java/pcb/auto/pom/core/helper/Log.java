package pcb.auto.pom.core.helper;

/**
 * Created by angmark on 2/5/2018.
 */

import com.hp.lft.report.Reporter;
import com.hp.lft.report.Status;
import com.hp.lft.sdk.web.Page;
import com.hp.lft.sdk.winforms.Window;
import cucumber.api.Scenario;
import net.minidev.json.JSONObject;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.testng.Assert;
import pcb.auto.pom.core.alm.ALMConnector;

import java.awt.image.RenderedImage;
import java.text.Normalizer;

public class Log {
    private static Scenario logScenario;
    private static int stepCount = 0;
    private static String reportString = "";

// Initialize Log4j logs

    private static Logger Log = Logger.getLogger(pcb.auto.pom.core.helper.Log.class.getName());//

    // This is to print log for the beginning of the test case, as we usually run so many test cases as a test suite

    public static void startTestCase(Scenario scenario) {
        logScenario = scenario;
        reportString = "";
        stepCount = 0;
        info("****************************************************************************************");

        info("****************************************************************************************");

        info("SCENARIO: " + scenario.getName());

        info("****************************************************************************************");

        info("****************************************************************************************");
        stepCount = 1;
    }

    //This is to print log for the ending of the test case

    public static void endTestCase() {

        info("XXXXXXXXXXXXXXXXXXXXXXX             " + "-E---N---D-" + "             XXXXXXXXXXXXXXXXXXXXXX");
    }

    // Need to create these methods, so that they can be called

    public static void info(String message) {
        if (stepCount < 1) {
            reportString = reportString + "\n" + message;
            Log.info(message);
        } else {
            Log.info(message);
            try {
                Reporter.reportEvent("Step " + stepCount + ": " + message, message, Status.Passed);
                reportString = reportString + "\n" + "Step " + stepCount + ": " + message;
                insertStepToReport(logScenario, "Step " + stepCount + ": " + message);
                stepCount++;
            } catch (Exception e) {
            }
        }

    }

    public static void info(String message, Status status) {
        if (stepCount < 1) {
            reportString = reportString + "\n" + message;
            Log.info(message);
        } else {
            Log.info(message);
            try {
                Reporter.reportEvent("Step " + stepCount + ": " + message, message, status);
                reportString = reportString + "\n" + "Step " + stepCount + ": " + message;
                insertStepToReport(logScenario, "Step " + stepCount + ": " + message);
                stepCount++;
            } catch (Exception e) {
            }
        }
    }

    public static void info(String message, Status status, RenderedImage img) {
        if (stepCount < 1) {
            reportString = reportString + "\n" + message;
            Log.info(message);
        } else {
            reportString = reportString + "\n" + message;
            Log.info(message);
            try {
                Reporter.reportEvent("Step " + stepCount + ": " + message, message, status, img);
                reportString = reportString + "\n" + "Step " + stepCount + ": " + message;
                insertStepToReport(logScenario, "Step " + stepCount + ": " + message);
                logScenario.embed(ScreenshotHelperWeb.convertRenderedImageToByte(img), "image/png");
                stepCount++;
            } catch (Exception e) {
            }
        }
    }

    public static void nonStepInfo(String message, Status status) {
        if (stepCount < 1) {
            reportString = reportString + "\n" + message;
            Log.info(message);
        } else {
            Log.info(message);
            try {
                Reporter.reportEvent(message, message, status);
                reportString = reportString + "\n" + message;
                insertStepToReport(logScenario, message);
            } catch (Exception e) {
            }
        }
    }

    public static void nonStepInfo(String message) {
        if (stepCount < 1) {
            reportString = reportString + "\n" + message;
            Log.info(message);
        } else {
            Log.info(message);
            try {
                Reporter.reportEvent(message, message, Status.Passed);
                reportString = reportString + "\n" + message;
                insertStepToReport(logScenario, message);
            } catch (Exception e) {
            }
        }
    }

    public static void warn(String message) {
        Log.warn(message);
    }

    public static void error(String message) {
        reportString = reportString + "\n" + message;
        info(message, Status.Failed);
        Log.error("Error encountered, terminating run...");
        ScreenshotHelperWindows.takeScreenshot();
        Assert.fail();
        // System.exit(0);
    }

    public static void fatal(String message) {
        reportString = reportString + "\n" + message;
        Log.fatal(message);
    }

    public static void debug(String message) {
        try {
            if (System.getProperty("logDebug").contains("true")) {
                Log.debug(message);
            }
        } catch (Exception e) {
        }
    }

    public static void step(String message) {
        Log.info(message);
        stepCount++;
        try {
            //insertStepToReport(logScenario, "Step " + stepCount + ": " + message);
            insertStepToReport(logScenario, message);
        } catch (Exception e) {

        }
    }


    public static void takeScreenshot(Scenario scenario, Window window) {
        try {
            scenario.embed(ScreenshotHelperWindows.takeScreenshot(window), "image/png");
            PDFReport.writeImage();
        } catch (Exception e) {
            Log.error(ExceptionUtils.getStackTrace(e));
        }

    }

    public static void takeScreenshotWeb(Scenario scenario, Page page) throws Exception {
        scenario.embed(ScreenshotHelperWeb.takeScreenshot(page), "image/png");
        PDFReport.writeImage();
    }

    public static void takeScreenshotWeb(Scenario scenario, Page page, String imageName) throws Exception {
        scenario.embed(ScreenshotHelperWeb.takeScreenshot(page, imageName), "image/png");
        PDFReport.writeImage();
    }


    public static void takeScreenshotWindows(Scenario scenario) throws Exception {
        scenario.embed(ScreenshotHelperWindows.takeScreenshot(), "image/png");
        PDFReport.writeImage();
    }

    public static void takeScreenshotWindows(Scenario scenario, String imageName) throws Exception

    {
        scenario.embed(ScreenshotHelperWindows.takeScreenshot(imageName), "image/png");
        PDFReport.writeImage();
    }

    public static void insertXMLToReport(Scenario scenario, String content, String fileType) throws Exception {
        String temp = "<xmp>" + CoreFrameworkHelper.prettifyXML(content) + "</xmp>";
        byte[] b = temp.getBytes();
        scenario.embed(b, fileType);
    }

    public static void insertStringToReport(Scenario scenario, String content, String fileType) throws Exception {
        String temp = "<xmp>" + content + "</xmp>";
        byte[] b = temp.getBytes();
        scenario.embed(b, fileType);
    }

    public static void insertStepToReport(Scenario scenario, String content) throws Exception {
        scenario.write(content);
        PDFReport.writeText(content);
    }

    public static void reportStatus(String validationMessage, String expected, String actual) {
        if (expected.trim().equals(actual)) {
            validationMessage = "PASSED:" + validationMessage + "\n Expected:" + expected + "\n Actual:" + actual;
            info(validationMessage, Status.Passed);
        } else {
            validationMessage = "FAILED:" + validationMessage + "\n Expected:" + expected + "\n Actual:" + actual;
            info(validationMessage, Status.Failed);
        }
    }

    public static void logToALM(JSONObject jsonObject) {
        try {
            jsonObject.remove("comments");
            jsonObject.put("comments", stripFrenchAccentsFromString(reportString));
            jsonObject.put("commentsnormal", reportString);
            ALMConnector.recordRunInALM(jsonObject);
        } catch (Exception e) {
            Log.info("Failed to log results to ALM" + e.getMessage());
        }
    }

    public static String stripFrenchAccentsFromString(String string) {
        return Normalizer.normalize(string, Normalizer.Form.NFC).replaceAll("[^\\p{ASCII}]", "");
    }

    public static String returnCurrentReportString() {
        return reportString;
    }

}