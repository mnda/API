package pcb.auto.pom.core.helper;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.RenderedImage;
import java.awt.image.WritableRaster;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;


/**
 * Created by angmark on 1/5/2018.
 */
public class ScreenshotHelperWindows {


    public static void main(String[] args) {
        ScreenshotHelperWindows screenshotHelper = new ScreenshotHelperWindows();
        screenshotHelper.takeScreenshot();
    }


    public static BufferedImage convertRenderedImage(RenderedImage img) {
        if (img instanceof BufferedImage) {
            return (BufferedImage) img;
        }
        ColorModel cm = img.getColorModel();
        int width = img.getWidth();
        int height = img.getHeight();
        WritableRaster raster = cm
                .createCompatibleWritableRaster(width, height);
        boolean isAlphaPremultiplied = cm.isAlphaPremultiplied();
        Hashtable properties = new Hashtable();
        String[] keys = img.getPropertyNames();
        if (keys != null) {
            for (int i = 0; i < keys.length; i++) {
                properties.put(keys[i], img.getProperty(keys[i]));
            }
        }
        BufferedImage result = new BufferedImage(cm, raster,
                isAlphaPremultiplied, properties);
        img.copyData(raster);
        return result;
    }

    public static byte[] takeScreenshot() {
        String fileName = CoreFrameworkHelper.getValuesFromProperties("testsettings.properties", "temp_screenshot_folder") + "\\" + new SimpleDateFormat("yyyyMMddHHmmss'.png'").format(new Date());
        return takeScreenshotCore(fileName);
    }

    public static byte[] takeScreenshot(String fileName) {
        return takeScreenshotCore(fileName.replace(" ", "_"));
    }

    private static byte[] takeScreenshotCore(String fileName) {
        File outputFile = new File(fileName);
        File parentDir = outputFile.getParentFile();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        if (parentDir != null && !parentDir.exists()) {
            if (!parentDir.mkdirs()) {
                Log.error("Error creating directories");
            }
        }

        try {
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Rectangle screenRectangle = new Rectangle(screenSize);
            Robot robot = new Robot();
            BufferedImage image = getScaledInstance(robot.createScreenCapture(screenRectangle), true);
            ImageIO.write(image, "png", baos);
            ImageIO.write(image, "png", outputFile);
            System.out.println("screenshot taken and saved temporarily to " + fileName);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return baos.toByteArray();
    }


    public static byte[] takeScreenshot(com.hp.lft.sdk.winforms.Window window) throws Exception {
        RenderedImage renderimage = window.getSnapshot();
        BufferedImage image = getScaledInstance(convertRenderedImage(renderimage), true);
        //BufferedImage image = convertRenderedImage(renderimage);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(image, "png", baos);
        return baos.toByteArray();
    }


    public static void deleteTempScreenshotFolder() {
        File index = new File(System.getProperty("java.io.tmpdir") + "/leanfttemp/");
        String[] entries = index.list();
        for (String s : entries) {
            File currentFile = new File(index.getPath(), s);
            currentFile.delete();
        }
        index.delete();
    }


    private static BufferedImage resizeImage(BufferedImage originalImage, int type) {
        Double imageWidthHalf = originalImage.getWidth() * .5;
        Double imageHeightHalf = originalImage.getHeight() * .5;
        BufferedImage resizedImage = new BufferedImage(imageWidthHalf.intValue(), imageHeightHalf.intValue(), type);
        Graphics2D g = resizedImage.createGraphics();
        g.drawImage(originalImage, 0, 0, imageWidthHalf.intValue(), imageHeightHalf.intValue(), null);
        g.dispose();

        return resizedImage;
    }


    private static BufferedImage resizeImageWithHint(BufferedImage originalImage, int type) {
        Double imageWidthHalf = originalImage.getWidth() * .5;
        Double imageHeightHalf = originalImage.getHeight() * .5;
        BufferedImage resizedImage = new BufferedImage(imageWidthHalf.intValue(), imageHeightHalf.intValue(), type);
        Graphics2D g = resizedImage.createGraphics();
        g.drawImage(originalImage, 0, 0, imageWidthHalf.intValue(), imageHeightHalf.intValue(), null);
        g.dispose();
        g.setComposite(AlphaComposite.Src);

        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.setRenderingHint(RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY);
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        return resizedImage;
    }


    private static BufferedImage getScaledInstance(BufferedImage img, boolean higherQuality) {
        Double imageWidthHalf = img.getWidth() * .7;
        Double imageHeightHalf = img.getHeight() * .7;
        int targetWidth = imageWidthHalf.intValue();
        int targetHeight = imageHeightHalf.intValue();
        int type = (img.getTransparency() == Transparency.OPAQUE) ?
                BufferedImage.TYPE_INT_RGB : BufferedImage.TYPE_INT_ARGB;
        BufferedImage ret = (BufferedImage) img;
        int w, h;
        if (higherQuality) {
            // Use multi-step technique: start with original size, then
            // scale down in multiple passes with drawImage()
            // until the target size is reached
            w = img.getWidth();
            h = img.getHeight();
        } else {
            // Use one-step technique: scale directly from original
            // size to target size with a single drawImage() call
            w = targetWidth;
            h = targetHeight;
        }

        do {
            if (higherQuality && w > targetWidth) {
                w /= 2;
                if (w < targetWidth) {
                    w = targetWidth;
                }
            }

            if (higherQuality && h > targetHeight) {
                h /= 2;
                if (h < targetHeight) {
                    h = targetHeight;
                }
            }

            BufferedImage tmp = new BufferedImage(w, h, type);
            Graphics2D g2 = tmp.createGraphics();
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2.drawImage(ret, 0, 0, w, h, null);
            g2.dispose();

            ret = tmp;
        } while (w != targetWidth || h != targetHeight);

        return ret;
    }

}
