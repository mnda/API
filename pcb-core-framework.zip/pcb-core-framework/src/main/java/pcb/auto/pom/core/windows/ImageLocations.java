package pcb.auto.pom.core.windows;

/**
 * Created by angmark on 6/6/2017.
 */
public class ImageLocations {
    public static final String ABOVE = "above";
    public static final String BELOW = "below";
    public static final String LEFT = "left";
    public static final String RIGHT = "right";
    public static final String SURROUND = "surround";
    public static final String ORIGINAL = "original";

    public ImageLocations() {

    }
}
