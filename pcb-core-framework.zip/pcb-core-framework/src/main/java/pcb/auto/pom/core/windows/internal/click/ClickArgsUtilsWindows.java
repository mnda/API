package pcb.auto.pom.core.windows.internal.click;

import com.hp.lft.sdk.ClickArgs;
import com.hp.lft.sdk.Location;
import com.hp.lft.sdk.MouseButton;
import com.hp.lft.sdk.Position;

import java.awt.*;

/**
 * Created by angmark on 1/9/2018.
 */
public class ClickArgsUtilsWindows {


    public static ClickArgs offSetClick(int x, int y) {
        Point point = new Point(x, y);
        Location location = new Location(Position.CENTER, point);
        ClickArgs clickArgs = new ClickArgs(MouseButton.LEFT, location);
        return clickArgs;
    }

    public static ClickArgs offSetClick(int x, int y, String mouseButton) {
        Point point = new Point(x, y);
        Location location = new Location(Position.CENTER, point);
        ClickArgs clickArgs = new ClickArgs();
        switch (mouseButton.toLowerCase()) {
            case "left":
                clickArgs = new com.hp.lft.sdk.ClickArgs(MouseButton.LEFT, location);
                break;
            case "right":
                clickArgs = new com.hp.lft.sdk.ClickArgs(MouseButton.RIGHT, location);
                break;
            case "middle":
                clickArgs = new com.hp.lft.sdk.ClickArgs(MouseButton.MIDDLE, location);
                break;
            default:
                clickArgs = new com.hp.lft.sdk.ClickArgs(MouseButton.MIDDLE, location);
        }

        return clickArgs;
    }
}
