package pcb.auto.pom.core.web;

import com.hp.lft.sdk.web.Page;

/**
 * Created by angmark on 6/5/2017.
 */
public abstract class AbstractPageWeb {
    protected AbstractPageWeb() {
    }

    protected static Page mainPage;

    protected void waitUntilVisible() {
    }

}
