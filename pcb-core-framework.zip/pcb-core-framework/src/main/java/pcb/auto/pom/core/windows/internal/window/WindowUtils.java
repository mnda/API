package pcb.auto.pom.core.windows.internal.window;


import pcb.auto.pom.core.helper.Log;

/**
 * Created by angmark on 12/5/2017.
 */
public class WindowUtils {

    public static void maximizeWindow(com.hp.lft.sdk.winforms.Window window) throws Exception {
        if (window.exists(5)) {
            window.activate();
            window.move(0, 0);
            if (window.isMaximizable()) {
                Log.debug("Maximizing window");
                window.maximize();
            }
        }
    }

    public static void maximizeWindow(com.hp.lft.sdk.winforms.Window window, int w, int h) throws Exception {
        if (window.exists(5)) {
            window.activate();
            window.move(0, 0);
            if (window.isMaximizable()) {
                Log.debug("Maximizing window");
                window.maximize();
                window.resize(h, w);
            }
        }
    }

    public static void minimizeWindow(com.hp.lft.sdk.winforms.Window window) throws Exception {
        if (window.exists(5) && window.isMinimizable()) {
            Log.debug("Minimizing window");
            window.activate();
            window.minimize();
        }
    }
}

