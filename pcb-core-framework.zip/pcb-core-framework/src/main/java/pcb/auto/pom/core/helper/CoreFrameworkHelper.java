package pcb.auto.pom.core.helper;

import com.hp.lft.sdk.winforms.Window;
import cucumber.api.Scenario;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.sikuli.script.App;
import org.sikuli.script.Key;
import org.sikuli.script.KeyModifier;
import org.sikuli.script.Region;
import org.w3c.dom.Node;
import org.w3c.dom.bootstrap.DOMImplementationRegistry;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSSerializer;
import org.xml.sax.InputSource;
import pcb.auto.pom.core.windows.internal.click.ClickWindows;

import javax.xml.parsers.DocumentBuilderFactory;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by angmark on 11/16/2017.
 */
public class CoreFrameworkHelper {


    public static boolean regexChecker(String regex, String input) {
        boolean flag = false;
        Pattern pattern = Pattern.compile(regex);

        Matcher matcher = pattern.matcher(input);

        boolean isMatched = matcher.matches();

        if (isMatched) {
            flag = true;
        }
        //Log.debug(String.valueOf(flag).toUpperCase() + " - Checking if input: " + input + " passes regex: " + regex);
        return flag;
    }


    public static void typeString(Window window, String value) throws Throwable {
        String[] charArray = value.split("");
        for (int i = 0; i < charArray.length; i++) {
            window.sendKeys(charArray[i]);
        }
    }

    public static String getFeatureFileNameFromScenarioId(Scenario scenario) {
        String rawFeatureName = scenario.getId().split(";")[0].replace("-", "_").toUpperCase();
        return rawFeatureName;
    }

    public static boolean checkString(String value) {
        if (value.toLowerCase().contains("i-") || value.toLowerCase().contains("_") || value.length() > 10) {
            return true;
        } else {
            return false;
        }

    }

    public static void highlightRectangle(String windowDesc, Rectangle rect) {
        App app = App.focus(windowDesc);
        app.focus();
        Region region = app.window();
        region.setRect(rect);
        region.highlight(1);
        region.highlight(3);
    }

    public static void highlightRectangle(Window window, Rectangle rect) throws Exception {
        Log.debug("Highlighting rectangle area of rectangle with points " + rect);
        App app = App.focus(window.getWindowTitleRegExp());
        Region region = app.window();
        region.setRect(rect);
        region.highlight(1);
    }

    private static String getClipboardValue() throws Exception {
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Clipboard clipboard = toolkit.getSystemClipboard();
        String result = (String) clipboard.getData(DataFlavor.stringFlavor);
        return result;
    }


    private static void copyValueToClipboard(Window window) throws Exception {
        StringSelection stringSelection = new StringSelection("");
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(
                stringSelection, null);
        Log.debug("Clearing clipboard... value is now " + getClipboardValue());
        App app = App.focus(window.getWindowTitleRegExp());
        Region region = app.window();
        Toolkit.getDefaultToolkit().setLockingKeyState(KeyEvent.VK_NUM_LOCK, false);
        region.type(Key.END);
        region.type(Key.HOME, KeyModifier.SHIFT);
        region.type("C", Key.CTRL);
    }

    public static String getFieldValueToClipBoard(Window window, String text, Rectangle rect, int x, int y) throws Throwable {
        Log.debug("Copying value of " + text + " field to the clipboard");
        ClickWindows.clickUsingTextSikuli(window, text, x, y, rect);
        CoreFrameworkHelper.copyValueToClipboard(window);
        String value = CoreFrameworkHelper.getClipboardValue().trim();
        Log.debug("Clipboard contains " + value);
        return value;
    }

    public static String prettifyXML(String xml) {

        try {
            final InputSource src = new InputSource(new StringReader(xml));
            final Node document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(src).getDocumentElement();
            final Boolean keepDeclaration = Boolean.valueOf(xml.startsWith("<?xml"));

            //May need this: System.setProperty(DOMImplementationRegistry.PROPERTY,"com.sun.org.apache.xerces.internal.dom.DOMImplementationSourceImpl");


            final DOMImplementationRegistry registry = DOMImplementationRegistry.newInstance();
            final DOMImplementationLS impl = (DOMImplementationLS) registry.getDOMImplementation("LS");
            final LSSerializer writer = impl.createLSSerializer();

            writer.getDomConfig().setParameter("format-pretty-print", Boolean.TRUE); // SetWeb this to true if the output needs to be beautified.
            writer.getDomConfig().setParameter("xml-declaration", keepDeclaration); // SetWeb this to true if the declaration is needed to be outputted.

            return writer.writeToString(document);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public Boolean checkIfStringExists(Window window, String value, Rectangle rect) throws Exception {
        Log.debug("Looking for text " + value + " in the window");
        boolean found = true;
        App app = App.focus(window.getWindowTitleRegExp());
        app.focus();
        Region region = app.window();
        region.setRect(rect);
        try {
            region.findText(value).click();
            found = true;
        } catch (Exception e) {
            Log.debug("Cannot find text using sikuli, switching to LeanFT");
            Rectangle[] r = window.getTextLocations(value, rect);
            if (r != null) {
                found = false;
            } else {
                found = true;
            }
        }

        return found;
    }

    public static String getValuesFromProperties(String propFileName, String propertyName) {
        Properties prop = new Properties();
        InputStream inputStream = CoreFrameworkHelper.class.getClassLoader().getResourceAsStream(propFileName);
        try {
            if (inputStream != null) {
                prop.load(inputStream);
                String propValue = prop.getProperty(propertyName);
                Log.debug("Returning property value for property " + propertyName + ": " + propValue);
                return propValue;
            } else {
                throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
            }
        } catch (Exception e) {
            return "property file '" + propFileName + "' not found in the classpath";
        }
    }

    public static String checkTestTag() {
        try {
            String tag = System.getProperty("testTag").trim();
            return tag;
        } catch (Exception e) {
            Log.error("No testTag was defined in maven parameter");
            return null;
        }
    }

    public static void clearTempFolder() throws Exception {
        Logger.getRootLogger().setLevel(Level.INFO);
        File directory = new File(CoreFrameworkHelper.getValuesFromProperties("testsettings.properties", "temp_screenshot_folder"));
        if (directory != null && !directory.exists()) {
            Log.debug("Creating " + directory + " directory");
            if (!directory.mkdirs()) {
                Log.error("Error creating directories");
            }
        }
        Logger.getRootLogger().setLevel(Level.DEBUG);
        Log.debug("Clearing files inside " + directory + " directory");
        FileUtils.cleanDirectory(directory);
    }

    public static void clearTempFolderExcept(String fileExtension) {
        Logger.getRootLogger().setLevel(Level.INFO);
        File file = new File(CoreFrameworkHelper.getValuesFromProperties("testsettings.properties", "temp_screenshot_folder"));
        if (file.isDirectory())
            for (File f : file.listFiles())
                if (!f.getName().toLowerCase().contains(fileExtension.toLowerCase())) {
                    clearTempFolderExcept(fileExtension);
                } else
                    file.delete();

        Logger.getRootLogger().setLevel(Level.DEBUG);
    }


    public static void copyFile(String source, String destination) throws Exception {
        File src = new File(source);
        File dest = new File(destination);

        FileUtils.copyFile(src, dest);
    }

    public static String getJenkinsItemName(String jobName) {
        String[] arJobName = jobName.split(",", -1)[0].split("/");
        if (arJobName[arJobName.length - 1].contains("alm")) {
            jobName = arJobName[arJobName.length - 2];
        } else {
            jobName = arJobName[arJobName.length - 1];
        }
        Log.debug("Jenkins Node Name: " + jobName);
        return jobName;
    }

    public static java.util.List<java.util.List<String>> getTableData(java.util.List<java.util.List<String>> columns) throws Exception {
        //Check if the table sent is supposed to get it from CSV if not, return the same table
        if (!(columns.size() > 1)) {
            String id = columns.get(0).get(0);
            String fileName = columns.get(0).get(1);

            java.util.List<java.util.List<String>> tempCols = new LinkedList<java.util.List<String>>();
            ArrayList<String> colList = new ArrayList<>();
            ArrayList<String> retList = new ArrayList<>();
            //getting the columns
            for (int i = 2; i < columns.get(0).size(); i++) {
                colList.add(columns.get(0).get(i));
                retList.add(columns.get(0).get(i));
            }
            colList.add("ALMTestSetID");
            colList.add("ALMTestID");
            tempCols.add(colList);

            Scanner scanner = new Scanner(new File(fileName));
            int counter = 0;

            String[] arCSVColumns = new String[100];
            ArrayList<String> rowList = new ArrayList<>();
            while (scanner.hasNextLine()) {
                String rowValues = scanner.nextLine();
                if (counter == 0) {
                    arCSVColumns = rowValues.toLowerCase().split(",", -1);
                    counter++;
                }
                if (rowValues.toLowerCase().trim().contains(id.trim().toLowerCase()) && counter > 0) {
                    String[] arCSVValues = rowValues.split(",", -1);
                    for (int i = 0; i < tempCols.get(0).size(); i++) {
                        try {
                            //Add almtestset and almtestid one time
                            if (tempCols.get(0).get(i).toLowerCase().equals("almtestsetid")) {
                                try {
                                    if (System.getProperty("almTestSetID").equals("")) {
                                        System.setProperty("almTestSetID", String.valueOf(arCSVValues[Arrays.asList(arCSVColumns).indexOf(tempCols.get(0).get(i).toLowerCase())]));
                                    }
                                } catch (Exception e) {
                                    System.setProperty("almTestSetID", String.valueOf(arCSVValues[Arrays.asList(arCSVColumns).indexOf(tempCols.get(0).get(i).toLowerCase())]));
                                }
                            } else if (tempCols.get(0).get(i).toLowerCase().equals("almtestid")) {
                                try {
                                    if (System.getProperty("almTestID").equals("")) {
                                        System.setProperty("almTestID", String.valueOf(arCSVValues[Arrays.asList(arCSVColumns).indexOf(tempCols.get(0).get(i).toLowerCase())]));
                                    }
                                } catch (Exception e) {
                                    System.setProperty("almTestID", String.valueOf(arCSVValues[Arrays.asList(arCSVColumns).indexOf(tempCols.get(0).get(i).toLowerCase())]));
                                }
                            } else {
                                rowList.add(String.valueOf(arCSVValues[Arrays.asList(arCSVColumns).indexOf(tempCols.get(0).get(i).toLowerCase())]));
                            }
                        } catch (Exception e) {
                            Log.error("Cannot find " + tempCols.get(0).get(i).toLowerCase() + " column from CSV file " + fileName);
                        }
                    }
                    break;
                }
            }
            scanner.close();
            //Remove alm cols
            tempCols.remove(0);
            tempCols.add(retList);
            tempCols.add(rowList);
            Log.debug("Data " + tempCols + " was found for testCaseID " + id);
            return tempCols;
        } else {
            if (columns.get(0).toString().toLowerCase().contains("almtest")) {
                java.util.List<java.util.List<String>> tempCols = new LinkedList<java.util.List<String>>();
                ArrayList<String> colList = new ArrayList<>();
                ArrayList<String> valList = new ArrayList<>();
                //ensure last two columns are not added when ALM columns are there
                for (int i = 2; i < columns.get(0).size(); i++) {
                    colList.add(columns.get(0).get(i));
                    valList.add(columns.get(1).get(i));
                }
                int size = columns.get(1).size();
                System.setProperty("almTestSetID", columns.get(1).get(0));
                System.setProperty("almTestID", columns.get(1).get(1));
                tempCols.add(colList);
                tempCols.add(valList);
                return tempCols;
            } else {
                return columns;
            }

        }
    }

}
