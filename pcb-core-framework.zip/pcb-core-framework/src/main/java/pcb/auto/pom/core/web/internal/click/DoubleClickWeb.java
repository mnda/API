package pcb.auto.pom.core.web.internal.click;

/**
 * Created by angmark on 12/5/2017.
 */
public class DoubleClickWeb {

}