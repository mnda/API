package pcb.auto.pom.core.web;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.Page;
import pcb.auto.pom.core.helper.SyncHelperWeb;

/**
 * Created by angmark on 6/5/2017.
 */
public abstract class AbstractChunkWeb {

    protected AbstractChunkWeb(Page page) {
        SyncHelperWeb.waitForPageToAppear(page);
    }

    protected void waitUntilVisible() throws GeneralLeanFtException {

    }

}
