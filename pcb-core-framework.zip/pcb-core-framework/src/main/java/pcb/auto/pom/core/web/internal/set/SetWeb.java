package pcb.auto.pom.core.web.internal.set;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.CheckBox;
import com.hp.lft.sdk.web.EditField;
import com.hp.lft.sdk.web.ListBox;
import com.hp.lft.sdk.web.RadioGroup;
import pcb.auto.pom.core.helper.Log;

/**
 * Created by angmark on 12/5/2017.
 */
public class SetWeb {

    public static void set(EditField editField, String value) throws GeneralLeanFtException {
        Log.info("Set " + editField.getName() + " edit field to " + value);
        editField.setValue(value);
    }

    public static void set(RadioGroup radioGroup, String value) throws GeneralLeanFtException {
        Log.info("Set " + radioGroup.getName() + " radio group field to " + value);
        radioGroup.select(value);
    }

    public static void set(RadioGroup radioGroup, int index) throws GeneralLeanFtException {
        Log.info("Set " + radioGroup.getName() + " radio group field to index " + index);
        radioGroup.select(index);
    }


    public static void setPassword(EditField editField, String value) throws GeneralLeanFtException {
        Log.info("Set " + editField.getName() + " password edit field");
        editField.setValue(value);
    }

    public static void set(ListBox listBox, int index) throws GeneralLeanFtException {
        Log.info("Set " + listBox.getName() + " list box field to index " + index);
        listBox.select(index);
    }


    public static void set(ListBox listBox, String value) throws GeneralLeanFtException {
        Log.info("Set " + listBox.getName() + " list box field to " + value);
        listBox.select(value);
    }


    public static void set(CheckBox checkBox, String bool) throws GeneralLeanFtException {
        if (bool.equals("true") || bool.equals("false")) {
            boolean bl = Boolean.parseBoolean(bool);
            if (checkBox.isEnabled()) {
                Log.info("Set " + checkBox.getName() + " check box field to " + String.valueOf(bool));
                checkBox.set(bl);
            } else {
                Log.debug("Set " + checkBox.getName() + " check box field to " + String.valueOf(bool) + " was not successful as object is disabled");
            }
        }
    }


}

