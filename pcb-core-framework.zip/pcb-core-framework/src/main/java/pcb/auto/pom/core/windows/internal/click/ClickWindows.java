package pcb.auto.pom.core.windows.internal.click;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.Mouse;
import com.hp.lft.sdk.MouseButton;
import com.hp.lft.sdk.winforms.Window;
import org.sikuli.basics.Settings;
import org.sikuli.script.App;
import org.sikuli.script.Region;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWindows;
import pcb.auto.pom.core.windows.CoreFrameworkWindows;
import pcb.auto.pom.core.windows.TextIdAutomationObject;

import java.awt.*;

/**
 * Created by angmark on 12/5/2017.
 */
public class ClickWindows {
    private static int clickGlobalWait = 10000;

    static Settings settings;


    public static void click(com.hp.lft.sdk.stdwin.Button button) throws GeneralLeanFtException {
        Log.info("Clicking " + button.getText().trim() + " button");
        button.click();
    }


    //******************* OLD FUNCTIONS ****************************//
    public static void clickUsingText(Window window, String text) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Rectangle[] r = SyncHelperWindows.waitForTextToBePresent(window, text, clickGlobalWait);
        if (r != null) {
            int xCoord = window.getAbsoluteLocation().x + r[0].x + 10;
            int yCoord = window.getAbsoluteLocation().y + r[0].y + 10;
            Log.step("Clicking text " + text);
            Log.debug("Clicking text " + text + " in the window coordinates x:" + xCoord + " y:" + yCoord);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.click(new Point(xCoord, yCoord));
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }

    public static void clickUsingText(Window window, String text, MouseButton mouseButton) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Rectangle[] r = SyncHelperWindows.waitForTextToBePresent(window, text, clickGlobalWait);
        if (r != null) {
            int xCoord = window.getAbsoluteLocation().x + r[0].x + 10;
            int yCoord = window.getAbsoluteLocation().y + r[0].y + 10;
            Log.step("Clicking text " + text);
            Log.debug("Clicking text " + text + " in the window coordinates x:" + xCoord + " y:" + yCoord);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.click(new Point(xCoord, yCoord), mouseButton);
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }

    public static void clickUsingText(Window window, String text, int offsetX, int offsetY) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Rectangle[] r = SyncHelperWindows.waitForTextToBePresent(window, text, clickGlobalWait);
        if (r != null) {
            int xCoord = window.getAbsoluteLocation().x + r[0].x + 10 + offsetX;
            int yCoord = window.getAbsoluteLocation().y + r[0].y + 10 + offsetY;
            Log.step("Clicking text " + text);
            Log.debug("Clicking text " + text + " with offset in the window coordinates x:" + xCoord + " y:" + yCoord);
            Rectangle rect = new Rectangle(xCoord, yCoord, 50, 50);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.click(new Point(xCoord, yCoord));
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }

    public static void clickUsingText(Window window, String text, int offsetX, int offsetY, MouseButton mouseButton) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Rectangle[] r = SyncHelperWindows.waitForTextToBePresent(window, text, clickGlobalWait);

        if (r != null) {
            int xCoord = window.getAbsoluteLocation().x + r[0].x + 10 + offsetX;
            int yCoord = window.getAbsoluteLocation().y + r[0].y + 10 + offsetY;
            Log.step("Clicking text " + text);
            Log.debug("Clicking text " + text + " with offset in the window coordinates x:" + xCoord + " y:" + yCoord);
            Rectangle rect = new Rectangle(xCoord, yCoord, 50, 50);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.click(new Point(xCoord, yCoord), mouseButton);
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }

    public static void clickUsingText(Window window, String text, int offsetX, int offsetY, Rectangle rect) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Double rectX = rect.getX();
        Double rectY = rect.getY();
        Rectangle[] r = SyncHelperWindows.waitForTextToBePresent(window, text, rect);
        if (r != null) {
            int xCoord = window.getAbsoluteLocation().x + (r[0].x + rectX.intValue()) + 10 + offsetX;
            int yCoord = window.getAbsoluteLocation().y + (r[0].y + rectY.intValue()) + 10 + offsetY;
            Log.step("Clicking text " + text);
            Log.debug("Clicking text " + text + " with offset in the window coordinates x:" + xCoord + " y:" + yCoord);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.doubleClick(new Point(xCoord, yCoord));
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }


    public static void clickUsingTextSikuli(Window window, String text, int offsetX, int offsetY, Rectangle rect) throws Throwable {
//        settings.OcrTextRead = true; // to switch on the Region.text() function
//        settings.OcrTextSearch = true;
//        settings.ActionLogs = false;

        Log.info("Looking for text " + text + " in the window");

        App app = App.focus(window.getWindowTitleRegExp());
        app.focus();
        Region region = app.window();
        region.setRect(rect);
        Log.debug("Clicking " + text + " in the window if it exists");
        try {
            region.findText(text).offset(offsetX, offsetY).click();
            Log.step("Clicked " + text + " in the window using Sikuli");
            //region.click();
            //region.offset(offsetX, offsetY).click(text);
        } catch (Exception e) {
            Log.debug("Cannot find text using sikuli, switching to LeanFT");
            clickUsingText(window, text, offsetX, offsetY);
        }
    }

    public static void clickUsingTextSikuli(Window window, String text, int offsetX, int offsetY, Rectangle rect, MouseButton mouseButton) throws Throwable {
//        settings.OcrTextRead = true; // to switch on the Region.text() function
//        settings.OcrTextSearch = true;
//        settings.ActionLogs = false;

        Log.info("Looking for text " + text + " in the window");

        App app = App.focus(window.getWindowTitleRegExp());
        app.focus();
        Region region = app.window();
        region.setRect(rect);
        Log.debug("Clicking " + text + " in the window if it exists");
        try {
            region.findText(text).offset(offsetX, offsetY).click(mouseButton);
            Log.step("Clicked " + text + " in the window using Sikuli");
            //region.click();
            //region.offset(offsetX, offsetY).click(text);
        } catch (Exception e) {
            Log.debug("Cannot find text using sikuli, switching to LeanFT");
            clickUsingText(window, text, offsetX, offsetY, mouseButton);
        }
    }

    public static void clickUsingText(Window window, String text, int offsetX, int offsetY, Rectangle rect, MouseButton mouseButton) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Double rectX = rect.getX();
        Double rectY = rect.getY();
        Rectangle[] r = SyncHelperWindows.waitForTextToBePresent(window, text, rect);
        if (r != null) {
            int xCoord = window.getAbsoluteLocation().x + (r[0].x + rectX.intValue()) + 10 + offsetX;
            int yCoord = window.getAbsoluteLocation().y + (r[0].y + rectY.intValue()) + 10 + offsetY;
            Log.step("Clicking text " + text);
            Log.debug("Clicking text " + text + " with offset in the window coordinates x:" + xCoord + " y:" + yCoord);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.doubleClick(new Point(xCoord, yCoord), mouseButton);
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }


    public static void clickText(Window window, String text, int offsetX, int offsetY, Rectangle[] rect, Rectangle rArea) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Double rectX = rArea.getX();
        Double rectY = rArea.getY();
        if (rect != null) {
            int xCoord = window.getAbsoluteLocation().x + rect[0].x + rectX.intValue() + 10 + offsetX;
            int yCoord = window.getAbsoluteLocation().y + rect[0].y + rectY.intValue() + offsetY;
            Log.step("Clicking text " + text);
            Log.debug("Clicking text " + text + " with offset and rectangle in the window coordinates x:" + xCoord + " y:" + yCoord);
            Rectangle rect2 = new Rectangle(xCoord, yCoord, 50, 50);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.click(new Point(xCoord, yCoord));
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }

    public static void clickText(Window window, String text, int offsetX, int offsetY, Rectangle[] rect, Rectangle rArea, MouseButton mouseButton) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Double rectX = rArea.getX();
        Double rectY = rArea.getY();
        if (rect != null) {
            int xCoord = window.getAbsoluteLocation().x + rect[0].x + rectX.intValue() + 10 + offsetX;
            int yCoord = window.getAbsoluteLocation().y + rect[0].y + rectY.intValue() + offsetY;
            Log.step("Clicking text " + text);
            Log.debug("Clicking text " + text + " with offset and rectangle in the window coordinates x:" + xCoord + " y:" + yCoord);
            Rectangle rect2 = new Rectangle(xCoord, yCoord, 50, 50);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.click(new Point(xCoord, yCoord), mouseButton);
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }

    public static void clickTIAO(Window window, TextIdAutomationObject[] textIdAutomationObject) throws Throwable {
        Log.step("Clicking text " + textIdAutomationObject[0].getID());
        try {
            //defaults to tst
            if (System.getProperty("testMachine").toLowerCase().equals("vm")) {
                try {
                    Log.debug("Insight object failed, trying with text id automation object");
                    clickUsingTextSikuli(window, textIdAutomationObject[0].getID(), 0, 0, textIdAutomationObject[1].getRectangle());
                } catch (Exception e) {
                    Log.debug("Trying with insight object first");
                    Log.step("Clicking text " + textIdAutomationObject[0].getID());
                    textIdAutomationObject[2].getInsightObject().click();
                }
            } else {
                try {
                    Log.debug("Trying with insight object first");
                    Log.step("Clicking text " + textIdAutomationObject[0].getID());
                    textIdAutomationObject[2].getInsightObject().click();
                } catch (Exception e) {
                    Log.debug("Insight object failed, trying with text id automation object");
                    clickUsingTextSikuli(window, textIdAutomationObject[0].getID(), 0, 0, textIdAutomationObject[1].getRectangle());
                }
            }
        } catch (Exception e) {
            try {
                Log.debug("Trying with insight object first");
                Log.step("Clicking text " + textIdAutomationObject[0].getID());
                textIdAutomationObject[2].getInsightObject().click();
            } catch (Exception x) {
                Log.debug("Insight object failed, trying with text id automation object");
                clickUsingTextSikuli(window, textIdAutomationObject[0].getID(), 0, 0, textIdAutomationObject[1].getRectangle());
            }
        }
    }

    public static void clickTIAO(Window window, TextIdAutomationObject[] textIdAutomationObject, int x, int y) throws Throwable {
        try {
            //defaults to tst
            if (System.getProperty("testMachine").toLowerCase().equals("vm")) {
                try {
                    Log.debug("Trying with text id automation object");
                    clickUsingTextSikuli(window, textIdAutomationObject[0].getID(), x, y, textIdAutomationObject[1].getRectangle());
                } catch (Exception e) {
                    Log.debug("Text Id failed, Trying with insight object first");
                    Log.step("Clicking text " + textIdAutomationObject[0].getID());
                    textIdAutomationObject[2].getInsightObject().click();
                }
            } else {
                try {
                    Log.debug("Trying with insight object first");
                    Log.step("Clicking text " + textIdAutomationObject[0].getID());
                    textIdAutomationObject[2].getInsightObject().clickSpecial(CoreFrameworkWindows.offSetClick(x, y));
                } catch (Exception e) {
                    Log.debug("Insight object failed, trying with text id automation object");
                    clickUsingTextSikuli(window, textIdAutomationObject[0].getID(), x, y, textIdAutomationObject[1].getRectangle());
                }
            }
        } catch (Exception e) {
            try {
                Log.debug("Trying with insight object first");
                Log.step("Clicking text " + textIdAutomationObject[0].getID());
                textIdAutomationObject[2].getInsightObject().clickSpecial(CoreFrameworkWindows.offSetClick(x, y));
            } catch (Exception l) {
                Log.debug("Insight object failed, trying with text id automation object");
                clickUsingTextSikuli(window, textIdAutomationObject[0].getID(), x, y, textIdAutomationObject[1].getRectangle());
            }
        }
    }


}

