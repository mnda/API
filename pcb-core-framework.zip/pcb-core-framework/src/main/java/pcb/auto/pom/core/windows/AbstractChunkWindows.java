package pcb.auto.pom.core.windows;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.stdwin.Dialog;
import com.hp.lft.sdk.stdwin.Window;
import pcb.auto.pom.core.helper.SyncHelperWindows;

/**
 * Created by angmark on 6/5/2017.
 */
public class AbstractChunkWindows {

    protected AbstractChunkWindows(Dialog dialog) {
        SyncHelperWindows.waitForPageToAppear(dialog);
    }

    protected AbstractChunkWindows(Window window) {
        SyncHelperWindows.waitForPageToAppear(window);
    }

    protected void waitUntilVisible() throws GeneralLeanFtException {

    }
}
