package pcb.auto.pom.core.alm;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.filter.log.ResponseLoggingFilter;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import net.minidev.json.JSONObject;
import okhttp3.MediaType;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.RegexFileFilter;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import pcb.auto.pom.core.helper.CoreFrameworkHelper;
import pcb.auto.pom.core.helper.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Base64;
import java.util.List;
import java.util.Properties;

/**
 * Created by angmark on 6/5/2017.
 */
public class ALMConnector {

    private static String almURL = "";
    private static final String isAuthenticatedPath = "authentication-point/authenticate";
    private static final String qcSiteSession = "rest/site-session";
    private static final String logoutPath = "authentication-point/logout";
    private static String lswoocookie;
    private static String qcsessioncookie;


    private static String strDomain = "";
    private static String strProject = "";
    private static String strUserName = "";
    private static String strPassword = "";
    private static String runID = "";
    private static String gloStatus = "";


    private static String getEncodedAuthString() {
        String auth = strUserName + ":" + strPassword;
        byte[] encodedAuth = Base64.getEncoder().encode(auth.getBytes());
        String authHeader = "Basic " + new String(encodedAuth);

        return authHeader;
    }

    public static final MediaType JSON
            = MediaType.parse("application/json; charset=utf-8");

    public static void main(String[] args) throws Exception {
        ALMConnector t = new ALMConnector();
        JSONObject json = new JSONObject();
        InputStream inputStream = ALMConnector.class.getClassLoader().getResourceAsStream("alm.properties");
        Properties props = new Properties();
        props.load(inputStream);
        String URL = props.getProperty("url");
        String USERID = props.getProperty("userid");
        String PASSWORD = props.getProperty("password");
        String DOMAIN = props.getProperty("domain");
        String PROJECT = props.getProperty("project");
        String ALM_CONNECTOR = props.getProperty("almendpoint");

        json.put("url", URL);
        json.put("domain", DOMAIN);
        json.put("project", PROJECT);
        json.put("username", USERID);
        json.put("password", PASSWORD);
        json.put("testsetid", "59191");
        json.put("testinstanceid", "246119");
        json.put("testid", "160006");
        json.put("testconfigid", "160532");
        json.put("status", "Passed");
        //json = getALMProperties("59191", "160006", "Passed", "scenario");
        String test = "\n" +
                "****************************************************************************************\n" +
                "****************************************************************************************\n" +
                "SCENARIO: OLB Funds Transfer - ASV to DBK-sole-APE040\n" +
                "****************************************************************************************\n" +
                "****************************************************************************************\n" +
                "Step 1: Click Client Identification button\n" +
                "Step 2: Execute API request for transferring funds: <ns2:RBCTransferFundsRequest version=\"1.0\" origin=\"testdbTransferFunds\" lang=\"en\"\n" +
                "    xmlns:ns4=\"http://mobile.rbc.com/rbc/paymenthistory/\"\n" +
                "    xmlns:ns13=\"http://mobiliser.paybox.net/rbc/accountdetails/\"\n" +
                "    xmlns:ns7=\"http://mobile.rbc.com/rbc/manageetransfer/\"\n" +
                "    xmlns:ns16=\"http://rbc.mobile.com/rbc/send3pp/\"\n" +
                "    xmlns:ns5=\"http://rbc.mobile.com/rbc/mobileenrollment/\"\n" +
                "    xmlns:ns12=\"http://mobiliser.paybox.net/rbc/emaillist/\"\n" +
                "    xmlns:ns6=\"http://mobile.rbc.com/rbc/managepayee/\"\n" +
                "    xmlns:ns11=\"http://mobile.rbc.com/rbc/fees/\"\n" +
                "    xmlns:ns9=\"http://rbc.mobile.com/rbc/idattribute/\"\n" +
                "    xmlns:ns17=\"http://rbc.mobile.com/rbc/paybills/\"\n" +
                "    xmlns:ns3=\"http://rbc.mobile.com/rbc/signin/\"\n" +
                "    xmlns:ns14=\"http://rbc.mobile.com/rbc/validatefinancialtransaction/\"\n" +
                "    xmlns:ns2=\"http://rbc.mobile.com/rbc/transferfunds/\"\n" +
                "    xmlns:ns15=\"http://rbc.mobile.com/rbc/sendIEMT/\"\n" +
                "    xmlns:ns8=\"http://mobiliser.paybox.net/rbc/mwallet/\"\n" +
                "    xmlns:ns10=\"http://rbc.mobile.com/rbc/getpayeelist/\">\n" +
                "    <Parameter value=\"RBC_iPhone\" key=\"0\"/>\n" +
                "    <Parameter value=\"5.0\" key=\"1\"/>\n" +
                "    <user>\n" +
                "        <Identifier type=\"cardNumber\">4519035697934588</Identifier>\n" +
                "    </user>\n" +
                "    <fromAccount>\n" +
                "        <isPayee>false</isPayee>\n" +
                "        <name>Savings</name>\n" +
                "        <branch>04701</branch>\n" +
                "        <accountNumber>5020300</accountNumber>\n" +
                "        <type>DDA</type>\n" +
                "        <shortNumber>S002</shortNumber>\n" +
                "        <amount currency=\"CAD\">101</amount>\n" +
                "        <currency>CAD</currency>\n" +
                "    </fromAccount>\n" +
                "    <toAccount>\n" +
                "        <isPayee>false</isPayee>\n" +
                "        <name>Savings</name>\n" +
                "        <branch>02342</branch>\n" +
                "        <accountNumber>5006788</accountNumber>\n" +
                "        <type>DDA</type>\n" +
                "        <shortNumber>S001</shortNumber>\n" +
                "        <currency>CAD</currency>\n" +
                "    </toAccount>\n" +
                "    <amountVerification currency=\"CAD\">101</amountVerification>\n" +
                "    <invoiceNum/>\n" +
                "    <foreignExchange>\n" +
                "        <rate/>\n" +
                "        <formattedFxAmount/>\n" +
                "    </foreignExchange>\n" +
                "</ns2:RBCTransferFundsRequest>\n" +
                "Step 3: Transfer fund successful with: \n" +
                "Confirmation Number:3454\n" +
                "Balance:9979953\n" +
                "Date:Jun 15 2018\n" +
                "Time:14:07 EDT\n" +
                "Waiting for element Link to appear failed: Link not found\n" +
                "Step 4: Waiting for element Link to appear failed: Link not found\n" +
                "Step 5: Failure - check java/jenkins log\n" +
                "\n" +
                "\n" +
                "Report was successfully generated here: \\\\8X4SB43B\\tempReportCISALP\\TransferFunds\\2018-06-15\\20180615-130646\\cucumber-html-reports\\overview-features.html";

        String test2 = "<html><body><br>****************************************************************************************<br>****************************************************************************************<br>SCENARIO: OLB Funds Transfer - ASV to DBK-sole-APE040<br>****************************************************************************************<br>****************************************************************************************<br>Step 1: Click Client Identification button<br>Step 2: Execute API request for transferring funds: &lt;ns2:RBCTransferFundsRequest version=&quot;1.0&quot; origin=&quot;testdbTransferFunds&quot; lang=&quot;en&quot;\n" +
                "<br>    xmlns:ns4=&quot;http://mobile.rbc.com/rbc/paymenthistory/&quot;\n" +
                "<br>    xmlns:ns13=&quot;http://mobiliser.paybox.net/rbc/accountdetails/&quot;\n" +
                "<br>    xmlns:ns7=&quot;http://mobile.rbc.com/rbc/manageetransfer/&quot;\n" +
                "<br>    xmlns:ns16=&quot;http://rbc.mobile.com/rbc/send3pp/&quot;\n" +
                "<br>    xmlns:ns5=&quot;http://rbc.mobile.com/rbc/mobileenrollment/&quot;\n" +
                "<br>    xmlns:ns12=&quot;http://mobiliser.paybox.net/rbc/emaillist/&quot;\n" +
                "<br>    xmlns:ns6=&quot;http://mobile.rbc.com/rbc/managepayee/&quot;\n" +
                "<br>    xmlns:ns11=&quot;http://mobile.rbc.com/rbc/fees/&quot;\n" +
                "<br>    xmlns:ns9=&quot;http://rbc.mobile.com/rbc/idattribute/&quot;\n" +
                "<br>    xmlns:ns17=&quot;http://rbc.mobile.com/rbc/paybills/&quot;\n" +
                "<br>    xmlns:ns3=&quot;http://rbc.mobile.com/rbc/signin/&quot;\n" +
                "<br>    xmlns:ns14=&quot;http://rbc.mobile.com/rbc/validatefinancialtransaction/&quot;\n" +
                "<br>    xmlns:ns2=&quot;http://rbc.mobile.com/rbc/transferfunds/&quot;\n" +
                "<br>    xmlns:ns15=&quot;http://rbc.mobile.com/rbc/sendIEMT/&quot;\n" +
                "<br>    xmlns:ns8=&quot;http://mobiliser.paybox.net/rbc/mwallet/&quot;\n" +
                "<br>    xmlns:ns10=&quot;http://rbc.mobile.com/rbc/getpayeelist/&quot;&gt;\n" +
                "<br>    &lt;Parameter value=&quot;RBC_iPhone&quot; key=&quot;0&quot;/&gt;\n" +
                "<br>    &lt;Parameter value=&quot;5.0&quot; key=&quot;1&quot;/&gt;\n" +
                "<br>    &lt;user&gt;\n" +
                "<br>        &lt;Identifier type=&quot;cardNumber&quot;&gt;4519035697934588&lt;/Identifier&gt;\n" +
                "<br>    &lt;/user&gt;\n" +
                "<br>    &lt;fromAccount&gt;\n" +
                "<br>        &lt;isPayee&gt;false&lt;/isPayee&gt;\n" +
                "<br>        &lt;name&gt;Savings&lt;/name&gt;\n" +
                "<br>        &lt;branch&gt;04701&lt;/branch&gt;\n" +
                "<br>        &lt;accountNumber&gt;5020300&lt;/accountNumber&gt;\n" +
                "<br>        &lt;type&gt;DDA&lt;/type&gt;\n" +
                "<br>        &lt;shortNumber&gt;S002&lt;/shortNumber&gt;\n" +
                "<br>        &lt;amount currency=&quot;CAD&quot;&gt;101&lt;/amount&gt;\n" +
                "<br>        &lt;currency&gt;CAD&lt;/currency&gt;\n" +
                "<br>    &lt;/fromAccount&gt;\n" +
                "<br>    &lt;toAccount&gt;\n" +
                "<br>        &lt;isPayee&gt;false&lt;/isPayee&gt;\n" +
                "<br>        &lt;name&gt;Savings&lt;/name&gt;\n" +
                "<br>        &lt;branch&gt;02342&lt;/branch&gt;\n" +
                "<br>        &lt;accountNumber&gt;5006788&lt;/accountNumber&gt;\n" +
                "<br>        &lt;type&gt;DDA&lt;/type&gt;\n" +
                "<br>        &lt;shortNumber&gt;S001&lt;/shortNumber&gt;\n" +
                "<br>        &lt;currency&gt;CAD&lt;/currency&gt;\n" +
                "<br>    &lt;/toAccount&gt;\n" +
                "<br>    &lt;amountVerification currency=&quot;CAD&quot;&gt;101&lt;/amountVerification&gt;\n" +
                "<br>    &lt;invoiceNum/&gt;\n" +
                "<br>    &lt;foreignExchange&gt;\n" +
                "<br>        &lt;rate/&gt;\n" +
                "<br>        &lt;formattedFxAmount/&gt;\n" +
                "<br>    &lt;/foreignExchange&gt;\n" +
                "<br>&lt;/ns2:RBCTransferFundsRequest&gt;<br>Step 3: Transfer fund successful with: <br>Confirmation Number:3461<br>Balance:9980458<br>Date:Jun 15 2018<br>Time:15:14 EDT<br><br><br>Report was successfully generated here: &#92;&#92;8X4SB43B&#92;tempReportCISALP&#92;TransferFunds&#92;2018-06-15&#92;20180615-141423&#92;cucumber-html-reports&#92;overview-features.html</body></html>";

         updateSteps("197905", "Test Scenario Desc go here", "<html><body>" + htmlCompliance(test) + " </body></html>", "Passed");

        //json.put("comments", test);
        //Log.logToALM(json);
        //t.recordRunInALM(json);
    }


    public static JSONObject getALMProperties(String testSetID, String testID, String status, String scenarioName, String testAlmURL, String testStrUserName,
                                              String testStrPassword, String testStrDomain, String testStrProject, String ALM_CONNECTOR) throws Exception {
        JSONObject json = new JSONObject();

//        InputStream inputStream = ALMConnector.class.getClassLoader().getResourceAsStream("alm.properties");
//        Properties props = new Properties();
//        props.load(inputStream);
//        almURL = props.getProperty("url");
//        strUserName = props.getProperty("userid");
//        strPassword = props.getProperty("password");
//        strDomain = props.getProperty("domain");
//        strProject = props.getProperty("project");
        almURL = testAlmURL;
        strUserName = testStrUserName;
        strPassword = testStrPassword;
        strDomain = testStrDomain;
        strProject = testStrProject;
        //String ALM_CONNECTOR = props.getProperty("almendpoint");


        json.put("almendpoint", ALM_CONNECTOR);
        json.put("url", almURL);
        json.put("domain", strDomain);
        json.put("project", strProject);
        json.put("username", strUserName);
        json.put("password", strPassword);
        json.put("testsetid", testSetID);
        json.put("testinstanceid", "");
        json.put("testid", testID);
        json.put("testconfigid", "");
        json.put("status", status);
        gloStatus = status;
        json.put("comments", "");
        json.put("scenarioname", scenarioName);

        Log.debug("Added alm properties to JSON" + json.values().toString());
        return json;
    }


    public static void recordRunInALM(JSONObject json) throws Exception {
        Log.debug("Recording run in ALM");
        Logger.getRootLogger().setLevel(Level.INFO);
        Log.debug("Test debug onM");
        String jsonAsString, almConnector;
        almConnector = json.get("almendpoint").toString();
        JSONObject jsonObject = new JSONObject(json);
        jsonObject.remove("testinstanceid");
        jsonObject.put("testinstanceid", createTestInstance(almConnector, json));

        RestAssured.baseURI = almConnector;
        Log.debug("Creating test run in ALM");
        RequestSpecification request = RestAssured.given().filter(new ResponseLoggingFilter());

        request.body(jsonObject);
        Response response = request.post("/testrun/");

        int statusCode = response.getStatusCode();

        jsonAsString = response.getBody().asString();
        if (statusCode == 200) {
            response = request.post("/logout");
            runID = jsonAsString.split("\"id\": ", -1)[1].replace("\"", "").replace("}", "");
            Log.info("Run recorded in ALM with Run ID: " + runID);
            //upload screenshot/s
            //uploadScreenshots(runID);
            //update last run report steps
            updateSteps(runID, jsonObject.get("scenarioname").toString(),
                    "<html><body>" + htmlCompliance(jsonObject.get("comments").toString()) + "</body></html>"
                    , jsonObject.get("status").toString());
        } else {
            Log.info("Run was NOT tagged in ALM with error: " + jsonAsString);
        }
        //reset to debug
        Logger.getRootLogger().setLevel(Level.DEBUG);
    }

    private static String createTestInstance(String almConnector, JSONObject json) {

        String jsonAsString;
        RestAssured.baseURI = almConnector;
        RequestSpecification request = RestAssured.given().filter(new ResponseLoggingFilter());
        Log.debug("Creating test instance in ALM");

        json.remove("testinstanceid");
        json.remove("testconfigid");
        json.remove("status");
        json.remove("comments");

        request.body(json);
        Response response = request.post("/testinstance/");

        int statusCode = response.getStatusCode();
        jsonAsString = response.getBody().asString();
        if (statusCode == 200) {
            Log.info("Test Instance in ALM was created or already existed with ID:" + jsonAsString.split("\"id\": ", -1)[1].replace("\"", "").replace("}", ""));
            return jsonAsString.split("\"id\": ", -1)[1].replace("\"", "").replace("}", "").trim();
        } else {
            Log.info("Test Instance was not created in ALM with error: " + jsonAsString);
            return "null";
        }
    }


    private static List getLWSSOCookieKey() {
        try {
            HttpResponse<String> jsonResponse = Unirest.post(almURL + "/qcbin/" + isAuthenticatedPath)
                    .header("Authorization", getEncodedAuthString())
                    .asString();
            return jsonResponse.getHeaders().get("Set-Cookie");
        } catch (Exception e) {
            Log.error("Cannot get lswoocookie cookie from ALM" + e.getMessage());
            return null;
        }

    }

    private static List getQCSessionCookies(String LWSSOCookieKey) {
        try {
            HttpResponse<JsonNode> jsonResponse = Unirest.post(almURL + "/qcbin/" + qcSiteSession)
                    .header("Cookie", LWSSOCookieKey)
                    .asJson();

            return jsonResponse.getHeaders().get("Set-Cookie");
        } catch (Exception e) {
            Log.error("Cannot get qcsessioncookie cookie from ALM" + e.getMessage());
            return null;
        }
    }

    private static void getDefects(String LWSSOCookie, String qcSessionCookie) throws Exception {
        String midPoint = "rest/domains/" + strDomain + "/projects/" + strProject;
        HttpResponse<String> stringResponse = Unirest.get(almURL + "/" + midPoint + "/defects/1")
                .header("Cookie", LWSSOCookie)
                .header("Cookie", qcSessionCookie)
                .asString();
        Log.info(stringResponse.getBody());
    }

    private static void uploadRunAttachment(File initialFile, String runId) throws Exception {
        try {
            String midPoint = "rest/domains/" + strDomain + "/projects/" + strProject;

            InputStream targetStream = new FileInputStream(initialFile);

            final byte[] bytes = new byte[targetStream.available()];
            targetStream.read(bytes);
            targetStream.close();

            Log.debug("Uploading " + initialFile.getName() + " to ALM runID " + runId);
            HttpResponse<String> stringResponse = Unirest.post(almURL + "/qcbin/" + midPoint + "/runs/" + runId + "/attachments")
                    .header("Cookie", lswoocookie)
                    .header("Cookie", qcsessioncookie)
                    .header("Content-Type", "application/octet-stream")
                    .header("Slug", initialFile.getName())
                    .body(bytes)
                    .asString();
            //Log.info(stringResponse.getBody());
        } catch (Exception e) {
            Log.error("There was an error with uploading screenshots to ALM\n" + e.getMessage());
        }
    }

    private static String getCookie(String cookieID, List cookies) {
        String cookieTemp = "";
        for (Object cookie : cookies) {
            if (cookie.toString().contains(cookieID)) {
                cookieTemp = cookie.toString();
                break;
            }
        }
        return cookieTemp;
    }


    private static void logOut() {
        try {
            HttpResponse<String> stringResponse = Unirest.post(almURL + "/" + logoutPath)
                    .header("Cookie", lswoocookie)
                    .header("Cookie", qcsessioncookie)
                    .asString();
        } catch (Exception e) {
            Log.error("Failed to logout ALM Rest Session");
        }
    }


    private static void uploadScreenshots(String runId) throws Exception {
        Logger.getRootLogger().setLevel(Level.INFO);

        //get ALM session
        initializedCookies();


        File tempFolder = new File(CoreFrameworkHelper.getValuesFromProperties("testsettings.properties", "temp_screenshot_folder"));
        List<File> files = (List<File>) FileUtils.listFiles(tempFolder, new RegexFileFilter("(.*/)*.+"), DirectoryFileFilter.DIRECTORY);
        for (File file : files) {
            //upload logs only if test fails
            if (file.getName().contains("txt")) {
                if (gloStatus.toLowerCase().contains("fail")) {
                    uploadRunAttachment(file, runId);
                }
            } else {
                uploadRunAttachment(file, runId);
            }
        }
        logOut();
        Logger.getRootLogger().setLevel(Level.DEBUG);
    }


    private static void updateSteps(String runId, String description, String actual, String status) throws Exception {
        Logger.getRootLogger().setLevel(Level.INFO);

        initializedCookies();
        String[] arIDs = getRunStepIDs(runId).split(",", -1);

        for (int i = 0; i < arIDs.length; i++) {
            if (i == arIDs.length - 1) {
                try {
                    String midPoint = "rest/domains/" + strDomain + "/projects/" + strProject;
                    Log.debug("Updating step details");
                    HttpResponse<String> stringResponse = Unirest.put(almURL + "/qcbin/" + midPoint + "/runs/" + runId + "/run-steps/" + arIDs[i])
                            .header("Cookie", lswoocookie)
                            .header("Cookie", qcsessioncookie)
                            .header("Accept", "application/json")
                            .header("Content-Type", "application/json")
                            .body(getJSONTemplateForSteps(status, actual, description))
                            .asString();
                } catch (Exception e) {
                    Log.error("There was an error updating run step id " + arIDs[i] + " in ALM\n" + e.getMessage());
                }
                break;
            } else {
                try {
                    String midPoint = "rest/domains/" + strDomain + "/projects/" + strProject;
                    Log.debug("Deleting extra steps ID");
                    HttpResponse<String> stringResponse = Unirest.delete(almURL + "/qcbin/" + midPoint + "/runs/" + runId + "/run-steps/" + arIDs[i])
                            .header("Cookie", lswoocookie)
                            .header("Cookie", qcsessioncookie)
                            .asString();
                } catch (Exception e) {
                    Log.error("There was an error deleting run step id " + arIDs[i] + " from ALM\n" + e.getMessage());
                }
            }
        }

        logOut();
        Logger.getRootLogger().setLevel(Level.DEBUG);
    }


    private static void initializedCookies() {
        //get ALM session
        lswoocookie = getCookie("LWSSO_COOKIE_KEY", getLWSSOCookieKey());
        qcsessioncookie = getCookie("QCSession", getQCSessionCookies(lswoocookie));


    }

    private static String getRunStepIDs(String runId) {
        String tempStepIds = "";
        try {
            String midPoint = "rest/domains/" + strDomain + "/projects/" + strProject;
            Log.debug("Getting test run steps ID");
            HttpResponse<String> stringResponse = Unirest.get(almURL + "/qcbin/" + midPoint + "/runs/" + runId + "/run-steps")
                    .header("Cookie", lswoocookie)
                    .header("Cookie", qcsessioncookie)
                    .asString();
            String[] arString = stringResponse.getBody().split("Field Name=\"id", -1);
            for (int i = 1; i < arString.length; i++) {
                tempStepIds = tempStepIds + arString[i].split("<Value>", -1)[1].split("</Value>", -1)[0] + ",";
            }
        } catch (Exception e) {
            Log.error("There was an error extracting run step ids from ALM\n" + e.getMessage());
        }
        return tempStepIds.substring(0, tempStepIds.length() - 1);
    }

    private static String getJSONTemplateForSteps(String status, String actual, String description) {
        String baseJSON = "{\"Fields\":[{\"Name\":\"name\",\"values\":[{}]},{\"Name\":\"status\",\"values\":[{\"value\":\"#@STATUS@#\"}]}," +
                "{\"Name\":\"description\",\"values\":[{\"value\":\"#@DESCRIPTION@#\"}]},{\"Name\":\"expected\",\"values\":[{\"value\":\"\"}]}," +
                "{\"Name\":\"actual\",\"values\":[{\"value\":\"#@ACTUAL@#\"}]},{\"Name\":\"name\",\"values\":[{\"value\":\"Automation Steps\"}]}],\"Type\":\"run-step\",\"children-count\":0}";

        return baseJSON.replace("#@STATUS@#", status).replace("#@DESCRIPTION@#", description).replace("#@ACTUAL@#", actual);
    }


    private static String htmlCompliance(String str) {
        return str.replace("\\", "&#92;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>");
    }
}
