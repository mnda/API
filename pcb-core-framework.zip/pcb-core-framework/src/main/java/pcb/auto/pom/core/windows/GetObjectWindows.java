package pcb.auto.pom.core.windows;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.stdwin.*;
import org.apache.commons.lang.exception.ExceptionUtils;
import pcb.auto.pom.core.helper.Log;

/**
 * Created by angmark on 5/29/2017.
 */
public class GetObjectWindows {

    private GetObjectWindows() {

    }

    public static Dialog getPageObject(DialogDescription dialogDescription) {
        try {
            return Desktop.describe(Dialog.class, dialogDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static Window getPageObject(WindowDescription windowDescription) {
        try {
            return Desktop.describe(Window.class, windowDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static com.hp.lft.sdk.winforms.Window getPageObject(com.hp.lft.sdk.winforms.WindowDescription windowDescription) {
        try {
            return Desktop.describe(com.hp.lft.sdk.winforms.Window.class, windowDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }


    public static ListBox getListBoxObject(Dialog dialog, ListBoxDescription listBoxDescription) {
        try {
            return dialog.describe(ListBox.class, listBoxDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static Button getButtonObject(Dialog dialog, ButtonDescription buttonDescription) {
        try {
            return dialog.describe(Button.class, buttonDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }


    public static EditField getEditFieldObject(Dialog dialog, EditFieldDescription editFieldDescription) {
        try {
            return dialog.describe(EditField.class, editFieldDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

}

