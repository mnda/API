package pcb.auto.pom.core.windows;

import com.hp.lft.sdk.insight.InsightObject;

import java.awt.*;

/**
 * Created by angmark on 11/16/2017.
 */
public class TextIdAutomationObject {
    private String fieldName;
    private Rectangle rectangle;
    private InsightObject insightObj;


    public TextIdAutomationObject() {

    }

    public void setID(String id) {
        this.fieldName = id;
    }

    public String getID() {
        return fieldName;
    }


    public void setRectangle(Rectangle rect) {
        this.rectangle = rect;
    }

    public Rectangle getRectangle() {
        return rectangle;
    }

    public void setInsightObject(InsightObject insightObject) {
        this.insightObj = insightObject;
    }


    public InsightObject getInsightObject() {
        return insightObj;
    }

}
