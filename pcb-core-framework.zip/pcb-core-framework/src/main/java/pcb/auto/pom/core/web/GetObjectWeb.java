package pcb.auto.pom.core.web;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.*;
import com.hp.lft.sdk.winforms.Window;
import com.hp.lft.sdk.winforms.WindowDescription;
import org.apache.commons.lang.exception.ExceptionUtils;
import pcb.auto.pom.core.helper.Log;

/**
 * Created by angmark on 5/29/2017.
 */
public class GetObjectWeb {

    private GetObjectWeb() {

    }

    public static Page getPageObject(WindowDescription windowDescription, PageDescription pageDescription) {
        try {
            return Desktop.describe(Window.class, windowDescription).describe(Page.class, pageDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static Page getPageObject(Browser browser, PageDescription pageDescription) {
        try {
            return browser.describe(Page.class, pageDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }


    public static Page getDialogPageObject(WindowDescription windowDescription1, WindowDescription windowDescription2, PageDescription pageDescription) {
        try {
            return Desktop.describe(Window.class, windowDescription1).describe(Window.class, windowDescription2).describe(Page.class, pageDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }


    public static Button getButtonObject(Page page, ButtonDescription buttonDescription) {
        try {
            return page.describe(Button.class, buttonDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static Link getLinkObject(Page page, LinkDescription linkDescription) {
        try {
            return page.describe(Link.class, linkDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static EditField getEditFieldObject(Page page, EditFieldDescription editFieldDescription) {
        try {
            return page.describe(EditField.class, editFieldDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static Image getImageObject(Page page, ImageDescription imageDescription) {
        try {
            return page.describe(Image.class, imageDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static WebElement getWebElementObject(Page page, WebElementDescription webElementDescription) {
        try {
            return page.describe(WebElement.class, webElementDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static RadioGroup getRadioGroupObject(Page page, RadioGroupDescription radioButtonDescription) {
        try {
            return page.describe(RadioGroup.class, radioButtonDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static Table getTableObject(Page page, TableDescription tableDescription) {
        try {
            return page.describe(Table.class, tableDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static ListBox getListBoxObject(Page page, ListBoxDescription listBoxDescription) {
        try {
            return page.describe(ListBox.class, listBoxDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }


    public static CheckBox getCheckBoxObject(Page page, CheckBoxDescription checkBoxDescription) {
        try {
            return page.describe(CheckBox.class, checkBoxDescription);
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }


}

