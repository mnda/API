package pcb.auto.pom.core.windows.internal.insightobject;

import com.hp.lft.sdk.insight.InsightDescription;
import com.hp.lft.sdk.insight.InsightObject;
import com.hp.lft.sdk.winforms.Window;
import org.sikuli.script.App;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.ScreenshotHelperWindows;
import pcb.auto.pom.core.helper.SyncHelperWindows;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.InputStream;

/**
 * Created by angmark on 1/9/2018.
 */
public class InsightObjectUtils {

    private static RenderedImage readImageFile(String path) throws Exception {
        InputStream imgFile = InsightObjectUtils.class.getClassLoader().getResourceAsStream(path);
        RenderedImage image = ImageIO.read(imgFile);
        return image;
    }


    public static InsightObject getInsightObject(Window parent, String path) throws Exception {
        return parent.describe(InsightObject.class, new InsightDescription(readImageFile(path)));
    }

    public static InsightObject getInsightObjectNonPersistent(Window parent, String path, int similarity) throws Exception {
        InsightDescription insightDescription = new InsightDescription(readImageFile(path), similarity);
        insightDescription.setIndex(0);
        return parent.describe(InsightObject.class, insightDescription);
    }

    public static InsightObject getInsightObject(Window parent, String path, int similarity) throws Exception {
        Boolean bError = true;
        int tempSimilarity = similarity;
        InsightDescription insightDescription = new InsightDescription(readImageFile(path), tempSimilarity);
        insightDescription.setIndex(0);
        //try getting the object until similarity is 100
        do {
            try {
                parent.describe(com.hp.lft.sdk.insight.InsightObject.class, insightDescription).exists(1);
                bError = false;
            } catch (Exception e) {
                tempSimilarity = tempSimilarity + 10;
                Log.debug("Inreasing the similarity to " + tempSimilarity + " for image " + path);
                SyncHelperWindows.explicitWait(1000);
            }
        } while (bError && tempSimilarity <= 100);

        return parent.describe(com.hp.lft.sdk.insight.InsightObject.class, insightDescription);
    }

    public static InsightObject getInsightObject(Window parent, String path, int similarity, int index) throws Exception {
        Boolean bError = true;

        int tempSimilarity = similarity;

        InsightDescription insightDescription = new InsightDescription(readImageFile(path), tempSimilarity);
        insightDescription.setIndex(index);
        //try getting the object until similarity is 100
        do {
            try {
                parent.describe(InsightObject.class, insightDescription).exists(1);
                bError = false;
            } catch (Exception e) {
                tempSimilarity = tempSimilarity + 10;
                Log.debug("Inreasing the similarity to " + tempSimilarity + " for image " + path);
                SyncHelperWindows.explicitWait(1000);
            }
        } while (bError && tempSimilarity <= 100);

        return parent.describe(InsightObject.class, insightDescription);
    }

    public static String getTextFromImage(Window window, String imagepath, String location, int offset) throws Throwable {
        App app = App.focus(window.getWindowTitleRegExp());
        Region region = app.window();

        //convert classpath to actual path
        BufferedImage bufferedImage = ScreenshotHelperWindows.convertRenderedImage(readImageFile(imagepath));
        Pattern imagePathAbs = new Pattern(bufferedImage);

        GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
        int width = gd.getDisplayMode().getWidth();
        int height = gd.getDisplayMode().getHeight();

        region.add(width, width, height, height);
        String result = "";

        try {
            switch (location.toLowerCase()) {
                case "above":
                    result = region.find(imagePathAbs).above(offset).text();
                    region.find(imagePathAbs).above(offset).highlight(1);
                    break;
                case "below":
                    result = region.find(imagePathAbs).below(offset).text();
                    region.find(imagePathAbs).below(offset).highlight(1);
                    break;
                case "left":
                    result = region.find(imagePathAbs).right(offset).text();
                    region.find(imagePathAbs).left(offset).highlight(1);
                    break;
                case "right":
                    result = region.find(imagePathAbs).left(offset).text();
                    region.find(imagePathAbs).right(offset).highlight(1);
                    break;
                case "surround":
                    result = region.find(imagePathAbs).add(offset, offset, offset, offset).text();
                    region.find(imagePathAbs).add(offset, offset, offset, offset).highlight(1);
                    break;
                default:
                    result = region.find(imagePathAbs).text();
                    region.find(imagePathAbs).highlight(1);
                    break;
            }
        } catch (FindFailed e) {
            e.printStackTrace();
        }
        return result;
    }

    public static String getTextFromImageLeanFT(Window window, InsightObject insightObject, String location, int offset) throws Throwable, Exception {
        Rectangle r = new Rectangle(insightObject.getLocation());
        int imageWidth = (int) (insightObject.getSize().getWidth());
        int imageHeight = (int) (insightObject.getSize().getHeight());
        String result = "";
        try {
            switch (location.toLowerCase()) {
                case "above":
                    r.setLocation(r.x, r.y - offset);
                    break;
                case "below":
                    r.setLocation(r.x, r.y + offset);
                    break;
                case "left":
                    r.setLocation(r.x + offset, r.y);
                    break;
                case "right":
                    r.setLocation(r.x - offset, r.y);
                    break;
                case "surround":
                    r.add(r.x + offset, r.y + offset);
                    break;
                default:
                    r.setLocation(r.x, r.y + offset);
                    break;
            }
            r.setSize(imageWidth, imageHeight);
            result = window.getVisibleText(r);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return result;
    }
}
