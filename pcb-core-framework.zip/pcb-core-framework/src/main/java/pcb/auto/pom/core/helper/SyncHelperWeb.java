package pcb.auto.pom.core.helper;

import com.hp.lft.sdk.web.*;
import org.apache.commons.lang.exception.ExceptionUtils;

/**
 * Created by angmark on 5/29/2017.
 */
public class SyncHelperWeb {
    private static int globalWait = Integer.parseInt(CoreFrameworkHelper.getValuesFromProperties("testsettings.properties", "default_wait_time"));

    public SyncHelperWeb(int millis) {
        globalWait = millis;
    }

    public SyncHelperWeb() {
    }

    /**
     * Explicitly holds the execution for the defined time
     *
     * @param milliseconds time to hold in millis
     * @throws InterruptedException if error occurs for thread sleep
     */
    public static void explicitWait(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
        }
    }

    public static void waitForPageToAppear(Page page) {
        int counter = 0;
        boolean exist = false;
        while (!exist) {
            try {
                exist = page.exists(1);
                Log.debug("Waiting for page to appear... Time elapsed: " + counter + " second/s");
                explicitWait(1000);
                if (counter > globalWait / 1000) {
                    logIfNotFound(counter, "Page");
                    break;
                } else {
                    counter++;
                }
            } catch (Exception e) {
                Log.error(ExceptionUtils.getStackTrace(e));
            }
        }
    }


    public static void waitForElementToAppear(Button button) {
        int counter = 0;
        boolean exist = false;
        while (!exist) {
            try {
                exist = button.exists(1);
                Log.debug("Waiting for button to appear... Time elapsed: " + counter + " second/s");
                explicitWait(1000);
                if (counter > globalWait / 1000) {
                    logIfNotFound(counter, "EditField");
                    break;
                } else {
                    counter++;
                }
            } catch (Exception e) {
                Log.error(ExceptionUtils.getStackTrace(e));
            }
        }
    }


    public static void waitForElementToAppear(EditField editField) {
        int counter = 0;
        boolean exist = false;
        while (!exist) {
            try {
                exist = editField.exists(1);
                Log.debug("Waiting for editField to appear... Time elapsed: " + counter + " second/s");
                explicitWait(1000);
                if (counter > globalWait / 1000) {
                    logIfNotFound(counter, "EditField");
                    break;
                } else {
                    counter++;
                }
            } catch (Exception e) {
                Log.error(ExceptionUtils.getStackTrace(e));
            }
        }
    }


    public static void waitForElementToAppear(Link link) {
        int counter = 0;
        boolean exist = false;
        while (!exist) {
            try {
                exist = link.exists(1);
                Log.debug("Waiting for link to appear... Time elapsed: " + counter + " second/s");
                explicitWait(1000);
                if (counter > globalWait / 1000) {
                    logIfNotFound(counter, "Link");
                    break;
                } else {
                    counter++;
                }
            } catch (Exception e) {
                Log.error(ExceptionUtils.getStackTrace(e));
            }
        }
    }


    public static void waitForElementToAppear(Image image) {
        int counter = 0;
        boolean exist = false;
        while (!exist) {
            try {
                exist = image.exists(1);
                Log.debug("Waiting for image to appear... Time elapsed: " + counter + " second/s");
                explicitWait(1000);
                if (counter > globalWait / 1000) {
                    logIfNotFound(counter, "Image");
                    break;
                } else {
                    counter++;
                }
            } catch (Exception e) {
                Log.error(ExceptionUtils.getStackTrace(e));
            }
        }
    }

    public static void waitForElementToAppear(WebElement webElement) {
        int counter = 0;
        boolean exist = false;
        while (!exist) {
            try {
                exist = webElement.exists(1);
                Log.debug("Waiting for webelement to appear... Time elapsed: " + counter + " second/s");
                explicitWait(1000);
                if (counter > globalWait / 1000) {
                    logIfNotFound(counter, "WebElement");
                    break;
                } else {
                    counter++;
                }
            } catch (Exception e) {
                Log.error(ExceptionUtils.getStackTrace(e));
            }
        }
    }

    public static void waitForElementToAppear(RadioGroup radioGroup) {
        int counter = 0;
        boolean exist = false;
        while (!exist) {
            try {
                exist = radioGroup.exists(1);
                Log.debug("Waiting for radioGroup to appear... Time elapsed: " + counter + " second/s");
                explicitWait(1000);
                if (counter > globalWait / 1000) {
                    logIfNotFound(counter, "RadioGroup");
                    break;
                } else {
                    counter++;
                }
            } catch (Exception e) {
                Log.error(ExceptionUtils.getStackTrace(e));
            }
        }
    }

    private static void logIfNotFound(int counter, String object) {
        Log.error("Waiting for element " + object + " to appear failed: " + object + " not found");
    }

}