package pcb.auto.pom.core.windows.internal.click;

import com.hp.lft.sdk.Mouse;
import com.hp.lft.sdk.MouseButton;
import com.hp.lft.sdk.winforms.Window;
import org.sikuli.basics.Settings;
import org.sikuli.script.App;
import org.sikuli.script.Region;
import pcb.auto.pom.core.helper.CoreFrameworkHelper;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWindows;
import pcb.auto.pom.core.windows.TextIdAutomationObject;

import java.awt.*;

/**
 * Created by angmark on 12/5/2017.
 */
public class DoubleClickWindows {

    private static int dblClickGlobalWait = 10000;

    public static void dblClickUsingText(Window window, String text) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Rectangle[] r = SyncHelperWindows.waitForTextToBePresent(window, text, dblClickGlobalWait);
        if (r != null) {
            int xCoord = window.getAbsoluteLocation().x + r[0].x + 10;
            int yCoord = window.getAbsoluteLocation().y + r[0].y + 10;
            Log.step("Double clicking text " + text);
            Log.debug("Double clicking text " + text + " in the window coordinates x:" + xCoord + " y:" + yCoord);
            Rectangle rect2 = new Rectangle(xCoord, yCoord, 20, 20);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.doubleClick(new Point(xCoord, yCoord));
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }

    public static void dblClickUsingText(Window window, String text, MouseButton mouseButton) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Rectangle[] r = SyncHelperWindows.waitForTextToBePresent(window, text, dblClickGlobalWait);
        if (r != null) {
            int xCoord = window.getAbsoluteLocation().x + r[0].x + 10;
            int yCoord = window.getAbsoluteLocation().y + r[0].y + 10;
            Log.step("Double clicking text " + text);
            Log.debug("Double clicking text " + text + " in the window coordinates x:" + xCoord + " y:" + yCoord);
            Rectangle rect2 = new Rectangle(xCoord, yCoord, 20, 20);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.doubleClick(new Point(xCoord, yCoord), mouseButton);
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }

    public static void dblClickUsingText(Window window, String text, int offsetX, int offsetY, Rectangle rect) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Double rectX = rect.getX();
        Double rectY = rect.getY();
        Rectangle[] r = SyncHelperWindows.waitForTextToBePresent(window, text, rect);
        if (r != null) {
            int xCoord = window.getAbsoluteLocation().x + (r[0].x + rectX.intValue()) + 10 + offsetX;
            int yCoord = window.getAbsoluteLocation().y + (r[0].y + rectY.intValue()) + 10 + offsetY;
            Rectangle rect2 = new Rectangle(xCoord, yCoord, 50, 50);
            CoreFrameworkHelper.highlightRectangle(window, rect2);
            Log.step("Double clicking text " + text);
            Log.debug("Double clicking text " + text + " with offset in the window coordinates x:" + xCoord + " y:" + yCoord);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.doubleClick(new Point(xCoord, yCoord));
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }

    public static void dblClickUsingText(Window window, String text, int offsetX, int offsetY, Rectangle rect, MouseButton mouseButton) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Double rectX = rect.getX();
        Double rectY = rect.getY();
        Rectangle[] r = SyncHelperWindows.waitForTextToBePresent(window, text, rect);
        if (r != null) {
            int xCoord = window.getAbsoluteLocation().x + (r[0].x + rectX.intValue()) + 10 + offsetX;
            int yCoord = window.getAbsoluteLocation().y + (r[0].y + rectY.intValue()) + 10 + offsetY;
            Rectangle rect2 = new Rectangle(xCoord, yCoord, 50, 50);
            CoreFrameworkHelper.highlightRectangle(window, rect2);
            Log.step("Double clicking text " + text);
            Log.debug("Double clicking text " + text + " with offset in the window coordinates x:" + xCoord + " y:" + yCoord);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.doubleClick(new Point(xCoord, yCoord), mouseButton);
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }

    public static void dblClickUsingText(Window window, String text, int offsetX, int offsetY) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Rectangle[] r = window.getTextLocations(text);
        if (r != null) {
            int xCoord = window.getAbsoluteLocation().x + r[0].x + 10 + offsetX;
            int yCoord = window.getAbsoluteLocation().y + r[0].y + 10 + offsetY;
            Log.step("Double clicking text " + text);
            Log.debug("Double clicking text " + text + " with offset and rectangle in the window coordinates x:" + xCoord + " y:" + yCoord);
            Rectangle rect2 = new Rectangle(xCoord, yCoord, 50, 50);
            CoreFrameworkHelper.highlightRectangle(window, rect2);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.doubleClick(new Point(xCoord, yCoord));
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }

    public static void dblClickUsingText(Window window, String text, int offsetX, int offsetY, MouseButton mouseButton) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Rectangle[] r = SyncHelperWindows.waitForTextToBePresent(window, text, dblClickGlobalWait);
        if (r != null) {
            int xCoord = window.getAbsoluteLocation().x + r[0].x + 10 + offsetX;
            int yCoord = window.getAbsoluteLocation().y + r[0].y + 10 + offsetY;
            Log.step("Double clicking text " + text);
            Log.debug("Double clicking text " + text + " with offset and rectangle in the window coordinates x:" + xCoord + " y:" + yCoord);
            Rectangle rect2 = new Rectangle(xCoord, yCoord, 50, 50);
            CoreFrameworkHelper.highlightRectangle(window, rect2);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.doubleClick(new Point(xCoord, yCoord), mouseButton);
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }


    public static void dblClickText(Window window, String text, int offsetX, int offsetY, Rectangle[] rect, Rectangle rArea) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Double rectX = rArea.getX();
        Double rectY = rArea.getY();
        if (rect != null) {
            int xCoord = window.getAbsoluteLocation().x + rect[0].x + rectX.intValue() + 10 + offsetX;
            int yCoord = window.getAbsoluteLocation().y + rect[0].y + rectY.intValue() + offsetY;
            Log.step("Double clicking text " + text);
            Log.debug("Clicking text " + text + " with offset and rectangle in the window coordinates x:" + xCoord + " y:" + yCoord);
            Rectangle rect2 = new Rectangle(xCoord, yCoord, 50, 50);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.doubleClick(new Point(xCoord, yCoord));
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }

    public static void dblClickText(Window window, String text, int offsetX, int offsetY, Rectangle[] rect, Rectangle rArea, MouseButton mouseButton) throws Throwable {
        Log.info("Looking for text " + text + " in the window");
        Double rectX = rArea.getX();
        Double rectY = rArea.getY();
        if (rect != null) {
            int xCoord = window.getAbsoluteLocation().x + rect[0].x + rectX.intValue() + 10 + offsetX;
            int yCoord = window.getAbsoluteLocation().y + rect[0].y + rectY.intValue() + offsetY;
            Log.step("Double clicking text " + text);
            Log.debug("Clicking text " + text + " with offset and rectangle in the window coordinates x:" + xCoord + " y:" + yCoord);
            Rectangle rect2 = new Rectangle(xCoord, yCoord, 50, 50);
            Mouse.move(new Point(xCoord, yCoord));
            Mouse.doubleClick(new Point(xCoord, yCoord), mouseButton);
        } else {
            throw new java.lang.RuntimeException("Text " + text + " was not found in the window");
        }
    }

    public static void dblClickUsingTextSikuli(Window window, String text, int offsetX, int offsetY, Rectangle rect) throws Throwable {
        Settings.OcrTextRead = true; // to switch on the Region.text() function
        Settings.OcrTextSearch = true;
        Settings.ActionLogs = false;

        Log.info("Looking for text " + text + " in the window");

        App app = App.focus(window.getWindowTitleRegExp());
        app.focus();
        Region region = app.window();
        region.setRect(rect);
        Log.step("Double clicking  " + text + " in the window if it exists");
        try {
            region.doubleClick(text);
        } catch (Exception e) {
            Log.debug("Cannot find text using sikuli, switching to LeanFT");
            dblClickUsingText(window, text);
        }
    }

    public static void dblClickTIAO(Window window, TextIdAutomationObject[] textIdAutomationObject) throws Throwable {
        try {
            //defaults to tst
            if (System.getProperty("testMachine").toLowerCase().equals("vm")) {
                try {
                    Log.debug("Trying with text id automation object");
                    dblClickUsingTextSikuli(window, textIdAutomationObject[0].getID(), 0, 0, textIdAutomationObject[1].getRectangle());
                } catch (Exception e) {
                    Log.debug("Text ID failed, Trying with insight object");
                    Log.step("Double clicking text " + textIdAutomationObject[0].getID());
                    textIdAutomationObject[2].getInsightObject().doubleClick();
                }
            } else {
                try {
                    Log.debug("Trying with insight object first");
                    Log.step("Double clicking text " + textIdAutomationObject[0].getID());
                    textIdAutomationObject[2].getInsightObject().doubleClick();
                } catch (Exception e) {
                    Log.debug("Insight object failed, trying with text id automation object");
                    dblClickUsingTextSikuli(window, textIdAutomationObject[0].getID(), 0, 0, textIdAutomationObject[1].getRectangle());
                }
            }
        } catch (Exception e) {
            try {
                Log.debug("Trying with insight object first");
                Log.step("Double clicking text " + textIdAutomationObject[0].getID());
                textIdAutomationObject[2].getInsightObject().doubleClick();
            } catch (Exception l) {
                Log.debug("Insight object failed, trying with text id automation object");
                dblClickUsingTextSikuli(window, textIdAutomationObject[0].getID(), 0, 0, textIdAutomationObject[1].getRectangle());
            }
        }

    }

    public static void dblClickTIAO(Window window, TextIdAutomationObject[] textIdAutomationObject, int x, int y) throws Throwable {
        try {
            //defaults to tst
            if (System.getProperty("testMachine").toLowerCase().equals("vm")) {
                try {
                    Log.debug("Trying with text id automation object");
                    dblClickUsingTextSikuli(window, textIdAutomationObject[0].getID(), x, y, textIdAutomationObject[1].getRectangle());
                } catch (Exception e) {
                    Log.debug("Text ID failed, Trying with insight object");
                    Log.step("Double clicking text " + textIdAutomationObject[0].getID());
                    textIdAutomationObject[2].getInsightObject().doubleClick();
                }
            } else {
                try {
                    Log.debug("Trying with insight object first");
                    Log.step("Double clicking text " + textIdAutomationObject[0].getID());
                    textIdAutomationObject[2].getInsightObject().doubleClick();
                } catch (Exception e) {
                    Log.debug("Insight object failed, trying with text id automation object");
                    dblClickUsingTextSikuli(window, textIdAutomationObject[0].getID(), x, y, textIdAutomationObject[1].getRectangle());
                }
            }
        } catch (Exception e) {
            try {
                Log.debug("Trying with insight object first");
                Log.step("Double clicking text " + textIdAutomationObject[0].getID());
                textIdAutomationObject[2].getInsightObject().doubleClick();
            } catch (Exception l) {
                Log.debug("Insight object failed, trying with text id automation object");
                dblClickUsingTextSikuli(window, textIdAutomationObject[0].getID(), x, y, textIdAutomationObject[1].getRectangle());
            }
        }
    }

}