package pcb.auto.pom.core.basestepsdefinition;

/**
 * Created by angmark on 6/5/2017.
 */
public class AbstractStepsDefinition {

    protected void logClassName() throws Exception {

    }

}
