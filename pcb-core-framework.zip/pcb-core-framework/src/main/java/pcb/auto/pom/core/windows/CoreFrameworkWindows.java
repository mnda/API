package pcb.auto.pom.core.windows;

import com.hp.lft.report.Reporter;
import com.hp.lft.sdk.*;
import com.hp.lft.sdk.insight.InsightObject;
import com.hp.lft.sdk.stdwin.EditField;
import com.hp.lft.sdk.stdwin.ListBox;
import com.hp.lft.sdk.winforms.Window;
import org.sikuli.basics.Settings;
import pcb.auto.pom.core.windows.internal.click.ClickArgsUtilsWindows;
import pcb.auto.pom.core.windows.internal.click.ClickWindows;
import pcb.auto.pom.core.windows.internal.click.DoubleClickWindows;
import pcb.auto.pom.core.windows.internal.insightobject.InsightObjectUtils;
import pcb.auto.pom.core.windows.internal.set.SetWindows;
import pcb.auto.pom.core.windows.internal.textobject.TextObject;
import pcb.auto.pom.core.windows.internal.window.WindowUtils;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.net.URI;


/**
 * Created by angmark on 5/29/2017.
 */
public class CoreFrameworkWindows {

    static {
        Settings.OcrTextRead = true; // to switch on the Region.text() function
        Settings.OcrTextSearch = true;
        Settings.ActionLogs = false;
    }

    private CoreFrameworkWindows() {
        //turn off num lock
        Toolkit.getDefaultToolkit().setLockingKeyState(KeyEvent.VK_NUM_LOCK, false);
    }


    // **** Click events *****//
    public static void click(com.hp.lft.sdk.stdwin.Button button) throws GeneralLeanFtException {
        ClickWindows.click(button);
    }


    // **** Set events *****//

    public static void set(ListBox listBox, String value) throws GeneralLeanFtException {
        SetWindows.set(listBox, value);
    }

    public static void set(EditField editField, String value) throws GeneralLeanFtException {
        SetWindows.set(editField, value);
    }


    public static void setPassword(EditField editField, String value) throws GeneralLeanFtException {
        SetWindows.setPassword(editField, value);
    }

    // ********************  OLD Functions **************************//

    //public static class Instantiate {

    //Instantiate Framework
    public static void instantiateSDK() throws Exception {
        ModifiableSDKConfiguration config = new ModifiableSDKConfiguration();
        config.setServerAddress(new URI("ws://localhost:5095"));
        SDK.init(config);
        Reporter.init();
    }

    public static void cleanupSDK() throws Exception {
        SDK.cleanup();
    }

    //}

    //Insight Object Related
    public static InsightObject getInsightObject(Window parent, String path) throws Exception {
        return InsightObjectUtils.getInsightObject(parent, path);
    }

    public static InsightObject getInsightObjectNonPersistent(Window parent, String path, int similarity) throws Exception {
        return InsightObjectUtils.getInsightObjectNonPersistent(parent, path, similarity);
    }

    public static InsightObject getInsightObject(Window parent, String path, int similarity) throws Exception {
        return InsightObjectUtils.getInsightObject(parent, path, similarity);
    }

    public static InsightObject getInsightObject(Window parent, String path, int similarity, int index) throws Exception {
        return InsightObjectUtils.getInsightObject(parent, path, similarity, index);
    }

    public static String getTextFromImage(Window window, String imagepath, String location, int offset) throws Throwable, Exception {
        return InsightObjectUtils.getTextFromImage(window, imagepath, location, offset);
    }

    public static String getTextFromImageLeanFT(Window window, InsightObject insightObject, String location, int offset) throws Throwable, Exception {
        return InsightObjectUtils.getTextFromImageLeanFT(window, insightObject, location, offset);
    }

//ClickWeb Arguments

    public static ClickArgs offSetClick(int x, int y) {
        return ClickArgsUtilsWindows.offSetClick(x, y);
    }

    public static ClickArgs offSetClick(int x, int y, String mouseButton) {
        return ClickArgsUtilsWindows.offSetClick(x, y, mouseButton);
    }

    //Set
    public static void setValueForInsightObject(Window parent, InsightObject insightObject, String value, int x, int y) throws IOException, GeneralLeanFtException, InterruptedException {
        SetWindows.setValueForInsightObject(parent, insightObject, value, x, y);
    }


    public static void clearField(InsightObject insightObject) throws Exception {
        SetWindows.clearField(insightObject);
    }

    public static void clearField(InsightObject insightObject, ClickArgs clickArgs) throws Exception {
        SetWindows.clearField(insightObject, clickArgs);
    }

    public static void sikuliSendString(Window window, String value) throws Throwable {
        SetWindows.sikuliSendString(window, value);
    }

    public static void sikuliSendString(Window window, String value, int modifiers) throws Throwable {
        SetWindows.sikuliSendString(window, value, modifiers);
    }

    public static void sikuliClearField(Window window) throws Throwable {
        SetWindows.sikuliClearField(window);
    }

    public static void fillOutField(Window window, TextIdAutomationObject[] textIdAutomationObjects, String value, int actualFieldX, int ActualFieldY) throws Throwable {
        SetWindows.fillOutField(window, textIdAutomationObjects, value, actualFieldX, ActualFieldY);
    }

    public static void fillOutFieldTIAO(Window window, TextIdAutomationObject[] textIdAutomationObjects, String value, int actualFieldX, int ActualFieldY) throws Throwable {
        SetWindows.fillOutFieldTIAO(window, textIdAutomationObjects, value, actualFieldX, ActualFieldY);
    }


    // ClickWeb
    public static void clickUsingText(Window window, String text) throws Throwable {
        ClickWindows.clickUsingText(window, text);
    }

    public static void clickUsingText(Window window, String text, int offsetX, int offsetY) throws Throwable {
        ClickWindows.clickUsingText(window, text, offsetX, offsetY);
    }

    public static void clickUsingText(Window window, String text, int offsetX, int offsetY, Rectangle rect) throws Throwable {
        //click.clickUsingText(window, text, offsetX, offsetY, rect);
        ClickWindows.clickUsingTextSikuli(window, text, offsetX, offsetY, rect);
    }

    public static void clickUsingText(Window window, String text, MouseButton mouseButton) throws Throwable {
        ClickWindows.clickUsingText(window, text, mouseButton);
    }

    public static void clickUsingText(Window window, String text, int offsetX, int offsetY, MouseButton mouseButton) throws Throwable {
        ClickWindows.clickUsingText(window, text, offsetX, offsetY, mouseButton);
    }

    public static void clickUsingText(Window window, String text, int offsetX, int offsetY, Rectangle rect, MouseButton mouseButton) throws Throwable {
        ClickWindows.clickUsingTextSikuli(window, text, offsetX, offsetY, rect, mouseButton);
    }

    public static void clickTIAO(Window window, TextIdAutomationObject[] textIdAutomationObject) throws Throwable {
        ClickWindows.clickTIAO(window, textIdAutomationObject);
    }

    public static void clickTIAO(Window window, TextIdAutomationObject[] textIdAutomationObject, int x, int y) throws Throwable {
        ClickWindows.clickTIAO(window, textIdAutomationObject, x, y);
    }

    public static void clickText(Window window, String text, int offsetX, int offsetY, Rectangle[] rect, Rectangle rArea) throws Throwable {
        ClickWindows.clickText(window, text, offsetX, offsetY, rect, rArea);
    }

    public static void clickText(Window window, String text, int offsetX, int offsetY, Rectangle[] rect, Rectangle rArea, MouseButton mouseButton) throws Throwable {
        ClickWindows.clickText(window, text, offsetX, offsetY, rect, rArea, mouseButton);
    }

    //Double ClickWeb
    public static void dblClickUsingText(Window window, String text) throws Throwable {
        DoubleClickWindows.dblClickUsingText(window, text);
    }

    public static void dblClickUsingText(Window window, String text, int offsetX, int offsetY, Rectangle rect) throws Throwable {
        DoubleClickWindows.dblClickUsingText(window, text, offsetX, offsetY, rect);
    }

    public static void dblClickUsingText(Window window, String text, int offsetX, int offsetY) throws Throwable {
        DoubleClickWindows.dblClickUsingText(window, text, offsetX, offsetY);
    }

    public static void dblClickUsingText(Window window, String text, MouseButton mouseButton) throws Throwable {
        DoubleClickWindows.dblClickUsingText(window, text, mouseButton);
    }

    public static void dblClickUsingText(Window window, String text, int offsetX, int offsetY, Rectangle rect, MouseButton mouseButton) throws Throwable {
        DoubleClickWindows.dblClickUsingText(window, text, offsetX, offsetY, rect, mouseButton);
    }

    public static void dblClickUsingText(Window window, String text, int offsetX, int offsetY, MouseButton mouseButton) throws Throwable {
        DoubleClickWindows.dblClickUsingText(window, text, offsetX, offsetY, mouseButton);
    }

    public static void dblClickTIAO(Window window, TextIdAutomationObject[] textIdAutomationObject) throws Throwable {
        DoubleClickWindows.dblClickTIAO(window, textIdAutomationObject);
    }

    public static void dblClickTIAO(Window window, TextIdAutomationObject[] textIdAutomationObject, int x, int y) throws Throwable {
        DoubleClickWindows.dblClickTIAO(window, textIdAutomationObject, x, y);
    }

    //WindowUtils
    public static void maximizeWindow(Window window) throws Exception {
        WindowUtils.maximizeWindow(window);
    }

    public static void maximizeWindow(Window window, int width, int height) throws Exception {
        WindowUtils.maximizeWindow(window, height, width);
    }

    public static void minimizeWindow(Window window) throws Exception {
        WindowUtils.minimizeWindow(window);
    }


    //Text Object
    public static TextIdAutomationObject[] setTextIdAutomationObject(String fieldName, Rectangle rect) {
        return TextObject.setTextIdAutomationObject(fieldName, rect);
    }

    public static TextIdAutomationObject[] setTextIdAutomationObject(String fieldName, Rectangle rect, InsightObject insightObject) {
        return TextObject.setTextIdAutomationObject(fieldName, rect, insightObject);
    }

}