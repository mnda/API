package pcb.auto.pom.core.helper;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.pdfbox.contentstream.operator.Operator;
import org.apache.pdfbox.cos.COSArray;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.cos.COSString;
import org.apache.pdfbox.pdfparser.PDFStreamParser;
import org.apache.pdfbox.pdfwriter.ContentStreamWriter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * Created by angmark on 2/5/2018.
 */

public class PDFReport {

    private static PDDocument document;
    private static PDPageContentStream contentStream;
    private static PDFont font;
    private static int fontSize, textRenderingLineY, newPageFlag;
    private static PDPage page;
    private static int docHeight = 780;


    public static void main(String[] args) throws Exception {

        String location = "C:/PDFSamples/my_doc.pdf";
        String location2 = "C:/PDFSamples/my_doc2.pdf";
        String imageLoc = "C:/PDFSamples/A.png";
        Logger.getRootLogger().setLevel(Level.INFO);
        initializeDocument("Project", "Feature Test", "Test Test");
        writeText("This is a test\nKulas\nYouToo");
        writeText("Step 1: This is a test you know!");
        writeText("Step 2: PASSED: Blag Bla");
        writeText("FAILED: BBBBBBBB");
        writeText("Step shouldn't be bold");
        writeText("4This site uses cookies to deliver our services and to show you relevant ads and job listings. By using our site, you acknowledge that you have read and understand our Cookie Policy, Privacy Policy, and our Terms of Service. Your use of Stack Overflow’s Products and Services, including the Stack Overflow Network, is subject to these policies and terms.");
        writeImage();
        writeText("This is a test5");
        writeText("This is a test6");
        writeImage();
        closeDocument(location, "PASSED");

        initializeDocument("Project NEWBOY", "Feature Test", "Test Test");
        writeText("This is a test\nKulas\nYouToo");
        writeText("Step 1: This is a test you know!");
        writeText("Step 2: PASSED: Blag Bla");
        writeText("FAILED: BBBBBBBB");
        writeText("Step shouldn't be bold");
        writeText("4This site uses cookies to deliver our services and to show you relevant ads and job listings. By using our site, you acknowledge that you have read and understand our Cookie Policy, Privacy Policy, and our Terms of Service. Your use of Stack Overflow’s Products and Services, including the Stack Overflow Network, is subject to these policies and terms.");
        writeImage();
        writeText("This is a test5");
        writeText("This is a test6");
        writeImage();
        closeDocument(location2, "PASSED");
    }

    public static void initializeDocument(String projectName, String featureName, String testName) throws Exception {
        Log.debug("Initializing PDF Report");
        Logger.getRootLogger().setLevel(Level.OFF);
        document = new PDDocument();
        page = new PDPage();
        contentStream = null;
        Logger.getRootLogger().setLevel(Level.INFO);
        addNewPage();
        writeText("_________________________________________________________________________________________________________________");
        setTextToBlue();
        writeText("Project: " + projectName);
        writeText("Feature File/Test Set: " + featureName);
        writeText("Test Name: " + testName);
        writeText("Date: " + java.time.LocalDate.now());
        writeText("Result: RESULT_PLACE_HOLDER");
        setTextToNormal();
        //adjust new line
        contentStream.newLineAtOffset(0, 5);
        writeText("_________________________________________________________________________________________________________________");
        writeText("");
        Logger.getRootLogger().setLevel(Level.DEBUG);
    }

    private static void setFont() throws Exception {
        Log.debug("Initializing PDF Report");
        //Setting the font to the Content stream
        font = PDType1Font.HELVETICA;
        fontSize = 8;
        contentStream.setFont(font, fontSize);
        contentStream.beginText();
    }

    private static void setFontBold() throws Exception {
        //Setting the font to the Content stream
        PDFont font = PDType1Font.HELVETICA_BOLD;
        contentStream.setFont(font, fontSize);
    }

    private static void setFontNormal() throws Exception {
        //Setting the font to the Content stream
        PDFont font = PDType1Font.HELVETICA;
        contentStream.setFont(font, fontSize);
    }


    private static void addNewPage() throws Exception {
        PDPage blankPage = new PDPage();
        document.addPage(blankPage);
        //Retrieving the pages of the document
        page = document.getPage(document.getNumberOfPages() - 1);
        try {
            contentStream.endText();
        } catch (Exception e) {

        }
        try {
            contentStream.close();
        } catch (Exception e) {

        }
        contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.OVERWRITE, true, true);
        setFont();
        contentStream.newLineAtOffset(40, 750);
        //reset rendering line
        textRenderingLineY = 0;
        newPageFlag = 1;
    }

    public static void closeDocument(String location, String status) throws Exception {
        Log.debug("Closing and Generating PDF Document");
        //Ending the content stream
        contentStream.endText();

        //Closing the content stream
        contentStream.close();


        for (int i = 0; i < document.getNumberOfPages(); i++) {
            page = document.getPage(i);
            contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true, true);
            contentStream.setFont(font, 5);
            contentStream.beginText();
            contentStream.newLineAtOffset(40, 10);
            contentStream.showText("Page " + (i + 1) + "                                                                    " +
                    "                                                                    " +
                    "                                                                    " +
                    "                        " +
                    "Report Generated on: " + new Date() +
                    " - Cards & Payments, Technology & Operations");
            contentStream.endText();
            contentStream.close();
        }

        ReplaceText("RESULT_PLACE_HOLDER", status);
        //Saving the document
        document.save(location);

        Log.debug("PDF Report created in " + location);

        //Closing the document
        document.close();
    }

    public static void writeText(String text) throws Exception {
        String[] arText = text.split("\n", -1);

        //check if there's new line
        for (int x = 0; x < arText.length; x++) {
            int paragraphLength = 140;
            int lastIndex = 0;
            //check if line has longer length than the allowed paragraph
            if (arText[x].length() > paragraphLength) {
                int lines = (int) Math.ceil((double) arText[x].length() / (double) paragraphLength);
                //write the lines with wrapping
                for (int g = 0; g < lines; g++) {
                    int s = (g + 1) * paragraphLength;
                    if (s > arText[x].length()) {
                        s = arText[x].length();
                        String tempText = arText[x].substring(lastIndex, s).trim();
                        writeDetails(tempText);
                        break;
                    }
                    while (!arText[x].substring(s, s + 1).equals(" ")) {
                        s++;
                    }
                    String tempText = arText[x].substring(lastIndex, s).trim();
                    lastIndex = s;

                    writeWrapping(tempText);
                }
            } else {
                writeDetails(arText[x]);
            }


        }
    }

    private static void setTextToRed() throws Exception {
        contentStream.setNonStrokingColor(163, 0, 0);
    }

    private static void setTextToBlue() throws Exception {
        contentStream.setNonStrokingColor(0, 0, 104);
    }

    private static void setTextToGreen() throws Exception {
        contentStream.setNonStrokingColor(0, 128, 0);
    }

    private static void setTextToNormal() throws Exception {
        contentStream.setNonStrokingColor(0, 0, 0);
    }


    private static void checkResultBeforeWriting(String text) throws Exception {
        if (text.toLowerCase().contains("passed")) {
            setTextToGreen();
            contentStream.showText(text);
            setTextToNormal();
        } else if (text.toLowerCase().contains("failed") || text.toLowerCase().contains("terminating")) {
            setTextToRed();
            contentStream.showText(text);
            setTextToNormal();
        } else {
            contentStream.showText(text);
        }
    }


    private static void writeDetails(String text) throws Exception {
        if (textRenderingLineY + 20 >= docHeight - 12) {
            addNewPage();
        }
        //add bold to Step
        if (CoreFrameworkHelper.regexChecker("Project.*:.*|Step .*:.*|Feature File/Test Set.*:.*|Test Name.*:.*|Date.*:.*|Result.*:.*", text)) {
            String[] arSplitColon = text.split(":", -1);
            setFontBold();
            contentStream.showText(arSplitColon[0]);
            setFontNormal();
            for (int i = 1; i < arSplitColon.length; i++) {
                checkResultBeforeWriting(":" + arSplitColon[i]);
            }
        } else {
            checkResultBeforeWriting(text);
        }

        contentStream.newLineAtOffset(0, -15);
        textRenderingLineY = textRenderingLineY + 20;
    }

    private static void writeWrapping(String text) throws Exception {
        if (textRenderingLineY + 25 >= docHeight - 25) {
            addNewPage();
        }
        checkResultBeforeWriting(text);
        contentStream.newLineAtOffset(0, -10);
        textRenderingLineY = textRenderingLineY + 12;
    }

    public static void writeImage() throws Exception {
        //just get the latest screenshot whenever this is called
        String location = getTheNewestFile(CoreFrameworkHelper.getValuesFromProperties("testsettings.properties", "temp_screenshot_folder") + "\\", "png");
        try {
            if (textRenderingLineY + 220 >= docHeight - 18) {
                addNewPage();
                textRenderingLineY = 40;
            }
            //Ending the content stream
            contentStream.endText();

            //Creating PDImageXObject object
            PDImageXObject pdImage = PDImageXObject.createFromFile(location, document);

            //Drawing the image in the PDF document
            if(textRenderingLineY < 100){
                textRenderingLineY = textRenderingLineY + 40;
            }
            contentStream.drawImage(pdImage, 50, docHeight - textRenderingLineY - 195, 280, 211);

            Log.debug("Image inserted");
            //Begin the Content stream
            contentStream.beginText();
            contentStream.newLineAtOffset(40, docHeight - textRenderingLineY - 220);
            textRenderingLineY = textRenderingLineY + 220;

        } catch (Exception e) {
            Log.warn("Image file was not found in: " + location);
        }
    }


    private static String getTheNewestFile(String filePath, String ext) {
        File theNewestFile = null;
        File dir = new File(filePath);
        FileFilter fileFilter = new WildcardFileFilter("*." + ext);
        File[] files = dir.listFiles(fileFilter);

        if (files.length > 0) {
            /** The newest file comes first **/
            Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
            theNewestFile = files[0];
        }

        return theNewestFile.getAbsolutePath();
    }


    private static void ReplaceText(String searchString, String replacement) throws IOException {
        for (PDPage page : document.getPages()) {
            PDFStreamParser parser = new PDFStreamParser(page);
            parser.parse();
            List tokens = parser.getTokens();

            for (int j = 0; j < tokens.size(); j++) {
                Object next = tokens.get(j);
                if (next instanceof Operator) {
                    Operator op = (Operator) next;

                    String pstring = "";
                    int prej = 0;

                    //Tj and TJ are the two operators that display strings in a PDF
                    if (op.getName().equals("Tj")) {
                        // Tj takes one operator and that is the string to display so lets update that operator
                        COSString previous = (COSString) tokens.get(j - 1);
                        String string = previous.getString();
                        string = string.replaceFirst(searchString, replacement);
                        previous.setValue(string.getBytes());
                    } else if (op.getName().equals("TJ")) {
                        COSArray previous = (COSArray) tokens.get(j - 1);
                        for (int k = 0; k < previous.size(); k++) {
                            Object arrElement = previous.getObject(k);
                            if (arrElement instanceof COSString) {
                                COSString cosString = (COSString) arrElement;
                                String string = cosString.getString();

                                if (j == prej) {
                                    pstring += string;
                                } else {
                                    prej = j;
                                    pstring = string;
                                }
                            }
                        }


                        if (searchString.equals(pstring.trim())) {
                            COSString cosString2 = (COSString) previous.getObject(0);
                            cosString2.setValue(replacement.getBytes());

                            int total = previous.size() - 1;
                            for (int k = total; k > 0; k--) {
                                previous.remove(k);
                            }
                        }
                    }
                }
            }

            // now that the tokens are updated we will replace the page content stream.
            PDStream updatedStream = new PDStream(document);
            OutputStream out = updatedStream.createOutputStream(COSName.FLATE_DECODE);
            ContentStreamWriter tokenWriter = new ContentStreamWriter(out);
            tokenWriter.writeTokens(tokens);
            out.close();
            page.setContents(updatedStream);
        }

    }


}