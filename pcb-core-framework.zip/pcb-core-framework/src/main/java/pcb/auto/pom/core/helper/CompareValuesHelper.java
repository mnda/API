package pcb.auto.pom.core.helper;

import com.hp.lft.report.Status;
import org.testng.asserts.SoftAssert;

import java.util.HashMap;
import java.util.List;

public class CompareValuesHelper {


    public static String result;

    public static SoftAssert compareHashAndList(HashMap<String, String> hashValues, List<List<String>> expected) throws Exception {
        Log.debug("Hash Values:\n" + hashValues);
        SoftAssert softAssert = new SoftAssert();
        String expectedResult, actualResult, resultTemp, column;
        for (int i = 0; i < expected.get(0).size(); i++) {
            column = expected.get(0).get(i);
            expectedResult = expected.get(1).get(i);
            actualResult = hashValues.get(column + "1");
            resultTemp = compareExpectedAndActual(expectedResult, actualResult, column);
            softAssert.assertFalse(resultTemp.toLowerCase().contains("failed"), resultTemp);
        }

        return softAssert;
    }

    private static String compareExpectedAndActual(String value1, String value2, String column) throws Exception {
        result = "";
        if (value1 == null) {
            value1 = "";
        }
        if (value2 == null) {
            value1 = "";
        }
        if (!value1.trim().equals(value2.trim())) {
            result = result + "FAILED|Key:" + column + " - Expected:" + value1 + "|Actual:" + value2 + "\n";
            Log.info("FAILED: Comparing " + column + "\n Expected:" + value1 + "\n Actual:" + value2, Status.Failed);
        } else {
            Log.info("PASSED: Comparing " + column + "\n Expected:" + value1 + "\n Actual:" + value2, Status.Passed);
        }
        return result;
    }

    public static String compareValues(String description, String value1, String value2) throws Exception {
        result = "";
        if (value1 == null) {
            value1 = "";
        }
        if (value2 == null) {
            value1 = "";
        }
        if (!value1.trim().equals(value2.trim())) {
            result = result + "FAILED|Expected:" + value1 + "|Actual:" + value2 + "\n";
        }
        Log.reportStatus(description, value1, value2);

        return result;
    }
}