package pcb.auto.pom.core.windows.internal.textobject;

import com.hp.lft.sdk.insight.InsightObject;
import pcb.auto.pom.core.windows.TextIdAutomationObject;

import java.awt.*;

/**
 * Created by angmark on 12/5/2017.
 */
public class TextObject {

    public static TextIdAutomationObject[] setTextIdAutomationObject(String fieldName, Rectangle rect) {
        TextIdAutomationObject[] textIdAutomationObject = new TextIdAutomationObject[2];
        textIdAutomationObject[0] = new TextIdAutomationObject();
        textIdAutomationObject[0].setID(fieldName);
        textIdAutomationObject[1] = new TextIdAutomationObject();
        textIdAutomationObject[1].setRectangle(rect);
        return textIdAutomationObject;
    }

    public static TextIdAutomationObject[] setTextIdAutomationObject(String fieldName, Rectangle rect, InsightObject insightObject) {
        TextIdAutomationObject[] textIdAutomationObject = new TextIdAutomationObject[3];
        textIdAutomationObject[0] = new TextIdAutomationObject();
        textIdAutomationObject[0].setID(fieldName);
        textIdAutomationObject[1] = new TextIdAutomationObject();
        textIdAutomationObject[1].setRectangle(rect);
        textIdAutomationObject[2] = new TextIdAutomationObject();
        textIdAutomationObject[2].setInsightObject(insightObject);
        return textIdAutomationObject;
    }

}

