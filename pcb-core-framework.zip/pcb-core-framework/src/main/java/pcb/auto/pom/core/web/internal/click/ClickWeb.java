package pcb.auto.pom.core.web.internal.click;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.Button;
import com.hp.lft.sdk.web.Image;
import com.hp.lft.sdk.web.Link;
import pcb.auto.pom.core.helper.Log;

/**
 * Created by angmark on 12/5/2017.
 */
public class ClickWeb {
    private static int clickGlobalWait = 10000;

    public static void click(Button button) throws GeneralLeanFtException {
        Log.info("Click " + button.getText().trim() + " button");
        button.click();
    }

    public static void click(Link link) throws GeneralLeanFtException {
        Log.info("Click " + link.getName().trim() + " link");
        link.click();
    }

    public static void click(Image image) throws GeneralLeanFtException {
        try {
            Log.info("Click " + image.getAttribute("alt").trim() + " image");
        } catch (GeneralLeanFtException e) {
            Log.info("Click " + image.getName().trim() + " image");
        }
        image.click();
    }
}

