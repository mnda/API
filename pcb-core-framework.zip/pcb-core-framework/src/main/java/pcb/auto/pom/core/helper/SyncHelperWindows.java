package pcb.auto.pom.core.helper;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.Keys;
import com.hp.lft.sdk.Mouse;
import com.hp.lft.sdk.insight.InsightObject;
import com.hp.lft.sdk.stdwin.EditField;
import com.hp.lft.sdk.stdwin.ListBox;
import com.hp.lft.sdk.winforms.Window;
import org.apache.commons.lang.exception.ExceptionUtils;
import pcb.auto.pom.core.windows.TextIdAutomationObject;

import java.awt.*;

/**
 * Created by angmark on 5/29/2017.
 */
public class SyncHelperWindows {
    private static int globalWait = 10000;

    public SyncHelperWindows(int millis) {
        globalWait = millis;
    }

    public SyncHelperWindows() {
    }


    public static void waitForPageToAppear(com.hp.lft.sdk.stdwin.Window window) {
        int counter = 0;
        boolean exist = false;
        while (!exist) {
            try {
                exist = window.exists(1);
                Log.debug("Waiting for window to appear... Time elapsed: " + counter + " second/s");
                explicitWait(1000);
                if (counter > globalWait / 1000) {
                    logIfNotFound(counter, "Window");
                    break;
                } else {
                    counter++;
                }
            } catch (Exception e) {
                Log.error(ExceptionUtils.getStackTrace(e));
            }
        }
    }


    public static void waitForPageToAppear(com.hp.lft.sdk.stdwin.Dialog dialog) {
        int counter = 0;
        boolean exist = false;
        while (!exist) {
            try {
                exist = dialog.exists(1);
                Log.debug("Waiting for window to appear... Time elapsed: " + counter + " second/s");
                explicitWait(1000);
                if (counter > globalWait / 1000) {
                    logIfNotFound(counter, "Window");
                    break;
                } else {
                    counter++;
                }
            } catch (Exception e) {
                Log.error(ExceptionUtils.getStackTrace(e));
            }
        }
    }

    public static void waitForElementToAppear(com.hp.lft.sdk.stdwin.Button button) {
        int counter = 0;
        boolean exist = false;
        while (!exist) {
            try {
                exist = button.exists(1);
                Log.debug("Waiting for button to appear... Time elapsed: " + counter + " second/s");
                explicitWait(1000);
                if (counter > globalWait / 1000) {
                    logIfNotFound(counter, "Button");
                    break;
                } else {
                    counter++;
                }
            } catch (Exception e) {
                Log.error(ExceptionUtils.getStackTrace(e));
            }
        }
    }

    public static void waitForElementToAppear(ListBox listBox) {
        int counter = 0;
        boolean exist = false;
        while (!exist) {
            try {
                exist = listBox.exists(1);
                Log.debug("Waiting for listBox to appear... Time elapsed: " + counter + " second/s");
                explicitWait(1000);
                if (counter > globalWait / 1000) {
                    logIfNotFound(counter, "ListBox");
                    break;
                } else {
                    counter++;
                }
            } catch (Exception e) {
                Log.error(ExceptionUtils.getStackTrace(e));
            }
        }
    }


    public static void waitForElementToAppear(EditField editField) {
        int counter = 0;
        boolean exist = false;
        while (!exist) {
            try {
                exist = editField.exists(1);
                Log.debug("Waiting for listBox to appear... Time elapsed: " + counter + " second/s");
                explicitWait(1000);
                if (counter > globalWait / 1000) {
                    logIfNotFound(counter, "EditField");
                    break;
                } else {
                    counter++;
                }
            } catch (Exception e) {
                Log.error(ExceptionUtils.getStackTrace(e));
            }
        }
    }
    //********************************* old ***************************************//
    @Deprecated
    public static Boolean waitForInsightObjectToAppear(InsightObject insightObject) {
        try {
            int flag = 0;
            int timer = 0;
            while (timer < globalWait / 1000) {
                if (insightObject.exists(1)) {
                    flag = 1;
                    break;
                }
                timer++;
            }
            if (flag == 1) {
                Log.debug("WindowUtils object " + insightObject.toString() + "found");
                return true;
            } else {
                Log.debug("Insight object " + insightObject.toString() + "does not exists");
                return false;
            }
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static Boolean waitForWindowToAppear(Window window) {
        try {
            int flag = 0;
            int timer = 0;
            while (timer < globalWait / 1000) {
                Log.debug("Waiting for window " + window.toString() + " to appear...");
                if (window.exists(1)) {
                    flag = 1;
                    break;
                }
                timer++;
            }
            if (flag == 1) {
                Log.debug("WindowUtils object " + window.toString() + "found");
                return true;
            } else {
                Log.debug("WindowUtils object " + window.toString() + "does not exists");
                return false;
            }
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static void explicitWait(int milliseconds) throws InterruptedException {
        Thread.sleep(milliseconds);
    }

    public static Rectangle[] waitForTextToBePresent(Window window, TextIdAutomationObject[] textIdAutomationObjects) {
        try {
            Rectangle[] r = window.getTextLocations(textIdAutomationObjects[0].getID(), textIdAutomationObjects[1].getRectangle());
            Log.debug("Waiting for textidautomationobject " + textIdAutomationObjects[0].getID() + " to appear using default global wait time");
            int waitTime = 0;
            while (r == null && waitTime < globalWait) {
                r = window.getTextLocations(textIdAutomationObjects[0].getID(), textIdAutomationObjects[1].getRectangle());
                waitTime = waitTime + 1000;
                explicitWait(1000);
            }
            if (r == null) {
                throw new RuntimeException("Text " + textIdAutomationObjects[0].getID() + " was not found in the window");
            }
            return r;
        } catch (Exception e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static Rectangle[] waitForTextToBePresent(Window window, String text, Rectangle rect) {
        try {
            Rectangle[] r = window.getTextLocations(text, rect);
            Log.debug("Waiting for textidautomationobject " + text + " to appear using default global wait time");
            int waitTime = 0;
            while (r == null && waitTime < globalWait) {
                r = window.getTextLocations(text, rect);
                waitTime = waitTime + 1000;
                explicitWait(1000);
            }
            if (r == null) {
                throw new RuntimeException("Text " + text + " was not found in the window");
            }
            return r;
        } catch (Exception e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static Rectangle[] waitForTextToBePresent(Window window, String text, int millis) {
        try {
            Rectangle[] r = window.getTextLocations(text);
            Log.debug("Waiting for text " + text + " to appear until " + millis + " milliseconds");
            int waitTime = 0;
            while (r == null && waitTime < millis) {
                r = window.getTextLocations(text);
                waitTime = waitTime + 1000;
                explicitWait(1000);
            }
            if (r == null) {
                throw new RuntimeException("Text " + text + " was not found in the window");
            }
            return r;
        } catch (Exception e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static Rectangle[] waitForTextToBePresent(Window window, TextIdAutomationObject[] textIdAutomationObjects, int millis) {
        try {
            Rectangle[] r = window.getTextLocations(textIdAutomationObjects[0].getID(), textIdAutomationObjects[1].getRectangle());
            Log.debug("Waiting for textidautomationobject " + textIdAutomationObjects[0].getID() + " to appear until " + millis);
            int waitTime = 0;
            while (r == null && waitTime < millis) {
                r = window.getTextLocations(textIdAutomationObjects[0].getID(), textIdAutomationObjects[1].getRectangle());
                waitTime = waitTime + 1000;
            }
            if (r == null) {
                throw new RuntimeException("Text " + textIdAutomationObjects[0].getID() + " was not found in the window");
            }
            return r;
        } catch (GeneralLeanFtException e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static Rectangle[] waitForTextToBePresentWithScrolling(Window window, TextIdAutomationObject[] textIdAutomationObjects) {
        try {
            Rectangle[] r = window.getTextLocations(textIdAutomationObjects[0].getID(), textIdAutomationObjects[1].getRectangle());
            Log.debug("Waiting for textidautomationobject " + textIdAutomationObjects[0].getID() + " to appear using default global wait time");
            int waitTime = 0;
            window.sendKeys(Keys.HOME);
            while (r == null && waitTime < globalWait) {
                waitTime = waitTime + 1000;
                window.sendKeys(Keys.PAGE_DOWN);
                explicitWait(1000);
                r = window.getTextLocations(textIdAutomationObjects[0].getID(), textIdAutomationObjects[1].getRectangle());
            }
            if (r == null) {
                throw new RuntimeException("Text " + textIdAutomationObjects[0].getID() + " was not found in the window");
            }
            return r;
        } catch (Exception e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static Rectangle[] waitForTextToBePresentWithScrolling(Window window, TextIdAutomationObject[] textIdAutomationObjects, int millis) {
        try {
            Rectangle[] r = window.getTextLocations(textIdAutomationObjects[0].getID(), textIdAutomationObjects[1].getRectangle());
            Log.debug("Waiting for textidautomationobject " + textIdAutomationObjects[0].getID() + " to appear using default global wait time");
            int waitTime = 0;
            window.sendKeys(Keys.HOME);
            while (r == null && waitTime < globalWait) {
                r = window.getTextLocations(textIdAutomationObjects[0].getID(), textIdAutomationObjects[1].getRectangle());
                waitTime = waitTime + 1000;
                window.sendKeys(Keys.PAGE_DOWN);
                explicitWait(millis);
            }
            if (r == null) {
                throw new RuntimeException("Text " + textIdAutomationObjects[0].getID() + " was not found in the window");
            }
            return r;
        } catch (Exception e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    public static InsightObject waitForTextToBePresentWithScrolling(Window window, InsightObject insightObject, Rectangle rect, int millis) {
        try {
            window.sendKeys(Keys.HOME);
            int waitTime = 0;
            int flag = 0;
            int xCoord = (int) (rect.getX()) + 20;
            int yCoord = (int) (rect.getY());

            while (waitTime < millis) {
                Mouse.move(new Point(xCoord, yCoord));
                Mouse.click(new Point(xCoord, yCoord));
                if (insightObject.exists(1)) {
                    flag = 1;
                    break;
                }
                waitTime = waitTime + 1000;
                //window.sendKeys(Keys.PAGE_DOWN);
                explicitWait(1000);
            }
            if (flag == 0) {
                throw new RuntimeException("Insight " + insightObject + " was not found in the window");
            }
            return insightObject;
        } catch (Exception e) {
            Log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }


    public static void waitUntilVWindowIsEnabled(Window window, int waitMillis) {
        try {
            int timer = 0;
            while (!window.isEnabled() && timer < waitMillis) {
                Log.debug("Waiting until window is enabled - time elapsed: " + timer / 1000 + " seconds.");
                explicitWait(1000);
                timer = timer + 1000;
            }
            explicitWait(2000);
        } catch (Exception e) {
            Log.error(ExceptionUtils.getStackTrace(e));
        }
    }


    private static void logIfNotFound(int counter, String object) {
        Log.error("Waiting for element " + object + " to appear failed: " + object + " not found");
    }
}