package pcb.auto.pom.core.windows.internal.set;

import com.hp.lft.sdk.ClickArgs;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.Keys;
import com.hp.lft.sdk.insight.InsightObject;
import com.hp.lft.sdk.stdwin.EditField;
import com.hp.lft.sdk.stdwin.ListBox;
import com.hp.lft.sdk.winforms.Window;
import org.sikuli.script.App;
import org.sikuli.script.Key;
import org.sikuli.script.Region;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWindows;
import pcb.auto.pom.core.windows.CoreFrameworkWindows;
import pcb.auto.pom.core.windows.TextIdAutomationObject;
import pcb.auto.pom.core.windows.internal.click.ClickArgsUtilsWindows;
import pcb.auto.pom.core.windows.internal.click.ClickWindows;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.IOException;

/**
 * Created by angmark on 12/5/2017.
 */
public class SetWindows {

    public static void set(ListBox listBox, String value) throws GeneralLeanFtException {
        Log.info("Setting " + listBox.getAttachedText() + " listbox field to " + value);
        listBox.sendKeys(value);
    }

    public static void set(EditField editField, String value) throws GeneralLeanFtException {
        Log.info("Setting " + editField.getAttachedText() + " editField field to " + value);
        editField.sendKeys(value);
    }

    public static void setPassword(EditField editField, String value) throws GeneralLeanFtException {
        Log.info("Setting " + editField.getAttachedText() + " password editField field");
        editField.sendKeys(value);
    }


    // *****************************  OLD Functions ***************************//
    public static void setValueForInsightObject(Window parent, InsightObject insightObject, String value, int x, int y) throws IOException, GeneralLeanFtException, InterruptedException {
        insightObject.click(ClickArgsUtilsWindows.offSetClick(x, y));
        //clear values first
        SyncHelperWindows.explicitWait(1000);
        parent.sendKeys(Keys.BACKSPACE);
        parent.sendKeys(value);
        parent.sendKeys(Keys.TAB);
        parent.sendKeys(Keys.ESC);
    }

    public static void fillOutField(Window window, TextIdAutomationObject[] textIdAutomationObjects, String value, int actualFieldX, int ActualFieldY) throws Throwable {
        String fieldName = textIdAutomationObjects[0].getID();
        if (!value.toLowerCase().contains("no change")) {
            Rectangle[] rect2 = SyncHelperWindows.waitForTextToBePresent(window, textIdAutomationObjects);
            Rectangle rect = textIdAutomationObjects[1].getRectangle();
            Log.step("Filling out " + fieldName + " with value:" + value);
            ClickWindows.clickText(window, fieldName, actualFieldX, ActualFieldY, rect2, rect);
            sikuliClearField(window);
            sikuliSendString(window, value);
            sikuliSendString(window, Key.TAB);
        } else {
            Log.info("Skipping field " + fieldName + " because value contains \"no change\"");
        }
    }

    public static void fillOutFieldUsingSikuli(Window window, TextIdAutomationObject[] textIdAutomationObjects, String value, int actualFieldX, int ActualFieldY) throws Throwable {
        String fieldName = textIdAutomationObjects[0].getID();
        if (!value.toLowerCase().contains("no change")) {
            Rectangle[] rect2 = SyncHelperWindows.waitForTextToBePresent(window, textIdAutomationObjects);
            Rectangle rect = textIdAutomationObjects[1].getRectangle();
            Log.step("Filling out " + fieldName + " with value:" + value);
            ClickWindows.clickUsingTextSikuli(window, fieldName, actualFieldX, ActualFieldY, rect);
            sikuliClearField(window);
            sikuliSendString(window, value);
            sikuliSendString(window, Key.TAB);
        } else {
            Log.info("Skipping field " + fieldName + " because value contains \"no change\"");
        }
    }

    public static void fillOutFieldTIAO(Window window, TextIdAutomationObject[] textIdAutomationObject, String value, int actualFieldX, int actualFieldY) throws Throwable {
        try {
            //defaults to tst
            if (System.getProperty("testMachine").toLowerCase().equals("vm")) {
                try {
                    Log.debug("Trying with text id automation object");
                    fillOutFieldUsingSikuli(window, textIdAutomationObject, value, actualFieldX, actualFieldY);
                } catch (Exception e) {
                    Log.debug("Text ID failed, Trying with insight object first");
                    textIdAutomationObject[2].getInsightObject().clickSpecial(CoreFrameworkWindows.offSetClick(actualFieldX, actualFieldY));
                    sikuliClearField(window);
                    sikuliSendString(window, value);
                }
            } else {
                try {
                    Log.debug("Trying with insight object first");
                    textIdAutomationObject[2].getInsightObject().clickSpecial(CoreFrameworkWindows.offSetClick(actualFieldX, actualFieldY));
                    sikuliClearField(window);
                    sikuliSendString(window, value);
                } catch (Exception l) {
                    Log.debug("Insight object failed, trying with text id automation object");
                    fillOutField(window, textIdAutomationObject, value, actualFieldX, actualFieldY);
                }
            }
        } catch (Exception e) {
            try {
                Log.debug("Trying with insight object first");
                textIdAutomationObject[2].getInsightObject().clickSpecial(CoreFrameworkWindows.offSetClick(actualFieldX, actualFieldY));

                sikuliClearField(window);
                sikuliSendString(window, value);
            } catch (Exception l) {
                Log.debug("Insight object failed, trying with text id automation object");
                fillOutField(window, textIdAutomationObject, value, actualFieldX, actualFieldY);
            }
        }
    }


    public static void sikuliSendString(Window window, String value) throws Throwable {
        App app = App.focus(window.getWindowTitleRegExp());
        Region region = app.window();
        if (value.equals("\t")) {
            Log.debug("Sikuli is pressing tab in the window " + window.getWindowTitleRegExp());
        } else {
            Log.debug("Sikuli is typing " + value + " in the window " + window.getWindowTitleRegExp());
        }
        Log.step("Setting value to " + value);
        region.type(value);
    }

    public static void sikuliSendString(Window window, String value, int modifiers) throws Throwable {
        App app = App.focus(window.getWindowTitleRegExp());
        Region region = app.window();
        Log.debug("Sikuli is typing " + value + " in the window " + window.getWindowTitleRegExp());
        Log.step("Setting value to " + value);
        region.type(value, modifiers);
    }

    public static void sikuliClearField(Window window) throws Throwable {
        App app = App.focus(window.getWindowTitleRegExp());
        Region region = app.window();
        window.sendKeys(Keys.BACKSPACE);
        region.type(Key.HOME);
        for (int i = 0; i < 50; i++) {
            region.type(Key.DELETE);
        }
    }

    public static void clearField(InsightObject insightObject) throws Exception {
        insightObject.click();
        Robot robot = new Robot();
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_A);
        robot.keyRelease(KeyEvent.VK_A);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_BACK_SPACE);
    }

    public static void clearField(InsightObject insightObject, ClickArgs clickArgs) throws Exception {
        insightObject.clickSpecial(clickArgs);
        Robot robot = new Robot();
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_A);
        robot.keyRelease(KeyEvent.VK_A);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_BACK_SPACE);
    }

}

