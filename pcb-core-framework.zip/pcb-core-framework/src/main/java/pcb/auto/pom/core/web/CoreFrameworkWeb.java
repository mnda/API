package pcb.auto.pom.core.web;

import com.hp.lft.report.Reporter;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.ModifiableSDKConfiguration;
import com.hp.lft.sdk.SDK;
import com.hp.lft.sdk.web.*;
import org.apache.commons.lang.exception.ExceptionUtils;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.web.internal.click.ClickWeb;
import pcb.auto.pom.core.web.internal.set.SetWeb;

import java.net.URI;


/**
 * Created by angmark on 5/29/2017.
 */
public class CoreFrameworkWeb {

    private CoreFrameworkWeb() {

    }

    //Instantiate Framework
    public static void instantiateSDK() {
        try {
            ModifiableSDKConfiguration config = new ModifiableSDKConfiguration();
            config.setServerAddress(new URI("ws://localhost:5095"));
            SDK.init(config);
            Reporter.init();
        } catch (Exception e) {
            Log.error(ExceptionUtils.getStackTrace(e));
        }
    }

    public static void cleanupSDK() {
        try {
            SDK.cleanup();
        } catch (Exception e) {
            Log.error(ExceptionUtils.getStackTrace(e));
        }
    }

    // **** Click events *****//
    public static void click(Button button) throws GeneralLeanFtException {
        ClickWeb.click(button);
    }

    public static void click(Link link) throws GeneralLeanFtException {
        ClickWeb.click(link);
    }

    public static void click(Image image) throws GeneralLeanFtException {
        ClickWeb.click(image);
    }

    // **** Set events *****//

    public static void set(EditField editField, String value) throws GeneralLeanFtException {
        SetWeb.set(editField, value);
    }

    public static void setPassword(EditField editField, String value) throws GeneralLeanFtException {
        SetWeb.setPassword(editField, value);
    }

    public static void set(RadioGroup radioGroup, String value) throws GeneralLeanFtException {
        SetWeb.set(radioGroup, value);
    }

    public static void set(RadioGroup radioGroup, int index) throws GeneralLeanFtException {
        SetWeb.set(radioGroup, index);
    }

    public static void set(ListBox listBox, String value) throws GeneralLeanFtException {
        SetWeb.set(listBox, value);
    }

    public static void set(ListBox listBox, int index) throws GeneralLeanFtException {
        SetWeb.set(listBox, index);
    }


    public static void set(CheckBox checkBox, String bool) throws GeneralLeanFtException {
        SetWeb.set(checkBox, bool);
    }
}

