package pcb.auto.pom.core.helper;

/**
 * Created by angmark on 2/5/2018.
 */

import com.hp.lft.report.Status;
import cucumber.api.Scenario;
import org.testng.asserts.SoftAssert;

public class Report {

    private static Scenario logScenario;
    public static SoftAssert sa = new SoftAssert();

    public static void reportStatus(String validationMessage, String expected, String actual, boolean contains, boolean softAssert) {
        if (expected == null) {
            expected = "null";
        }
        if (actual == null) {
            actual = "null";
        }
        if (contains) {
            if (expected.trim().contains(actual) || actual.trim().contains(expected)) {
                validationMessage = "PASSED: " + validationMessage + "\n Expected:" + expected + "\n Actual:" + actual;
                Log.info(validationMessage, Status.Passed);
            } else {
                validationMessage = validationMessage + "\n Expected:" + expected + "\n Actual:" + actual;
                if (softAssert) {
                    Log.info("FAILED: " + validationMessage, Status.Failed);
                } else {
                    Log.error("FAILED: " + validationMessage);
                }
                sa.fail("FAILED: " + validationMessage);
            }
        } else {
            if (expected.trim().equals(actual.trim())) {
                validationMessage = "PASSED: " + validationMessage + "\n Expected:" + expected + "\n Actual:" + actual;
                Log.info(validationMessage, Status.Passed);
            } else {
                validationMessage = validationMessage + "\n Expected:" + expected + "\n Actual:" + actual;
                if (softAssert) {
                    Log.info("FAILED: " + validationMessage, Status.Failed);
                } else {
                    Log.error("FAILED: " + validationMessage);
                }
                sa.fail("FAILED: " + validationMessage);
            }
        }
    }

    public static void reportStatusThenExit(String message) {
        Log.error(message);
    }
}