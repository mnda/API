import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class InstaMessenger {
    public static URL url;
    public static DesiredCapabilities capabilities;
    public static AndroidDriver<MobileElement> driver;

    //1
    @BeforeSuite
    public void setupAppium() throws MalformedURLException {
        //2
        final String URL_STRING = "http://192.168.2.12:4444/wd/hub";
        url = new URL(URL_STRING);
//3
        capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Device");
        //capabilities.setCapability(MobileCapabilityType.APP, "https://github.com/afollestad/material-dialogs/raw/master/sample/sample.apk");
        capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
        //capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator");
        capabilities.setCapability("appPackage", "com.instagram.android");
        capabilities.setCapability("appActivity", "com.instagram.android.activity.MainTabActivity");

        //4
        driver = new AndroidDriver<MobileElement>(url, capabilities);
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        //driver.resetApp();
    }

    //5
    @AfterSuite
    public void uninstallApp() throws InterruptedException {
        //driver.removeApp("com.example.android.contactmanager");
    }

    //6
    @Test(enabled = true)
    public void myFirstTest() throws InterruptedException {
        //run every 2 hours
        //for (int x = 0; x < 12; x++) {
        System.out.println("Starting run... Again.");
        ((AndroidDriver) driver).unlockDevice();
        driver.launchApp();

        String message = readFile("src/test/message.txt");
        driver.findElementByAccessibilityId("Profile").click();
        driver.findElementById("row_profile_header_textview_followers_title").click();
        //get usernames of followers
        List<MobileElement> elements = driver.findElementsByXPath("//android.widget.LinearLayout/android.widget.TextView[@resource-id='com.instagram.android:id/follow_list_username']");

        boolean foundLast = false;

        //getting lastusername
        String lastUser = readFile("src/test/lastUser.csv").trim();
        String allUsers = readFile("src/test/alreadySent.csv").trim();

        String userNameList = "";
        int counter = 0;


        //Get all users who I haven't sent any message
        while (!foundLast && counter < 20) {
            //try catch when something is messed up
            try {
                for (int i = 0; i < elements.size(); i++) {
                    String userName = elements.get(i).getText();
                    if (userName.trim().equalsIgnoreCase(lastUser)) {
                        foundLast = true;
                        System.out.println("Found " + lastUser);
                        break;
                    }
                    if (!(userName.toLowerCase().contains("follow")) && !(userName.toLowerCase().contains(" "))
                            && !(allUsers.toLowerCase().contains(userName.toLowerCase()))) {
                        if (!(userNameList.contains(userName))) {
                            System.out.println("Adding " + userName + " to the list");
                            userNameList = userNameList + "," + userName;
                        }
                    }
                }
            } catch (Exception e) {

            }
            if (driver.getPageSource().toLowerCase().contains(lastUser)) {
                System.out.println("Last user " + lastUser + " found!");
                break;
            }
            if (foundLast) {
                break;
            }
            //Scroll down
            System.out.println("Last user " + lastUser + " not found, scrolling down");
            scrollDown();
            driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
            elements = driver.findElementsByXPath("//android.widget.LinearLayout/android.widget.TextView[@resource-id='com.instagram.android:id/follow_list_username'][1]");
            counter++;
        }

        //split all users
        //userNameList = ",lizziesalvacion,nourmawood,merceeymerceey,athena.domonique,oliveborn.doodles,garimagrover601,jadelson29,jadelson29,mdriponalisadia,bxtchlasgna,verunasista,fhyared1,yubeelai,robwhyte11,danitza_mayerli,mikojalover,mpng.store,destination.travels.116,maryhelen701,two_lates_bullet,justkande.nyquole,terryownsyou,foluwasanmi,foluwasanmi,nikki_insigne,oulynneb,itsprinceofficialraipur,ilovepenongs,jazzynikki_b,micaela_jane_diego_,cherylsavino,Gemful1,taubergary,mcclendon70,jujugrinds3,hanifbaharuni,lolatv7,sarapauletteo,selfempower,lucky_famille,_mrl_15,tinaaaay23,Joseph,LynJai,dzanmark,Jason\uD83C\uDF35,thegratefula,laurel_calla,mck_transportes,damnyouderrick,lyviasant_anna,enough_ky,natdamiani,oo_23_111_,p.n.r,Hlekani_Manganye,maria,Samson,AlanKhouizTheName_,سَٰلُْطّْٱنٰٰۛۿۿہ,سَٰلُْطّْٱنٰٰۛۿۿہ,\uD835\uDE8A\uD835\uDE97\uD835\uDE8Dя\uD835\uDE8E\uD835\uDEA0,Justaman,thomson.sheree,dude1man2,gelo_mac20";
        String[] arUser = userNameList.split(",");
        counter = 0;
        //reverser looping
        for (int i = arUser.length - 1; i >= 1; i--) {
            //limit to 10 message per batch
            if (counter < 40) {
                if (driver.findElementByAccessibilityId("Search and explore").isDisplayed()) {
                    driver.findElementByAccessibilityId("Search and explore").click();
                } else {
                    driver.navigate().back();
                    driver.findElementByAccessibilityId("Search and explore").click();
                }
                try {
                    driver.findElementById("action_bar_search_edit_text").setValue(arUser[i]);
                    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                    driver.findElementByXPath("//android.widget.LinearLayout/android.widget.TextView[@instance=0]").click();


                    //like at least one photo if existing
                    try {
                        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
                        driver.findElementByXPath("//androidx.recyclerview.widget.RecyclerView/android.widget.LinearLayout/android.widget.ImageView[1]").click();
                        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
                        driver.findElementById("row_feed_button_like").click();
                        System.out.println("Liked one image for " + arUser[i]);
                        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
                        driver.navigate().back();
                        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

                    } catch (Exception e) {
                        if (!driver.findElementByAccessibilityId("Options").isDisplayed()) {
                            driver.navigate().back();
                        }
                        System.out.println("No image for " + arUser[i]);
                    }

                    //click send message
                    driver.findElementByAccessibilityId("Options").click();
                    driver.findElementByXPath("//android.widget.TextView[@text='Send Message']").click();

                    //send a message
                    driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
                    String newMessage = message.replace("REPLACETHIS", arUser[i]);

                    System.out.println("Sending message to:" + arUser[i]);
                    enterTextMethod(driver.findElementById("row_thread_composer_edittext"), newMessage);
                    driver.findElementById("row_thread_composer_button_send").click();

                    //write first username
                    try {
                        // append = false
                        FileWriter fw = new FileWriter("src/test/lastUser.csv", false);
                        fw.write(arUser[i]);
                        fw.close();

                        // append = false
                        System.out.println("Adding " + arUser[i] + " to All Users Sent");
                        FileWriter fw2 = new FileWriter("src/test/alreadySent.csv", true);
                        fw2.write(arUser[i] + ",");
                        fw2.close();

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    driver.navigate().back();
                    driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
                    driver.navigate().back();
                    driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
                    driver.navigate().back();

                    //} else {
                    //    System.out.println("Already sent message to " + arUser[0]);
                    //}
                } catch (Exception e) {

                }
            } else {
                break;
            }
            counter++;

        }
        System.out.println("******************************************************************************");
        System.out.println("Total messages sent:" + counter);
        System.out.println("******************************************************************************");
        ((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.KEYCODE_POWER);
        //driver.manage().timeouts().implicitlyWait(2, TimeUnit.HOURS);
        //}

    }

    private void scrollDown() {
        //if pressX was zero it didn't work for me
        int pressX = driver.manage().window().getSize().width / 2;
        // 4/5 of the screen as the bottom finger-press point
        int bottomY = driver.manage().window().getSize().height * 4 / 5;
        // just non zero point, as it didn't scroll to zero normally
        int topY = driver.manage().window().getSize().height / 8;
        //scroll with TouchAction by itself
        scroll(pressX, bottomY, pressX, topY);
    }

    /*
     * don't forget that it's "natural scroll" where
     * fromY is the point where you press the and toY where you release it
     */
    private void scroll(int fromX, int fromY, int toX, int toY) {
        TouchAction touchAction = new TouchAction(driver);
        touchAction.longPress(PointOption.point(fromX, fromY)).moveTo(PointOption.point(toX, toY)).release().perform();
    }

    private String readFile(String fileName) {
        String line = "";
        String line2 = "";
        try {
            File file = new File(fileName);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            while ((line = br.readLine()) != null) {
                System.out.println("line Read:" + line);
                line2 = line2 + line + "\n";
            }
        } catch (Exception e) {

        }
        return line2;
    }


    private void enterTextMethod(MobileElement element, String inputText) {
        element.click();
        String[] splitS = inputText.split("\n");
        for (int i = 0; i < splitS.length; i++) {
            element.setValue(splitS[i]);
            driver.pressKeyCode(AndroidKeyCode.KEYCODE_NUMPAD_ENTER);
            driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
            driver.pressKeyCode(AndroidKeyCode.KEYCODE_NUMPAD_ENTER);
            driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
            driver.pressKeyCode(AndroidKeyCode.KEYCODE_NUMPAD_ENTER);
            driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        }
    }

}
