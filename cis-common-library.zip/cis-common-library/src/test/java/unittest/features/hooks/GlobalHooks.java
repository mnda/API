package unittest.features.hooks;


import com.hp.lft.report.ModifiableReportConfiguration;
import com.hp.lft.report.ReportConfigurationFactory;
import com.hp.lft.report.Reporter;
import com.hp.lft.sdk.ModifiableSDKConfiguration;
import com.hp.lft.sdk.SDK;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.unittesting.UnitTestClassBaseTestNG;

import java.io.IOException;

public class GlobalHooks extends UnitTestClassBaseTestNG {


    @Before
    public void InitializeTest(Scenario scenario) throws Exception {
        //       if (!scenario.getId().contains("tranhub")) {
        Log.startTestCase(scenario);
        suiteSetup();
        System.setProperty("logDebug", "true");
        SDK.init(new ModifiableSDKConfiguration());
        Reporter.init(getReportConfiguration());
    }

    @After
    public void TearDownTest(Scenario scenario) throws Exception {
        if (scenario.isFailed()) {
            Log.takeScreenshotWindows(scenario);
        }
        Reporter.generateReport();
        suiteTearDown();
    }


    protected ModifiableReportConfiguration getReportConfiguration() throws IOException {
        ModifiableReportConfiguration reportConfig = ReportConfigurationFactory.createDefaultReportConfiguration();
        reportConfig.setTargetDirectory("c:\\Reports"); // The folder must exist under C:\
        reportConfig.setReportFolder("LeanFtJUnitExample");
        reportConfig.setTitle("LeanFT TestNG Example Run Results");
        reportConfig.setDescription("Configuration settings example");
        return reportConfig;
    }

}