package unittest.features.steps;

import cis.common.library.chunks.InquiryPageChunk;
import cis.common.library.helper.CISALPHelper;
import cis.common.library.pages.*;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.testng.asserts.SoftAssert;

import java.util.HashMap;
import java.util.List;

/**
 * Created by angmark on 6/12/2017.
 */
public class UnitTestStepsDefinition {
    private static Scenario myScenario;
    private ALPPage alpPage;
    private CISPage cisPage;
    private AccessLimitsChangePage accessLimitsChangePage;
    private AccessLimitsMaintenancePage accessLimitsMaintenancePage;
    private AccessLimitChangeDialogsPage accessLimitChangeDialogsPage;
    private InquiryPage inquiryPage;
    private InquiryPageChunk inquiryPageChunk;
    private SoftAssert softAssert = new SoftAssert();

    @Before
    public void InitializeTest(Scenario scenario) throws Exception {
        myScenario = scenario;
    }

    @Given("^I launch CIS$")
    public void iLaunchCIS(DataTable table) throws Throwable {
        List<List<String>> data = table.raw();
        alpPage = new ALPPage();
        alpPage.launchALP(data.get(1).get(0), data.get(1).get(1));
        alpPage.navigateToSystem("cis");
    }

    @And("^I change access limit$")
    public void iChangeAccessLimitTo(DataTable table) throws Throwable {
        List<List<String>> data = table.raw();
        cisPage = new CISPage();
        cisPage.navigateToCISFunctions("accesslimitsmaintenance");
        accessLimitsMaintenancePage = new AccessLimitsMaintenancePage();
        accessLimitsMaintenancePage.searchClient(data.get(1).get(0));
        accessLimitsChangePage = new AccessLimitsChangePage();
        accessLimitsChangePage.changeLimitValues(data.get(1).get(1), data.get(1).get(2),
                data.get(1).get(3), data.get(1).get(4));
        accessLimitChangeDialogsPage = new AccessLimitChangeDialogsPage();
        accessLimitChangeDialogsPage.setTemporaryChange(data.get(1).get(5), CISALPHelper.getDateCode(data.get(1).get(6)),
                data.get(1).get(7), data.get(1).get(8));

    }


    @When("^I validate inquiry screen using details$")
    public void iValidateInquiryScreenUsingDetails(DataTable table) throws Throwable {
        List<List<String>> data = table.raw();
        cisPage = new CISPage();
        cisPage.navigateToCISFunctions("inquiry");
        inquiryPage = new InquiryPage();
        inquiryPage.inquire(data.get(1).get(0), data.get(1).get(1), data.get(1).get(2), data.get(1).get(3));
    }

    @Then("^Values for Electronic Access Limits should be$")
    public void valuesShouldBe(DataTable table) throws Throwable {
        List<List<String>> data = table.raw();
        inquiryPage = new InquiryPage();
        inquiryPageChunk = new InquiryPageChunk(inquiryPage.getMainPage());
        HashMap<String, String> actualResults = inquiryPageChunk.getElectronicAccessLimits();
        //softAssert = (CompareValuesHelper.compareHashAndList(actualResults, data));
        softAssert.assertAll();
    }

}