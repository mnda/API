package unittest.features.runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

/**
 * Created by angmark on 6/12/2017.
 */

@CucumberOptions(features = {"src/test/java/unittest/features"}, glue = {"UnitTestStepsDefinition.steps"}, format = {"json:target/cucumber.json"})
public class TestRunner extends AbstractTestNGCucumberTests{
}
