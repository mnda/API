package cis.common.library.helper;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.Table;
import com.hp.lft.sdk.web.TableCell;
import com.hp.lft.sdk.web.TableRow;
import pcb.auto.pom.core.helper.CoreFrameworkHelper;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.Report;
import pcb.auto.pom.core.helper.SyncHelperWeb;

import java.io.*;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CISALPHelper {

    public static Properties getValuesFromProperties(String propFileName) throws IOException {
        Properties prop = new Properties();
        InputStream inputStream = CISALPHelper.class.getClassLoader().getResourceAsStream(propFileName);
        if (inputStream != null) {
            prop.load(inputStream);
            return prop;
        } else {
            throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
        }
    }

    //returns the first numeric
    public static String getNumericValue(String s) {
        Pattern regex = Pattern.compile("(\\d+(?:\\,\\d+)*(?:\\.)*(\\d+)*)");
        Matcher matcher = regex.matcher(s);
        String numeric1 = "";
        if (matcher.find()) {
            Log.debug("Extracted numeric value " + matcher.group(0) + " from string " + s);
            numeric1 = matcher.group(0);
        }
        return numeric1.replace(",", "");
    }

    //returns the first numeric
    public static String stripStringWithSpecialCharacters(String s) {
        return s.replace(" ", "").replace("#", "").replace("/", "");
    }


    public static String returnValuesWithComma(String value) {
        return NumberFormat.getNumberInstance(Locale.US).format(Integer.parseInt(value));
    }

    public static String getDateCode(String dateCode) throws Exception {
        Log.debug("Decoding date input: " + dateCode);
        String date = "";
        String splitString = "";
        int daysDifference = 0;
        if (dateCode.toLowerCase().contains("today")) {
            if (dateCode.contains("-")) {
                splitString = "-";
                daysDifference = Integer.parseInt(dateCode.split(splitString)[1]);
            } else {
                splitString = "";
                daysDifference = 0;
            }

            Date currentDate = new Date();
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDateTime localDateTime = currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
            //filter weekend
            int counter = daysDifference;
            if (dateCode.contains("-")) {
                while (localDateTime.minusDays(counter).getDayOfWeek().getValue() == 6
                        || localDateTime.minusDays(counter).getDayOfWeek().getValue() == 7) {
                    Log.debug(dateTimeFormatter.format(localDateTime.minusDays(counter)) + " falls on a weekend, going one more day back");
                    counter++;
                }
                date = dateTimeFormatter.format(localDateTime.minusDays(counter));
            } else {
                date = dateTimeFormatter.format(localDateTime.minusDays(counter));
            }
        } else {
            date = dateCode;
        }
        Log.debug("returning date: " + date);
        return date;
    }

    public static void closeALP() throws Exception {
        Runtime rt = Runtime.getRuntime();
        Log.debug("Closing ALP");

        rt.exec("wmic process where name='RUAPPBAR.exe' delete");
        rt.exec("wmic process where name='RUBROWSER.exe' delete");
        rt.exec("wmic process where name='efaifmgr.exe' delete");
        rt.exec("wmic process where name='LIS.exe' delete");
        rt.exec("wmic process where name='iexplore.exe' delete");
        rt.exec("wmic process where name='chrome.exe' delete");

        SyncHelperWeb.explicitWait(2000);
    }

    public static HashMap<String, String> getWebTableContents(Table table, String tableDesc) throws GeneralLeanFtException {
        List<TableRow> tblRows = table.getRows();
        List<TableCell> tblCells1 = null;
        HashMap<String, String> tableContent = new HashMap<String, String>();
        int rowCounter = 0;
        try {
            for (int i = 1; i <= tblRows.size(); i++) {
                int flag = 0;
                tblCells1 = tblRows.get(i).getCells();
                for (int x = 0; x <= tblCells1.size() - 1; x++) {
                    String column1 = CISALPHelper.stripStringWithSpecialCharacters(tblRows.get(0).getCells().get(x).getText()).toLowerCase() + rowCounter;
                    String value1 = tblCells1.get(x).getText();
                    if (column1.length() > 1) {
                        Log.debug("UI Column: " + column1 + " was added with value: " + value1);
                        tableContent.put(column1, value1);
                    }
                    flag = 1;
                }
                if (flag == 1) {
                    rowCounter++;
                }
            }
        } catch (Exception e) {
            //place holder
        }
        if (rowCounter == 0) {
            Report.reportStatusThenExit("No records found under " + tableDesc + " Table");
        } else {
            tableContent.put("rowscount", String.valueOf(rowCounter));
            tableContent.put("colscount", String.valueOf(tblCells1.size()));
        }
        return tableContent;
    }

    public static HashMap<String, String> getWebTableContents(Table table, String tableDesc, int rows) throws GeneralLeanFtException {
        List<TableRow> tblRows = table.getRows();
        List<TableCell> tblCells1 = null;
        HashMap<String, String> tableContent = new HashMap<String, String>();
        int rowCounter = 0;
        if (!(rows > 0)) {
            rows = tblRows.size();
        } else {
            rows = rows + 1;
        }
        try {
            for (int i = 1; i <= rows; i++) {
                int flag = 0;
                tblCells1 = tblRows.get(i).getCells();
                for (int x = 0; x <= tblCells1.size() - 1; x++) {
                    String column1 = CISALPHelper.stripStringWithSpecialCharacters(tblRows.get(0).getCells().get(x).getText()).toLowerCase() + rowCounter;
                    String value1 = tblCells1.get(x).getText();
                    if (column1.length() > 1) {
                        Log.debug("UI Column: " + column1 + " was added with value: " + value1);
                        tableContent.put(column1, value1);
                    }
                    flag = 1;
                }
                if (flag == 1) {
                    rowCounter++;
                }
            }
        } catch (Exception e) {
            //place holder
        }
        if (rowCounter == 0) {
            Report.reportStatusThenExit("No records found under " + tableDesc + " Table");
        } else {
            tableContent.put("rowscount", String.valueOf(rowCounter));
            tableContent.put("colscount", String.valueOf(tblCells1.size()));
        }
        return tableContent;
    }


    public static String getTranslationFromLanguageMap(String language, String term) {
        if (language.toLowerCase().equals("english")) {
            return term;
        } else {
            return CoreFrameworkHelper.getValuesFromProperties("languagemap.properties", term);
        }
    }


    public static String readFile(String fileName) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(fileName));
        try {
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();

            while (line != null) {
                sb.append(line);
                sb.append("\n");
                line = br.readLine();
            }
            return sb.toString();
        } finally {
            br.close();
        }
    }


    public static String getCISHistoryDateFormat() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyMMMdd");
        LocalDateTime now = LocalDateTime.now();
        String dateNow = dtf.format(now);
        return dateNow;
    }


    public static String formatCC(String cardNumber) {
        String temp = "";
        if ((cardNumber.length() > 13) && !cardNumber.contains("-")) {
            for (int i = 0; i < cardNumber.length(); i++) {
                temp = temp + cardNumber.substring(i, i + 1);
                if ((i + 1) % 4 == 0) {
                    temp = temp + "-";
                }
            }
            return temp.substring(0, temp.length() - 1);
        } else {
            return cardNumber;
        }
    }

}