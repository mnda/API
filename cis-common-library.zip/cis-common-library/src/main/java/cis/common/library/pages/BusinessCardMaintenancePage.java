package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.Keyboard;
import com.hp.lft.sdk.Keys;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.*;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class BusinessCardMaintenancePage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public BusinessCardMaintenancePage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing BusinessCardMaintenancePage...");
        SyncHelperWeb.waitForElementToAppear(getHeaderWebElement());
        Log.debug("BusinessCardMaintenancePage successfully initialized");
    }

    public String getMessage() throws GeneralLeanFtException {
        return getMessageEditField().getValue();
    }


    public void searchCardNumber(String cardNumber, String cardType, String cardHolderID, String transactionCode, String maintenanceCode,
                                 String cardHolderStatusCode, String changePOSDeliveryMethod, String accountType, String accountShortNum, String toPrimaryAccountType)
            throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getDisplayCardNumberEditField(), cardNumber);
        CoreFrameworkWeb.set(getCardTypeEditField(), cardType);
        CoreFrameworkWeb.set(getCardHolderIdEditField(), cardHolderID);
        CoreFrameworkWeb.set(getTransactionCodeEditField(), transactionCode);

        Keyboard.sendString(Keys.TAB);
        if (getMaintenanceCodeEditField().exists(1) && getMaintenanceCodeEditField().isVisible()
                && (!maintenanceCode.equals("") && !maintenanceCode.equals("NA"))) {
            CoreFrameworkWeb.set(getMaintenanceCodeEditField(), maintenanceCode);
            Keyboard.sendString(Keys.TAB);
        }
        if (getAccessMaintenanceCodeEditField().exists(1) && getAccessMaintenanceCodeEditField().isVisible()
                && (!maintenanceCode.equals("") && !maintenanceCode.equals("NA"))) {
            CoreFrameworkWeb.set(getAccessMaintenanceCodeEditField(), maintenanceCode);
            Keyboard.sendString(Keys.TAB);
        }


        Keyboard.sendString(Keys.TAB);
        if (!changePOSDeliveryMethod.toLowerCase().contains("na")) {
            if (changePOSDeliveryMethod.toLowerCase().contains("yes")) {
                CoreFrameworkWeb.set(getPointOfSaleRadioGroup(), 0);
            } else {
                CoreFrameworkWeb.set(getPointOfSaleRadioGroup(), 1);
            }
        }

        Keyboard.sendString(Keys.TAB);
        if (getAccountTypeEditField().exists(1) && getAccountTypeEditField().isVisible()
                && (!accountType.equals("") && !accountType.equals("NA"))) {
            CoreFrameworkWeb.set(getAccountTypeEditField(), accountType);
            Keyboard.sendString(Keys.TAB);
        }
        if (getAccountShortNumEditField().exists(1) && getAccountShortNumEditField().isVisible()
                && (!accountShortNum.equals("") && !accountShortNum.equals("NA"))) {
            CoreFrameworkWeb.set(getAccountShortNumEditField(), accountShortNum);
            Keyboard.sendString(Keys.TAB);
        }

        if (getAccountShortNumEditField().exists(1) && getAccountShortNumEditField().isVisible()
                && (!accountShortNum.equals("") && !accountShortNum.equals("NA"))) {
            CoreFrameworkWeb.set(getAccountShortNumEditField(), accountShortNum);
            Keyboard.sendString(Keys.TAB);
        }

        if (getMoveAccountTypeCodeNumEditField().exists(1) && getMoveAccountTypeCodeNumEditField().isVisible()
                && (!accountType.equals("") && !accountType.equals("NA"))) {
            CoreFrameworkWeb.set(getMoveAccountTypeCodeNumEditField(), accountType);
            Keyboard.sendString(Keys.TAB);
        }


        if (getMoveAccountShortNumEditField().exists(1) && getMoveAccountShortNumEditField().isVisible()
                && (!accountShortNum.equals("") && !accountShortNum.equals("NA"))) {
            CoreFrameworkWeb.set(getMoveAccountShortNumEditField(), accountShortNum);
            Keyboard.sendString(Keys.TAB);
        }

        if (getToPrimAccountTypeCodeEditField().exists(1) && getToPrimAccountTypeCodeEditField().isVisible()
                && (!toPrimaryAccountType.equals("") && !toPrimaryAccountType.equals("NA"))) {
            CoreFrameworkWeb.set(getToPrimAccountTypeCodeEditField(), toPrimaryAccountType);
            Keyboard.sendString(Keys.TAB);
        }


        Keyboard.sendString(Keys.TAB);
        if (getCardStatusCodeEditField().exists(1) && getCardStatusCodeEditField().isVisible()
                && !cardHolderStatusCode.toLowerCase().contains("na")) {
            CoreFrameworkWeb.set(getCardStatusCodeEditField(), cardHolderStatusCode);
        }


        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }

    //    /* -- Get Objects --*/

    private Link getBusinessMenuLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").innerText("Business Menu").build());
    }

    private EditField getDisplayCardNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("displayCardNumber").build());
    }

    private EditField getCardTypeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("cardType").build());
    }

    private EditField getCardHolderIdEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .tagName("INPUT").name("cardHolderID").build());
    }

    private EditField getTransactionCodeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .tagName("INPUT").name("transactionCode").build());
    }

    private EditField getMaintenanceCodeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .tagName("INPUT").name("cardHoldMaintenanceCode").build());
    }

    private EditField getAccessMaintenanceCodeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .tagName("INPUT").name("accessMaintenanceCode").build());
    }


    private EditField getCardStatusCodeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .tagName("INPUT").name("cardStatusCode").build());
    }


    private RadioGroup getPointOfSaleRadioGroup() {
        return GetObjectWeb.getRadioGroupObject(getMainPage(), new RadioGroupDescription.Builder()
                .tagName("INPUT").name("pointOfSaleRadio").build());
    }


    private EditField getAccountTypeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("accountType").build());
    }


    private EditField getAccountShortNumEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("accountShortNum").build());
    }

    private EditField getMoveAccountShortNumEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("moveAccountShortNum").build());
    }

    private EditField getMoveAccountTypeCodeNumEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("moveAccountTypeCode").build());
    }


    private EditField getToPrimAccountTypeCodeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("toPrimAccountTypeCode").build());
    }


    private EditField getMessageEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("message").build());
    }


    private WebElement getHeaderWebElement() {
        return GetObjectWeb.getWebElementObject(mainPage, new WebElementDescription.Builder()
                .tagName("H1").innerText(new RegExpProperty(".*Maintenance.*")).build());
    }

}