package cis.common.library.interfaces.mobilizer.mobilizer;


import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import org.apache.commons.io.IOUtils;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import pcb.auto.pom.core.helper.CoreFrameworkHelper;
import pcb.auto.pom.core.helper.Log;

import javax.net.ssl.SSLContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.InputStream;
import java.io.StringReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

/**
 * Created by angmark on 6/5/2017.
 */
public class MobilizerAPI {
    private static HashMap<String, String> transferFundsForNegative = new HashMap<String, String>();

    public static void main(String[] args) throws Exception {
        System.setProperty("log4j2.debug", "true");
        //mobileDebitToDebitTransfer("4519035697934588", "discovery", "04701-5020300", "02342-5006788", "1");
        mobileTransfer("debittodebit", "4519035734033006", "discovery", "02342-5041116", "02342-5005186", "100");
        //mobileSend3PP("4519035697934588", "discovery", "02342-5006887", "02342-1002815", "101");
        //mobilePayBill("loan", "4519035734033006", "discovery", "02342-5000161", "02342-009196640-001", "1","positive");

    }


    public static HashMap<String, String> mobileTransfer(String function, String clientCard, String loginPassword, String fromAccount,
                                                         String toAccount, String amount) throws Exception {


        System.setProperty("logDebug", "true");
        HttpResponse<String> response;

        String frmIsPayee = "", frmBranch = "", frmAccount = "", frmType = "", frmAmount = "", frmCurrency = "", toIsPayee = "",
                toBranch = "", toType = "", toCurrency = "", balanceTag = "";


        switch (function.toLowerCase().replace("-negative", "")) {
            case "debittodebit":
                frmIsPayee = "false";
                frmBranch = fromAccount.split("-", -1)[0];
                frmAccount = fromAccount.split("-", -1)[1];
                frmAmount = amount.replace(".", "");
                toIsPayee = "false";
                toBranch = toAccount.split("-", -1)[0];
                toAccount = toAccount.split("-", -1)[1];
                balanceTag = "toBalance";
                break;
            case "debittocredit":
                frmIsPayee = "false";
                frmBranch = fromAccount.split("-", -1)[0];
                frmAccount = fromAccount.split("-", -1)[1];
                frmAmount = amount.replace(".", "");
                toAccount = toAccount.replace("-", "");
                toIsPayee = "false";
                toBranch = "";
                balanceTag = "balance";
                break;
            case "credittodebit":
                frmIsPayee = "false";
                frmBranch = "";
                frmAccount = fromAccount.replace("-", "");
                frmAmount = amount.replace(".", "");
                toIsPayee = "false";
                toBranch = toAccount.split("-", -1)[0];
                toAccount = toAccount.split("-", -1)[1];
                balanceTag = "toBalance";
                break;
            case "credittocredit":
                frmIsPayee = "false";
                frmBranch = "";
                frmAccount = fromAccount.replace("-", "");
                frmAmount = amount.replace(".", "");
                toIsPayee = "false";
                toBranch = "";
                toAccount = toAccount.replace("-", "");
                balanceTag = "toBalance";
                break;
            case "debittoloan":
                frmIsPayee = "false";
                frmBranch = fromAccount.split("-", -1)[0];
                frmAccount = fromAccount.split("-", -1)[1];
                frmAmount = amount.replace(".", "");
                toIsPayee = "false";
                toBranch = toAccount.split("-", -1)[0];
                toAccount = toAccount.split("-", -1)[1] + toAccount.split("-", -1)[2];
                balanceTag = "toBalance";
                break;
            case "credittoloan":
                frmIsPayee = "false";
                frmBranch = "";
                frmAccount = fromAccount.replace("-", "");
                frmAmount = amount.replace(".", "");
                toIsPayee = "false";
                toBranch = toAccount.split("-", -1)[0];
                toAccount = toAccount.split("-", -1)[1] + toAccount.split("-", -1)[2];
                balanceTag = "toBalance";
                break;
        }

        response = mobileSignIn(clientCard, loginPassword);
        String jSessionID = getJSessionID(response);
        String token = getXMLTagValue(response.getBody(), "token");
        String pvqAnswer = getXMLTagValue(response.getBody(), "pvq").replace("true", "").replace("false", "");

        response = pvqValidation(clientCard, pvqAnswer, token, jSessionID);

        String frmShortNumber = getShortNumber(getAccountList(clientCard, jSessionID).getBody(), frmAccount);
        String toShortNumber = getShortNumber(getAccountList(clientCard, jSessionID).getBody(), toAccount);

        String frmName = getAccountName(getAccountList(clientCard, jSessionID).getBody(), frmAccount);
        String toName = getAccountName(getAccountList(clientCard, jSessionID).getBody(), toAccount);

        frmType = getTypeName(getAccountList(clientCard, jSessionID).getBody(), frmAccount);
        toType = getTypeName(getAccountList(clientCard, jSessionID).getBody(), toAccount);

        frmCurrency = getCurrency(getAccountList(clientCard, jSessionID).getBody(), frmAccount);
        toCurrency = getCurrency(getAccountList(clientCard, jSessionID).getBody(), toAccount);

        if (getXMLTagValue(response.getBody(), "Status").toLowerCase().contains("no errors")) {
            response = transferFunds(jSessionID, clientCard, frmIsPayee, frmName,
                    frmBranch, frmAccount, frmType, frmShortNumber,
                    frmAmount, frmCurrency, toIsPayee, toName,
                    toBranch, toAccount, toType, toShortNumber,
                    toCurrency);
            String body = response.getBody();
            if (getXMLTagValue(response.getBody(), "Status").toLowerCase().contains("no errors") && !function.toLowerCase().contains("negative")) {
                if (function.toLowerCase().equals("credittocredit")) {
                    Log.info("Transfer fund successful with: \n" + "Confirmation Number:" + getXMLTagValue(body, "confirmationNumber")
                            + "\nDate:" + getXMLTagValue(body, "currentDate")
                            + "\nTime:" + getXMLTagValue(body, "currentTime")
                    );
                } else {
                    Log.info("Transfer fund successful with: \n" + "Confirmation Number:" + getXMLTagValue(body, "confirmationNumber")
                            + "\nBalance:" + getXMLTagValue(body, balanceTag)
                            + "\nDate:" + getXMLTagValue(body, "currentDate")
                            + "\nTime:" + getXMLTagValue(body, "currentTime")
                    );
                }

                HashMap<String, String> transferReturnValues = new HashMap<>();
                transferReturnValues.put("confirmationNumber1", getXMLTagValue(body, "confirmationNumber"));
                transferReturnValues.put("currentDate1", getXMLTagValue(body, "currentDate"));
                transferReturnValues.put("currentTime1", getXMLTagValue(body, "currentTime"));
                mobileSignOut(jSessionID, clientCard);

                return transferReturnValues;
            } else if (!getXMLTagValue(response.getBody(), "Status").toLowerCase().contains("no errors") && function.toLowerCase().contains("negative")) {
                Log.debug("API Call to Transfer " + function + " failed as EXPECTED with response:\n" + body);
                return transferFundsForNegative;
            } else {
                Log.error("API Call to Transfer " + function + " failed with response:\n" + body);
            }

        } else {
            Log.error("PVQValidation failed, cannot proceed with the test");
            return null;
        }
        return null;
    }


    public static HashMap<String, String> mobileSend3PP(String clientCard, String loginPassword, String fromAccount, String toAccount, String amount, String testType) throws Exception {


        System.setProperty("logDebug", "true");
        HttpResponse<String> response;

        String frmIsPayee = "false";
        String frmBranch = fromAccount.split("-", -1)[0];
        String frmAccount = fromAccount.split("-", -1)[1];
        String frmAmount = amount.replace(".", "");

        toAccount = toAccount.replace("-", "");
        String balanceTag = "balance";


        response = mobileSignIn(clientCard, loginPassword);
        String jSessionID = getJSessionID(response);
        String token = getXMLTagValue(response.getBody(), "token");
        String pvqAnswer = getXMLTagValue(response.getBody(), "pvq").replace("true", "").replace("false", "");

        response = pvqValidation(clientCard, pvqAnswer, token, jSessionID);

        //get from details
        String frmShortNumber = getShortNumber(getAccountList(clientCard, jSessionID).getBody(), frmAccount);
        String frmName = getAccountName(getAccountList(clientCard, jSessionID).getBody(), frmAccount);
        String frmType = getTypeName(getAccountList(clientCard, jSessionID).getBody(), frmAccount);
        String frmCurrency = getCurrency(getAccountList(clientCard, jSessionID).getBody(), frmAccount);


        //get payee id from payee list
        String toPayeeID = getPayeeID(getPayeeList(clientCard, jSessionID).getBody(), toAccount);
        String toName = getPayeeName(getPayeeList(clientCard, jSessionID).getBody(), toAccount);
        String toType = getPayeeType(getPayeeList(clientCard, jSessionID).getBody(), toAccount);
        String toIsPayee = getIsPayee(getPayeeList(clientCard, jSessionID).getBody(), toAccount);
        //get client number from payeelist
        String toClientNumber = getClientNumber(getPayeeList(clientCard, jSessionID).getBody(), toAccount);

        if (getXMLTagValue(response.getBody(), "Status").toLowerCase().contains("no errors")) {
            response = send3PP(jSessionID, clientCard, frmIsPayee, frmName,
                    frmBranch, frmAccount, frmType, frmShortNumber,
                    frmAmount, frmCurrency, toIsPayee, toName,
                    toPayeeID, toAccount, toType, toClientNumber);
            String body = response.getBody();
            if (getXMLTagValue(response.getBody(), "Status").toLowerCase().contains("no errors") && !testType.toLowerCase().contains("negative")) {
                Log.info("Send 3PP successful with: \n" + "Confirmation Number:" + getXMLTagValue(body, "confirmationNumber")
                        + "\nBalance:" + getXMLTagValue(body, balanceTag)
                        + "\nDate:" + getXMLTagValue(body, "currentDate")
                        + "\nTime:" + getXMLTagValue(body, "currentTime")
                );

                HashMap<String, String> transferReturnValues = new HashMap<>();
                transferReturnValues.put("confirmationNumber1", getXMLTagValue(body, "confirmationNumber"));
                transferReturnValues.put("currentDate1", getXMLTagValue(body, "currentDate"));
                transferReturnValues.put("currentTime1", getXMLTagValue(body, "currentTime"));

                mobileSignOut(jSessionID, clientCard);
                return transferReturnValues;
            } else if (!getXMLTagValue(response.getBody(), "Status").toLowerCase().contains("no errors") && testType.toLowerCase().contains("negative")) {
                Log.debug("API Call to send 3PP " + testType + " failed as EXPECTED with response:\n" + body);
                return transferFundsForNegative;
            } else {
                Log.error("API Call to send 3PP failed with response:\n" + body);
            }

        } else {
            Log.error("PVQValidation failed, cannot proceed with the test");
            return null;
        }
        return null;
    }


    public static HashMap<String, String> mobilePayBill(String function, String clientCard, String loginPassword, String fromAccount,
                                                        String toAccount, String amount, String testType) throws Exception {


        System.setProperty("logDebug", "true");
        HttpResponse<String> response;

        String frmIsPayee = "", frmBranch = "", frmAccount = "", frmAmount = "";


        switch (function.toLowerCase()) {
            case "debit":
                frmIsPayee = "false";
                frmBranch = fromAccount.split("-", -1)[0];
                frmAccount = fromAccount.split("-", -1)[1];
                break;
            case "credit":
                frmIsPayee = "false";
                frmBranch = "";
                frmAccount = fromAccount.replace("-", "");
                break;
            case "loan":
                toAccount = toAccount.split("-", -1)[1];
        }

        String balanceTag = "balance";
        frmAmount = amount.replace(".", "");

        response = mobileSignIn(clientCard, loginPassword);
        String jSessionID = getJSessionID(response);
        String token = getXMLTagValue(response.getBody(), "token");
        String pvqAnswer = getXMLTagValue(response.getBody(), "pvq").replace("true", "").replace("false", "");

        response = pvqValidation(clientCard, pvqAnswer, token, jSessionID);

        //get from details
        String frmShortNumber = getShortNumber(getAccountList(clientCard, jSessionID).getBody(), frmAccount);
        String frmName = getAccountName(getAccountList(clientCard, jSessionID).getBody(), frmAccount);
        String frmType = getTypeName(getAccountList(clientCard, jSessionID).getBody(), frmAccount);
        String frmCurrency = getCurrency(getAccountList(clientCard, jSessionID).getBody(), frmAccount);


        //get payee id from payee list
        String toPayeeID = getPayeeID(getPayeeList(clientCard, jSessionID).getBody(), toAccount);
        String toName = getPayeeName(getPayeeList(clientCard, jSessionID).getBody(), toAccount);
        String toType = getPayeeType(getPayeeList(clientCard, jSessionID).getBody(), toAccount);
        String toIsPayee = getIsPayee(getPayeeList(clientCard, jSessionID).getBody(), toAccount);


        if (getXMLTagValue(response.getBody(), "Status").toLowerCase().contains("no errors")) {
            response = payBill(jSessionID, clientCard, frmIsPayee, frmName,
                    frmBranch, frmAccount, frmType, frmShortNumber,
                    frmAmount, frmCurrency, toIsPayee, toName,
                    toPayeeID, toAccount, toType);
            String body = response.getBody();
            if (getXMLTagValue(response.getBody(), "Status").toLowerCase().contains("no errors") && !testType.toLowerCase().contains("negative")) {
                if (function.toLowerCase().equals("credit")) {
                    Log.info("Pay Bill was successful with: \n" + "Confirmation Number:" + getXMLTagValue(body, "confirmationNumber")
                            + "\nDate:" + getXMLTagValue(body, "currentDate")
                            + "\nTime:" + getXMLTagValue(body, "currentTime")
                    );
                } else {
                    Log.info("Pay bill successful with: \n" + "Confirmation Number:" + getXMLTagValue(body, "confirmationNumber")
                            + "\nBalance:" + getXMLTagValue(body, balanceTag)
                            + "\nDate:" + getXMLTagValue(body, "currentDate")
                            + "\nTime:" + getXMLTagValue(body, "currentTime")
                    );
                }

                HashMap<String, String> transferReturnValues = new HashMap<>();
                transferReturnValues.put("confirmationNumber1", getXMLTagValue(body, "confirmationNumber"));
                transferReturnValues.put("currentDate1", getXMLTagValue(body, "currentDate"));
                transferReturnValues.put("currentTime1", getXMLTagValue(body, "currentTime"));

                mobileSignOut(jSessionID, clientCard);
                return transferReturnValues;
            } else if (!getXMLTagValue(response.getBody(), "Status").toLowerCase().contains("no errors") && testType.toLowerCase().contains("negative")) {
                Log.debug("API Call to Pay Bills " + testType + " failed as EXPECTED with response:\n" + body);
                return transferFundsForNegative;
            } else {
                Log.error("API Call to send 3PP failed with response:\n" + body);
            }

        } else {
            Log.error("PVQValidation failed, cannot proceed with the test");
            return null;
        }
        return null;
    }

    private static HttpResponse<String> mobileSignIn(String rbcUser, String rbcPassword) throws Exception {

        Logger.getRootLogger().setLevel(Level.INFO);
        String bodyString = getRequestBody("requestbody/MobileSignIn").replace("#@CARDNUMBER@#", rbcUser);


        Unirest.setHttpClient(turnOffSSL());
        HttpResponse<String> response = Unirest.post(CoreFrameworkHelper.getValuesFromProperties("api.properties", "mobilizerendpoint") + "/ip/service/rbc/MobileSignIn")
                .header("Content-Type", "application/xml")
                .header("Accept-Encoding", "gzip,deflate")
                .header("rbcxcq0_user", rbcUser)
                .header("rbcxcq0_pass", rbcPassword)
                .header("Connection", "Keep-Alive")
                .header("Cache-Control", "no-cache")
                .body(bodyString)
                .asString();

        String responseBody = response.getBody();
        Logger.getRootLogger().setLevel(Level.DEBUG);
        Log.debug("MobileSignIn Response: " + responseBody);
        return response;

    }

    private static HttpResponse<String> mobileSignOut(String jSessionID, String cardNumber) throws Exception {

        Logger.getRootLogger().setLevel(Level.INFO);
        String bodyString = getRequestBody("requestbody/MobileSignOut").replace("#@CARDNUMBER@#", cardNumber);


        Unirest.setHttpClient(turnOffSSL());
        HttpResponse<String> response = Unirest.post(CoreFrameworkHelper.getValuesFromProperties("api.properties", "mobilizerendpoint") + "/ip/service/rbc/MobileSignOut")
                .header("Content-Type", "application/xml")
                .header("Accept-Encoding", "gzip,deflate")
                .header("Cookie", jSessionID)
                .body(bodyString)
                .asString();

        String responseBody = response.getBody();
        Logger.getRootLogger().setLevel(Level.DEBUG);
        Log.debug("MobileSignIn Response: " + responseBody);
        return response;

    }

    private static HttpResponse<String> pvqValidation(String cardNumber, String pvqAnswer, String token, String
            jSessionID) throws Exception {
        Logger.getRootLogger().setLevel(Level.INFO);
        Unirest.setHttpClient(turnOffSSL());
        String bodyString = getRequestBody("requestbody/PVQValidation").replace("#@CARDNUMBER@#", cardNumber).replace("#@PVQANSWER@#", pvqAnswer)
                .replace("#@TOKEN@#", token);
        HttpResponse<String> response = Unirest.post(CoreFrameworkHelper.getValuesFromProperties("api.properties", "mobilizerendpoint") + "/ip/service/rbc/PVQValidation")
                .header("Content-Type", "application/xml")
                .header("Accept-Encoding", "gzip,deflate")
                .header("Cookie", jSessionID)
                .header("rbcxcq0_user", cardNumber)
                .header("rbcxcq0_answer", pvqAnswer)
                .header("Connection", "Keep-Alive")
                .header("Cache-Control", "no-cache")
                .body(bodyString)
                .asString();
        String responseBody = response.getBody();
        Logger.getRootLogger().setLevel(Level.DEBUG);
        Log.debug("pvqValidation Response: " + responseBody);
        return response;
    }


    private static HttpResponse<String> getPayeeList(String cardNumber, String jSessionID) throws Exception {
        Logger.getRootLogger().setLevel(Level.INFO);
        Unirest.setHttpClient(turnOffSSL());
        String bodyString = getRequestBody("requestbody/GetPayeeList").replace("#@CARDNUMBER@#", cardNumber);
        HttpResponse<String> response = Unirest.post(CoreFrameworkHelper.getValuesFromProperties("api.properties", "mobilizerendpoint") + "/ip/service/rbc/GetPayeeList")
                .header("Content-Type", "application/xml")
                .header("Accept-Encoding", "gzip,deflate")
                .header("Cookie", jSessionID)
                .header("Connection", "Keep-Alive")
                .header("Cache-Control", "no-cache")
                .body(bodyString)
                .asString();
        String responseBody = response.getBody();
        Logger.getRootLogger().setLevel(Level.DEBUG);
        Log.debug("getPayeeList Response: " + responseBody);
        return response;
    }

    private static HttpResponse<String> getAccountList(String cardNumber, String jSessionID) throws Exception {
        Logger.getRootLogger().setLevel(Level.INFO);
        Unirest.setHttpClient(turnOffSSL());
        String bodyString = getRequestBody("requestbody/GetAccountList").replace("#@CARDNUMBER@#", cardNumber);
        HttpResponse<String> response = Unirest.post(CoreFrameworkHelper.getValuesFromProperties("api.properties", "mobilizerendpoint") + "/ip/service/rbc/GetAccountListAndBalances")
                .header("Content-Type", "application/xml")
                .header("Accept-Encoding", "gzip,deflate")
                .header("Cookie", jSessionID)
                .header("Connection", "Keep-Alive")
                .header("Cache-Control", "no-cache")
                .body(bodyString)
                .asString();
        String responseBody = response.getBody();
        Logger.getRootLogger().setLevel(Level.DEBUG);
        Log.debug("getAccountList Response: " + responseBody);
        return response;
    }


    private static HttpResponse<String> transferFunds(String jSessionID, String cardNumber, String
            frmIsPayee, String frmName,
                                                      String frmBranch, String frmAccount, String frmType, String frmSourceNum,
                                                      String frmAmount, String frmCurrency, String toIsPayee, String toName,
                                                      String toBranch, String toAccount, String toType, String toSourceNum,
                                                      String toCurrency) throws Exception {
        Unirest.setHttpClient(turnOffSSL());
        String bodyString = getRequestBody("requestbody/TransferFundsDebit").replace("#@CARDNUMBER@#", cardNumber).replace("#@FROMISPAYEE@#", frmIsPayee)
                .replace("#@FROMNAME@#", frmName).replace("#@FROMBRANCH@#", frmBranch).replace("#@FROMACCOUNT@#", frmAccount).replace("#@FROMTYPE@#", frmType)
                .replace("#@FROMSOURCENUM@#", frmSourceNum).replace("#@FROMAMOUNT@#", frmAmount).replace("#@FROMCURRENCY@#", frmCurrency).replace("#@TOISPAYEE@#", toIsPayee)
                .replace("#@TONAME@#", toName).replace("#@TOBRANCH@#", toBranch).replace("#@TOACCOUNT@#", toAccount).replace("#@TOTYPE@#", toType).replace("#@TOSOURCENUM@#", toSourceNum)
                .replace("#@TOCURRENCY@#", toCurrency);

        bodyString =  bodyString.replace("<shortNumber></shortNumber>","<shortNumber>C001</shortNumber>");
        bodyString =  bodyString.replace("<name></name>","<name>CalcPlus</name>");

        Log.info("Execute API request for transferring funds");
        Log.debug("Transfer Funds request body:\n" + bodyString);

        Logger.getRootLogger().setLevel(Level.INFO);
        HttpResponse<String> response = Unirest.post(CoreFrameworkHelper.getValuesFromProperties("api.properties", "mobilizerendpoint") + "/ip/service/rbc/TransferFunds")
                .header("Content-Type", "application/xml")
                .header("Accept-Encoding", "gzip,deflate")
                .header("Cookie", jSessionID)
                .header("Connection", "Keep-Alive")
                .header("Cache-Control", "no-cache")
                .body(bodyString)
                .asString();
        //this is to get the time for negative testing since confirmation number is not available
        pushDateAndTime();
        String responseBody = response.getBody();
        Logger.getRootLogger().setLevel(Level.DEBUG);
        Log.debug("transferFundsDebit Response: " + responseBody);
        return response;
    }


    private static HttpResponse<String> send3PP(String jSessionID, String cardNumber, String frmIsPayee, String
            frmName,
                                                String frmBranch, String frmAccount, String frmType, String frmSourceNum,
                                                String frmAmount, String frmCurrency, String toIsPayee, String toName,
                                                String toPayeeID, String toAccount, String toType, String toClientNumber) throws Exception {
        Logger.getRootLogger().setLevel(Level.INFO);
        Unirest.setHttpClient(turnOffSSL());
        String bodyString = getRequestBody("requestbody/Send3PP").replace("#@CARDNUMBER@#", cardNumber).replace("#@FROMISPAYEE@#", frmIsPayee)
                .replace("#@FROMNAME@#", frmName).replace("#@FROMBRANCH@#", frmBranch).replace("#@FROMACCOUNT@#", frmAccount).replace("#@FROMTYPE@#", frmType)
                .replace("#@FROMSOURCENUM@#", frmSourceNum).replace("#@FROMAMOUNT@#", frmAmount).replace("#@FROMCURRENCY@#", frmCurrency).replace("#@TOISPAYEE@#", toIsPayee)
                .replace("#@TONAME@#", toName).replace("#@TOPAYEEID@#", toPayeeID).replace("#@TOACCOUNT@#", toAccount).replace("#@TOTYPE@#", toType).replace("#@TOCLIENTNUMBER@#", toClientNumber);

        Log.info("Execute API request for Sending 3PP");
        Log.debug("Sending 3PP request body:\n " + bodyString);
        HttpResponse<String> response = Unirest.post(CoreFrameworkHelper.getValuesFromProperties("api.properties", "mobilizerendpoint") + "/ip/service/rbc/Send3PP")
                .header("Cookie", jSessionID)
                .header("Content-Type", "application/xml")
                .header("rbcxcq0_user", cardNumber)
                .header("Accept-Encoding", "gzip,deflate")
                .header("Connection", "Keep-Alive")
                .header("Cache-Control", "no-cache")
                .body(bodyString)
                .asString();
        //this is to get the time for negative testing since confirmation number is not available
        pushDateAndTime();
        String responseBody = response.getBody();
        Logger.getRootLogger().setLevel(Level.DEBUG);
        Log.debug("send3PP Response: " + responseBody);
        return response;
    }


    private static HttpResponse<String> payBill(String jSessionID, String cardNumber, String frmIsPayee, String
            frmName,
                                                String frmBranch, String frmAccount, String frmType, String frmSourceNum,
                                                String frmAmount, String frmCurrency, String toIsPayee, String toName,
                                                String toPayeeID, String toAccount, String toType) throws Exception {
        Logger.getRootLogger().setLevel(Level.INFO);
        Unirest.setHttpClient(turnOffSSL());
        String bodyString = getRequestBody("requestbody/PayBill").replace("#@CARDNUMBER@#", cardNumber).replace("#@FROMISPAYEE@#", frmIsPayee)
                .replace("#@FROMNAME@#", frmName).replace("#@FROMBRANCH@#", frmBranch).replace("#@FROMACCOUNT@#", frmAccount).replace("#@FROMTYPE@#", frmType)
                .replace("#@FROMSOURCENUM@#", frmSourceNum).replace("#@FROMAMOUNT@#", frmAmount).replace("#@FROMCURRENCY@#", frmCurrency).replace("#@TOISPAYEE@#", toIsPayee)
                .replace("#@TONAME@#", toName).replace("#@TOPAYEEID@#", toPayeeID).replace("#@TOACCOUNT@#", toAccount).replace("#@TOTYPE@#", toType);

        Log.info("Execute API request for Bill Payments");
        Log.debug("Bill Payments request body:\n " + bodyString);
        HttpResponse<String> response = Unirest.post(CoreFrameworkHelper.getValuesFromProperties("api.properties", "mobilizerendpoint") + "/ip/service/rbc/PayBills")
                .header("Cookie", jSessionID)
                .header("Content-Type", "application/xml")
                .header("Accept-Encoding", "gzip,deflate")
                .header("Connection", "Keep-Alive")
                .header("Cache-Control", "no-cache")
                .body(bodyString)
                .asString();
        //this is to get the time for negative testing since confirmation number is not available
        pushDateAndTime();
        String responseBody = response.getBody();
        Logger.getRootLogger().setLevel(Level.DEBUG);
        Log.debug("payBill Response: " + responseBody);
        return response;
    }


    private static String getRequestBody(String fileName) throws Exception {
        InputStream inputStream = MobilizerAPI.class.getClassLoader().getResourceAsStream(fileName);
        return IOUtils.toString(inputStream, "UTF-8");

    }


    private static CloseableHttpClient turnOffSSL() throws Exception {
        SSLContext sslcontext = SSLContexts.custom()
                .loadTrustMaterial(null, new TrustSelfSignedStrategy())
                .build();

        SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        CloseableHttpClient httpclient = HttpClients.custom()
                .setSSLSocketFactory(sslsf)
                .build();

        return httpclient;
    }


    private static String getJSessionID(HttpResponse<String> response) {
        int count = response.getHeaders().get("Set-Cookie").size();
        for (int i = 0; i < count; i++) {
            if (response.getHeaders().get("Set-Cookie").get(i).contains("JSESSIONID")) {
                String jSessionID = response.getHeaders().get("Set-Cookie").get(i).split(";", -1)[0].trim();
                Log.debug("JSESSIONID Cookie: " + jSessionID);
                return jSessionID;
            }
        }
        Log.error("Cannot get JSESSIONID for Mobile Sign In");
        return null;
    }


    private static String getXMLTagValue(String xml, String tagName) throws Exception {
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        InputSource src = new InputSource();
        src.setCharacterStream(new StringReader(xml));

        Document doc = builder.parse(src);
        String node = "";
        try {
            node = doc.getElementsByTagName(tagName).item(0).getTextContent();
        } catch (Exception e) {
            Log.error("Tag " + tagName + " was not found from XML Response \n" + xml);
        }
        Log.debug("Got " + tagName + ": " + node + " from response body");
        return node;
    }


    private static String getClientNumber(String xml, String accountNumber) throws Exception {
        String[] arXML = xml.split("<accountNumber>", -1);
        String clientNumber = "";
        for (int i = 0; i < arXML.length; i++) {
            if (arXML[i].contains(accountNumber)) {
                clientNumber = arXML[i].split("</clientNumber>", -1)[0].split("<clientNumber>", -1)[1];
                break;
            }
        }

        if (clientNumber.equals("")) {
            Log.error("No client number found for accountNumber " + accountNumber);
        } else {
            Log.debug("Client number " + clientNumber + " was found for accountNumber " + accountNumber);
        }

        return clientNumber;
    }


    private static String getPayeeID(String xml, String accountNumber) throws Exception {
        String[] arXML = xml.split("</RBCPayee>", -1);
        String payeeID = "";
        for (int i = 0; i < arXML.length; i++) {
            if (arXML[i].contains(accountNumber)) {
                payeeID = arXML[i].split("</payeeId>", -1)[0].split("<payeeId>", -1)[1];
                break;
            }
        }

        if (payeeID.equals("")) {
            Log.error("No payee ID found for accountNumber " + accountNumber);
        } else {
            Log.debug("Payee ID " + payeeID + " was found for accountNumber " + accountNumber);
        }

        return payeeID;
    }

    private static String getPayeeName(String xml, String accountNumber) throws Exception {
        String[] arXML = xml.split("</RBCPayee>", -1);
        String payeeName = "";
        for (int i = 0; i < arXML.length; i++) {
            if (arXML[i].contains(accountNumber)) {
                payeeName = arXML[i].split("</name>", -1)[0].split("<name>", -1)[1];
                break;
            }
        }

        if (payeeName.equals("")) {
            Log.error("No payee name found for accountNumber " + accountNumber);
        } else {
            Log.debug("Payee name " + payeeName + " was found for accountNumber " + accountNumber);
        }

        return payeeName;
    }


    private static String getIsPayee(String xml, String accountNumber) throws Exception {
        String[] arXML = xml.split("</RBCPayee>", -1);
        String isPayee = "";
        for (int i = 0; i < arXML.length; i++) {
            if (arXML[i].contains(accountNumber)) {
                isPayee = arXML[i].split("</isPayee>", -1)[0].split("<isPayee>", -1)[1];
                break;
            }
        }

        if (isPayee.equals("")) {
            Log.error("No Is Payee found for accountNumber " + accountNumber);
        } else {
            Log.debug("Is Payee " + isPayee + " was found for accountNumber " + accountNumber);
        }

        return isPayee;
    }

    private static String getPayeeType(String xml, String accountNumber) throws Exception {
        String[] arXML = xml.split("</RBCPayee>", -1);
        String payeeType = "";
        for (int i = 0; i < arXML.length; i++) {
            if (arXML[i].contains(accountNumber)) {
                payeeType = arXML[i].split("</type>", -1)[0].split("<type>", -1)[1];
                break;
            }
        }

        if (payeeType.equals("")) {
            Log.error("No Payee Type found for accountNumber " + accountNumber);
        } else {
            Log.debug("Payee Type " + payeeType + " was found for accountNumber " + accountNumber);
        }

        return payeeType;
    }


    private static String getShortNumber(String xml, String accountNumber) throws Exception {
        String[] arXML = xml.split("</RBCAccount>", -1);
        String shortNumber = "";
        String secondaryType = "";
        for (int i = 0; i < arXML.length; i++) {
            if (arXML[i].contains(accountNumber)) {
                try {
                    shortNumber = arXML[i].split(">shortNumber</key><value>", -1)[1].split("</value>", -1)[0];
                } catch (Exception e) {
                    Log.debug("Account doesn't have a short number");
                    shortNumber = "";
                }
                try {
                    secondaryType = arXML[i].split(">secondaryType</key><value>", -1)[1].split("</value>", -1)[0];
                } catch (Exception f) {
                    Log.debug("Account doesn't have a secondary Type");
                    secondaryType = "";
                }

                if (secondaryType.length() > 1) {
                    secondaryType = "V";
                }
                break;
            }
        }

        if (shortNumber.equals("") || secondaryType.equals("")) {
            Log.debug("No Short Number found for accountNumber " + accountNumber);
        } else {
            Log.debug("Short Number " + secondaryType + shortNumber + " was found for accountNumber " + accountNumber);
        }

        return secondaryType + shortNumber;
    }

    private static String getAccountName(String xml, String accountNumber) throws Exception {
        String[] arXML = xml.split("</RBCAccount>", -1);
        String accountName = "";
        for (int i = 0; i < arXML.length; i++) {
            if (arXML[i].contains(accountNumber)) {
                try {
                    accountName = arXML[i].split("</name>", -1)[0].split("<name>", -1)[1];
                } catch (Exception e) {
                    accountName = "";
                }
                break;
            }
        }

        if (accountName.equals("")) {
            Log.debug("No account name found for accountNumber " + accountNumber);
        } else {
            Log.debug("Account Name " + accountName + " was found for accountNumber " + accountNumber);
        }

        return accountName;
    }

    private static String getTypeName(String xml, String accountNumber) throws Exception {
        String[] arXML = xml.split("</RBCAccount>", -1);
        String typeName = "";
        for (int i = 0; i < arXML.length; i++) {
            if (arXML[i].contains(accountNumber)) {
                typeName = arXML[i].split("</typeName>", -1)[0].split("<typeName>", -1)[1];
                break;
            }
        }

        if (typeName.equals("")) {
            Log.error("No Type Name found for accountNumber " + accountNumber);
        } else {
            Log.debug("Type Name " + typeName + " was found for accountNumber " + accountNumber);
        }

        return typeName;
    }

    private static String getCurrency(String xml, String accountNumber) throws Exception {
        String[] arXML = xml.split("</RBCAccount>", -1);
        String currency = "";
        for (int i = 0; i < arXML.length; i++) {
            if (arXML[i].contains(accountNumber)) {
                currency = arXML[i].split("<balance currency=\"", -1)[1].split("\">", -1)[0];
                break;
            }
        }

        if (currency.equals("")) {
            Log.error("No currency found for accountNumber " + accountNumber);
        } else {
            Log.debug("Currency " + currency + " was found for accountNumber " + accountNumber);
        }

        return currency;
    }


    private static void pushDateAndTime() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyMMMdd-HH:mm");
        LocalDateTime now = LocalDateTime.now();
        String dateNow = dtf.format(now);

        transferFundsForNegative.put("confirmationNumber1", "");
        Log.debug("Getting request timing for negative TCs: " + dateNow);
        transferFundsForNegative.put("currentDate1", dateNow.split("-", -1)[0]);
        transferFundsForNegative.put("currentTime1", dateNow.split("-", -1)[1]);

    }


}
