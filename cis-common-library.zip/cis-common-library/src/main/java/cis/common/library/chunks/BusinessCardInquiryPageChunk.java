package cis.common.library.chunks;


import cis.common.library.BaseChunkWeb;
import cis.common.library.pages.BusinessCardInquiryPage;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.*;
import cucumber.api.Scenario;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;

import java.util.HashMap;

/**
 * Created by angmark on 5/25/2017.
 */
public class BusinessCardInquiryPageChunk extends BaseChunkWeb {
    public static Page mainPage;


    public BusinessCardInquiryPageChunk(Page parent) {
        super(parent);
        mainPage = parent;
        Log.debug("BusinessCardInquiryPageChunk successfully initialized");
    }

    public static void main(String[] args) throws Exception, Throwable {
        Scenario scenario = null;
        CoreFrameworkWeb.instantiateSDK();
        System.setProperty("logDebug", "true");
        BusinessCardInquiryPage inquiryPage = new BusinessCardInquiryPage();
        BusinessCardInquiryPageChunk inquiryPageChunk = new BusinessCardInquiryPageChunk(inquiryPage.getMainPage());
        //inquiryPageChunk.getAccountTypeAndShortNumber();
        inquiryPageChunk.getBusinessInquiryValuesWithTable();
        //inquiryPageChunk.getBusinessInquiryValuesAccessLimits();

        CoreFrameworkWeb.cleanupSDK();
    }

    public String getCardStatus() throws GeneralLeanFtException {
        String cardStatus = getCardStatusEditField().getValue().trim();
        Log.debug("Card Status: " + cardStatus);
        return cardStatus;
    }

    public HashMap<String, String> getElectronicAccessLimits() throws GeneralLeanFtException {
        HashMap<String, String> electronicAccessLimits = new HashMap<>();

        electronicAccessLimits.put("ReleaseAmount1", getReleaseAmountEditField().getValue().replace(",", "").trim());
        electronicAccessLimits.put("AtmWithdrawalAmount1", getATMWithdrawalEditField().getValue().replace(",", "").trim());
        electronicAccessLimits.put("POSTransactionAmount1", getPOSTransactionEditField().getValue().replace(",", "").trim());
        electronicAccessLimits.put("3PPAmount1", get3PPEditField().getValue().replace(",", "").trim());
        electronicAccessLimits.put("ForeignCashPurchaseAmount1", getForeignCashPurchaseEditField().getValue().replace(",", "").trim());

        return electronicAccessLimits;
    }

    public HashMap<String, String> getContactlessLimitSection() throws GeneralLeanFtException {
        HashMap<String, String> contactlessLimitsSection = new HashMap<>();

        contactlessLimitsSection.put("CurrentOtherLimit1", getClssOtherCurrentLimitEditField().getValue().trim());
        contactlessLimitsSection.put("CurrentGasLimit1", getClssGasCurrentLimitEditField().getValue().trim());
        contactlessLimitsSection.put("CurrentGroceryLimit1", getClssGroceryCurrentLimitEditField().getValue().trim());

        return contactlessLimitsSection;
    }

    public HashMap<String, String> getATMAccessStatus() throws GeneralLeanFtException {
        HashMap<String, String> atmAccessSection = new HashMap<>();


        if (getPrimarySavingsEditField().getValue().equals("") && getPrimaryChequingEditField().getValue().equals("")) {

        }


        atmAccessSection.put("AtmAccess1", getAtmAccessEditField().getValue().trim());
        atmAccessSection.put("SavingAtmAccess1", getSavingAtmAccessEditField().getValue().trim());

        return atmAccessSection;
    }

    public HashMap<String, String> getAccountTypeAndShortNumber() throws GeneralLeanFtException {
        HashMap<String, String> typeAndShortNum = new HashMap<>();


        if (getPrimarySavingsEditField().getValue().equals("") && getPrimaryChequingEditField().getValue().equals("")) {
            int rowSize = getAccountsTable().getRows().size();
            boolean found = false;
            if (rowSize > 1) {
                for (int i = 2; i < 4; i++) {
                    for (int j = 3; j < rowSize; j++) {
                        String cellValue = getAccountsTable().getRows().get(i).getCells().get(j).getText();
                        if (!cellValue.equals("")) {
                            Log.debug("AccountType: " + String.valueOf(j / 2));
                            typeAndShortNum.put("AccountType1", String.valueOf(j / 2));
                            Log.debug("AccountShortNum: " + String.valueOf(cellValue.charAt(cellValue.length() - 1)));
                            typeAndShortNum.put("AccountShortNum1", String.valueOf(cellValue.charAt(cellValue.length() - 1)));
                            found = true;
                            break;
                        }
                    }
                    if (found) {
                        break;
                    }
                }
            }
            if (!found) {
                Log.error("ABCC does not have eligible accounts. Please use a different ABCC with account.");
            }

        } else {
            if (!getPrimarySavingsEditField().getValue().equals("")) {
                Log.debug("Current AccountType: 2");
                typeAndShortNum.put("AccountType1", "2");
                Log.debug("ChangeToAccountType1: 1");
                typeAndShortNum.put("ChangeToAccountType1", "1");
            } else {
                Log.debug("Current AccountType: 1");
                typeAndShortNum.put("AccountType1", "1");
                Log.debug("ChangeToAccountType1: 2");
                typeAndShortNum.put("ChangeToAccountType1", "2");

            }
            Log.debug("AccountShortNum: 1");
            typeAndShortNum.put("AccountShortNum1", "1");
        }

        return typeAndShortNum;
    }

    public HashMap<String, String> getBusinessInquiryValuesWithTable() throws GeneralLeanFtException {
        HashMap<String, String> businessInquiryValuesWithTable = new HashMap<>();

        businessInquiryValuesWithTable.put("pageName1", "businessInquiryValuesWithTable");

        businessInquiryValuesWithTable.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());

        businessInquiryValuesWithTable.put("atm1", getAtmEditField().getValue().trim());
        Log.debug("ATM: " + getAtmEditField().getValue().trim());

        businessInquiryValuesWithTable.put("pin1", getPinEditField().getValue().trim());
        Log.debug("PIN: " + getPinEditField().getValue().trim());

        businessInquiryValuesWithTable.put("primaryChequing1", getPrimaryChequingEditField().getValue().trim());
        Log.debug("Primary Chequing: " + getPrimaryChequingEditField().getValue().trim());

        businessInquiryValuesWithTable.put("primarySavings1", getPrimarySavingsEditField().getValue().trim());
        Log.debug("Primary Savings: " + getPrimarySavingsEditField().getValue().trim());

        businessInquiryValuesWithTable.put("creditCard1", getCreditCardEditField().getValue().trim());
        Log.debug("Credit Card: " + getCreditCardEditField().getValue().trim());

        businessInquiryValuesWithTable.put("rcl1", getRclEditField().getValue().trim());
        Log.debug("RCL: " + getRclEditField().getValue().trim());

        businessInquiryValuesWithTable.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important: " + getImportantEditField().getValue().trim());

        /**
         * Iterates through the getsAccountTable1 data.
         */
        int rowSize = getAccountsTable().getRows().size();
        int colSize = getAccountsTable().getColumnHeaders().size();
        String otherChequing = "", otherSavings = "", otherCredits = "", otherLoans = "";
        if (rowSize > 1) {
            for (int i = 2; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    String cellValue = getAccountsTable().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 1:
                                otherChequing = otherChequing + cellValue + " ";
                                break;
                            case 3:
                                otherSavings = otherSavings + cellValue + " ";
                                break;
                            case 5:
                                otherCredits = otherCredits + cellValue + " ";
                                break;
                            case 7:
                                otherLoans = otherLoans + cellValue + " ";
                                break;
                        }
                    }

                    /*try {
                        otherChequing = otherChequing.substring(0, otherChequing.length());
                    } catch (Exception e) {

                        try {
                            otherSavings = otherSavings.substring(0, otherSavings.length());
                        } catch (Exception f) {
                        }
                        try {
                            otherCredits = otherCredits.substring(0, otherCredits.length());
                        } catch (Exception g) {
                        }
                        try {
                            otherLoans = otherLoans.substring(0, otherLoans.length());
                        } catch (Exception h) {
                        }




                        break;

                    }*/
                }
            }

            businessInquiryValuesWithTable.put("otherChequing1", otherChequing);
            Log.debug("Other Chequing: " + otherChequing);
            businessInquiryValuesWithTable.put("otherSavings1", otherSavings);
            Log.debug("Other Savings: " + otherSavings);
            businessInquiryValuesWithTable.put("otherCredits1", otherCredits);
            Log.debug("Other Credits: " + otherCredits);
            businessInquiryValuesWithTable.put("otherLoans1", otherLoans);
            Log.debug("Other Loans: " + otherLoans);

        }

        return businessInquiryValuesWithTable;

    }

    //Table

    private Table getAccountsTable() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Other Chequing  Other Savings.*")).build());
    }

    private Table getAccountsTableAllAccounts() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Chequing Savings Credit Cards.*")).build());
    }

    //** Get Objects **/

    //Electronic Access Limists Section
    private EditField getReleaseAmountEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("releaseAmountCurrent").build());
    }



    private EditField getATMWithdrawalEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("currentWithdraw").build());
    }

    private EditField getPOSTransactionEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("currentPos").build());
    }

    private EditField get3PPEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("current3PP").build());
    }

    private EditField getForeignCashPurchaseEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("fcoCurrentLimit").build());
    }

    //Contactless Limits
    private EditField getClssOtherCurrentLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clssOtherCurrentLimit").build());
    }

    private EditField getClssGasCurrentLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clssGasCurrentLimit").build());
    }

    private EditField getClssGroceryCurrentLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clssGroceryCurrentLimit").build());
    }


    private EditField getPrimaryChequingEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("primaryChequing").build());
    }

    private EditField getPrimarySavingsEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("primarySavings").build());
    }


    private EditField getAtmAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("atmAccess").build());
    }

    private EditField getSavingAtmAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("savingAtmAccess").build());
    }

    private EditField getCardStatusEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("cardStatus").index(1).build());
    }

    /*****************************************************************************************/

    private EditField getAtmEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("atm").build());

    }

    private EditField getImportantEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("important").build());

    }

    private EditField getLanguageEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("language").index(0).build());

    }

    private EditField getPinEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("pin").build());

    }

    private EditField getCreditCardEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("creditCard").build());

    }

    private EditField getRclEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("rcl").build());

    }

    private EditField getCreditCardAtmAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("creditCardATMAccess").build());

    }

    private EditField getRclAtmAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("rclATMAccess").build());

    }

}
