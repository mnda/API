package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.EditField;
import com.hp.lft.sdk.web.EditFieldDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class MobileDebitMaintenancePage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public MobileDebitMaintenancePage() throws GeneralLeanFtException, InterruptedException {
        mainPage = getMainPage();
        waitUntilVisible();
    }


    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing MobileDebitMaintenancePage...");
        SyncHelperWeb.waitForElementToAppear(getDisplayCardNumberEditField());
        Log.debug("MobileDebitMaintenancePage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        CoreFrameworkWeb.cleanupSDK();
    }


    public void searchCardNumber(String cardNumber, String maintenanceCode, String mobileDebitStatCode) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getDisplayCardNumberEditField(), cardNumber);
        CoreFrameworkWeb.set(getMaintenanceCodeEditField(), maintenanceCode);

        if (getMobileDebitStatCodeEditField().exists(1)) {
            CoreFrameworkWeb.set(getMobileDebitStatCodeEditField(), mobileDebitStatCode);
        }

        CoreFrameworkWeb.click(getSubmitButton(mainPage));

    }

    //    /* -- Get Objects --*/

    private EditField getDisplayCardNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("displayCardNumber").build());
    }

    private EditField getMaintenanceCodeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("maintenanceCode").build());
    }

    private EditField getMobileDebitStatCodeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("mobileDebitStatCode").build());
    }


}
