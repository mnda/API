package cis.common.library.chunks;


import cis.common.library.BaseChunkWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.*;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;

/**
 * Created by angmark on 5/25/2017.
 */
public class MobileDebitMaintenancePageChunk extends BaseChunkWeb {
    public static Page mainPage;


    public MobileDebitMaintenancePageChunk(Page parent) {
        super(parent);
        mainPage = parent;
        Log.debug("MobileDebitMaintenancePageChunk successfully initialized");
    }

    public void selectClientMobileSelection(String enableContactless, String disableContactless, String updateLimits) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getEnableContactlessCheckBox(), enableContactless);
        CoreFrameworkWeb.set(getDisableContactlessCheckBox(), disableContactless);
        CoreFrameworkWeb.set(getUpdateLimitsCheckBox(), updateLimits);
        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }

    public void setContactlessLimitsChanges(String otherPersonalisedAmt, String gasPersonalisedAmt, String groceryPersonalisedAmt) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getOtherPersonalisedAmtEditField(), otherPersonalisedAmt);
        CoreFrameworkWeb.set(getGasPersonalisedAmtEditField(), gasPersonalisedAmt);
        CoreFrameworkWeb.set(getGroceryPersonalisedAmtEditField(), groceryPersonalisedAmt);
        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }


    private CheckBox getEnableContactlessCheckBox() {
        return GetObjectWeb.getCheckBoxObject(mainPage, new CheckBoxDescription.Builder()
                .type("checkbox").tagName("INPUT").name("enableContactless").build());

    }

    private CheckBox getDisableContactlessCheckBox() {
        return GetObjectWeb.getCheckBoxObject(mainPage, new CheckBoxDescription.Builder()
                .type("checkbox").tagName("INPUT").name("disableContactless").build());

    }

    private CheckBox getUpdateLimitsCheckBox() {
        return GetObjectWeb.getCheckBoxObject(mainPage, new CheckBoxDescription.Builder()
                .type("checkbox").tagName("INPUT").name("updateLimits").build());

    }

    private EditField getOtherPersonalisedAmtEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("otherPersonalisedAmt").build());

    }

    private EditField getGasPersonalisedAmtEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("gasPersonalisedAmt").build());

    }

    private EditField getGroceryPersonalisedAmtEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("groceryPersonalisedAmt").build());

    }

}
