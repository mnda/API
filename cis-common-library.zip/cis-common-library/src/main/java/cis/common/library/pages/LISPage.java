package cis.common.library.pages;


import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.stdwin.*;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWindows;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.windows.AbstractPageWindows;
import pcb.auto.pom.core.windows.CoreFrameworkWindows;
import pcb.auto.pom.core.windows.GetObjectWindows;

import java.util.Arrays;
import java.util.List;


/**
 * Created by angmark on 5/25/2017.
 */
public class LISPage extends AbstractPageWindows {
    /**
     * Constructs the page while ensuring that element is visible before proceeding
     */
    public LISPage() {
        mainPage = getMainPage();
    }

    /**
     * Overrides waitUntilVisible method to ensure page loaded correctly
     */
    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing LISPage...");
        SyncHelperWindows.waitForElementToAppear(getLISCardsListBox());
        Log.debug("LISPage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        LISPage lisPage = new LISPage();
        lisPage.loginToLIS("QXHGS4D,QXHGS4E,QXHGS4M", 01);
        CoreFrameworkWeb.cleanupSDK();
    }


    public void loginToLIS(String cardNumber, int seconds) throws GeneralLeanFtException {
        int counter = 0;
        while (!(getMainPage().exists(1)) && counter < seconds) {
            counter++;
        }

        if (getMainPage().exists(1)) {
            Log.info("Logging in to LIS");
            //Check if newly launched
            if (getMainPage().getText().contains("Select")) {
                CoreFrameworkWindows.set(getLISCardsListBox(), checkIfCardExists(cardNumber));
                CoreFrameworkWindows.click(getLISOKButton());
            }
            //Enter password if just logged out
            CoreFrameworkWindows.setPassword(getPasswordEditField(), "12345678");
            CoreFrameworkWindows.click(getLISOKButton());

            if (getMainPage().exists(2)) {
                CoreFrameworkWindows.click(getLISOKButton());
                CoreFrameworkWindows.setPassword(getPasswordEditField(), "87654321");
                CoreFrameworkWindows.click(getLISOKButton());
            }
        }
    }

    private String checkIfCardExists(String cardNumbers) throws GeneralLeanFtException {
        String tempCard = "";
        boolean flag = false;
        List<ListItem> listItem = getLISCardsListBox().getItems();
        String tempListContent = "";
        //Looping one time as looping a couple of times slows down the excution
        for (int i = 0; i < listItem.size(); i++) {
            tempListContent = tempListContent + listItem.get(i).getText().toLowerCase() + ",";
        }

        List<String> cards = Arrays.asList(cardNumbers.split(",", -1));
        List<String> cardsInLIS = Arrays.asList(tempListContent.split(",", -1));
        for (int x = 0; x < cards.size(); x++) {
            tempCard = cards.get(x).trim();
            Log.debug("Checking if " + tempCard + " exists in LIS");
            for (int i = 0; i < listItem.size(); i++) {
                if (cardsInLIS.get(i).toLowerCase().contains(tempCard.toLowerCase())) {
                    flag = true;
                    break;
                }
            }
            if (flag) {
                break;
            }
        }
        return tempCard;
    }


    //    /* -- Get Objects --*/
    public Dialog getMainPage() {
        return GetObjectWindows.getPageObject(new DialogDescription.Builder()
                .text(new RegExpProperty("LIS.*")).build());
    }

    private ListBox getLISCardsListBox() {
        return GetObjectWindows.getListBoxObject(getMainPage(), new ListBoxDescription.Builder()
                .attachedText(new RegExpProperty("Cards owned by.*")).build());
    }

    private Button getLISOKButton() {
        return GetObjectWindows.getButtonObject(getMainPage(), new ButtonDescription.Builder().text("OK").build());
    }

    private EditField getPasswordEditField() {
        return GetObjectWindows.getEditFieldObject(getMainPage(), new EditFieldDescription.Builder()
                .attachedText("Password:").index(0).build());
    }

    //***** ENUMS *****//
    public enum ALPSystems {
        CIS("CIS");

        private final String text;

        ALPSystems(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }
}
