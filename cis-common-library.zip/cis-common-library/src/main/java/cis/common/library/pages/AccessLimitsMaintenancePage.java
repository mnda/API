package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.EditField;
import com.hp.lft.sdk.web.EditFieldDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class AccessLimitsMaintenancePage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public AccessLimitsMaintenancePage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing AccessLimistsMaintenancePage...");
        SyncHelperWeb.waitForElementToAppear(getTrustClientNumberEditField());
        Log.debug("AccessLimistsMaintenancePage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        AccessLimitsMaintenancePage page = new AccessLimitsMaintenancePage();
        page.searchClient("test");
        CoreFrameworkWeb.cleanupSDK();
    }


    public void searchClient(String clientNumber) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getTrustClientNumberEditField(), clientNumber);
        CoreFrameworkWeb.click(this.getSubmitButton(mainPage));
    }

    //    /* -- Get Objects --*/


    private EditField getTrustClientNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("royalTrustClientNumber").build());
    }

}
