package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.*;
import com.sun.webkit.WebPage;
import org.opencv.core.Core;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class AccountPackageEntitlementChange extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public AccountPackageEntitlementChange() {
        mainPage = getMainPage();

        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing AccountPackageEntitlementChange...");

        SyncHelperWeb.waitForElementToAppear(getClientNumberEditField());
        Log.debug("AccountPackageEntitlementChange successfully initialized");
    }

    public static void main(String[] args) throws Exception{
        CoreFrameworkWeb.instantiateSDK();
        AccountPackageEntitlementChange page = new AccountPackageEntitlementChange();
        //test page and function here...
        CoreFrameworkWeb.cleanupSDK();

    }

    public void searchClient(String clientNumber) throws GeneralLeanFtException {
        //CoreFrameworkWeb.click(this.getOkButton(mainPage));
        CoreFrameworkWeb.set(getClientNumberEditField(), clientNumber);
        CoreFrameworkWeb.click(this.getDisplayButton(mainPage));
    }


    //    /* -- Get Objects --*/
    private EditField getClientNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clientNumber").build());
    }

    private RadioGroup getClientListRadioGroup() {
        return GetObjectWeb.getRadioGroupObject(mainPage, new RadioGroupDescription.Builder()
                .tagName("INPUT").name("clientList").build());
    }

    private Image getDisplayButtonImage() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .alt("Display Button").type(ImageType.LINK).tagName("IMG").build());
    }

    private Image getClearButtonImage() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .alt("Clear Button").type(ImageType.LINK).tagName("IMG").build());
    }

    private Image getEndClientSessionButtonImage() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .alt("End Client Session Button").type(ImageType.LINK).tagName("IMG").build());
    }


}
