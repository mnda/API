package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import cis.common.library.chunks.BusinessCardInquiryPageChunk;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.*;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;

import java.util.HashMap;


/**
 * Created by angmark on 5/25/2017.
 */
public class BusinessCardInquiryPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public BusinessCardInquiryPage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing BusinessCardInquiryPage...");
        SyncHelperWeb.waitForElementToAppear(getCardNumberEditField());
        Log.debug("BusinessCardInquiryPage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        System.setProperty("logDebug", "true");
        BusinessCardInquiryPage page = new BusinessCardInquiryPage();
        page.getBusinessInquiryValuesBusinessPrimaryHistory();
        // page.purgeCardNumber("4519031550702469", "60", "05", "1", "00001", "5260906");
        CoreFrameworkWeb.cleanupSDK();


    }

    public HashMap<String, String> searchCard(String cardNumber, String cardType, String cardHolderID, String inquiryCode,
                                              String issueNumber, String printIndicator) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getCardNumberEditField(), cardNumber);
        CoreFrameworkWeb.set(getCardTypeEditField(), cardType);
        CoreFrameworkWeb.set(getCardHolderIdEditField(), cardHolderID);
        CoreFrameworkWeb.set(getInquiryCodeEditField(), inquiryCode);
        CoreFrameworkWeb.set(getIssueNumberInputEditField(), issueNumber);

        if (!printIndicator.toLowerCase().contains("na")) {
            if (printIndicator.toLowerCase().contains("yes")) {
                CoreFrameworkWeb.set(getPrintIndicatorRadioGroup(), 0);
            } else {
                CoreFrameworkWeb.set(getPrintIndicatorRadioGroup(), 1);
            }
        }

        CoreFrameworkWeb.click(getSubmitButton(mainPage));

        if (cardType.contains("02") && cardHolderID.contains("001")
                && inquiryCode.contains("3") && printIndicator.toLowerCase().contains("no")) {

            return new BusinessCardInquiryPageChunk(mainPage).getBusinessInquiryValuesWithTable();

        } else if (cardType.contains("03") && cardHolderID.contains("001")
                && inquiryCode.contains("3") && printIndicator.toLowerCase().contains("no")) {

            return null;

        } else if (inquiryCode.contains("3") && printIndicator.toLowerCase().contains("no")) {

            return new BusinessCardInquiryPageChunk(mainPage).getAccountTypeAndShortNumber();

        }

        return null;

    }

    public HashMap<String, String> getBusinessInquiryValues() throws GeneralLeanFtException {
        HashMap<String, String> businessInquiryValues = new HashMap<>();

        businessInquiryValues.put("pageName1", "businessInquiryValues");
        businessInquiryValues.put("atm1", getAtmEditField().getValue().trim());
        Log.debug("ATM: " + getAtmEditField().getValue().trim());
        businessInquiryValues.put("atmLastDateUsed1", getAtmLastDateUsedEditField().getValue().trim());
        Log.debug("ATM Last Date Used: " + getAtmLastDateUsedEditField().getValue().trim());
        businessInquiryValues.put("branchStatus1", getBranchStatusEditField().getValue().trim());
        Log.debug("Branch Status: " + getBranchStatusEditField().getValue().trim());
        businessInquiryValues.put("branchStatusLastDateUsed1", getBranchStatusLastDateUsedEditField().getValue().trim());
        Log.debug("Branch Status Last Date Used: " + getBranchStatusLastDateUsedEditField().getValue().trim());
        businessInquiryValues.put("accountUpdated1", getAccountUpdatedEditField().getValue().trim());
        Log.debug("Account Updated: " + getAccountUpdatedEditField().getValue().trim());
        businessInquiryValues.put("accountUpdateLastDateUsed1", getAccountUpdateLastDateUsedEditField().getValue().trim());
        Log.debug("Account Updated Last Date Used: " + getAccountUpdateLastDateUsedEditField().getValue().trim());
        businessInquiryValues.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important: " + getImportantEditField().getValue().trim());

        return businessInquiryValues;

    }

    public HashMap<String, String> getBusinessInquiryValuesMoreInfo() throws GeneralLeanFtException {
        HashMap<String, String> businessInquiryValuesMoreInfo = new HashMap<>();
        businessInquiryValuesMoreInfo.put("pageName1", "businessInquiryValuesMoreInfo");
        businessInquiryValuesMoreInfo.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());
        businessInquiryValuesMoreInfo.put("cardStatus1", getCardStatusEditField().getValue().trim());
        Log.debug("Card Status: " + getCardStatusEditField().getValue().trim());
        businessInquiryValuesMoreInfo.put("date1", getDateEditField().getValue().trim());
        Log.debug("Date: " + getDateEditField().getValue().trim());
        businessInquiryValuesMoreInfo.put("issueStatus1", getIssueStatusEditField().getValue().trim());
        Log.debug("Issue Status: " + getIssueStatusEditField().getValue().trim());
        businessInquiryValuesMoreInfo.put("issueDate1", getIssueDateEditField().getValue().trim());
        Log.debug("Issue Date: " + getIssueDateEditField().getValue().trim());
        businessInquiryValuesMoreInfo.put("clientStatus1", getClientStatusEditField().getValue().trim());
        Log.debug("Client Status: " + getClientStatusEditField().getValue().trim());
        businessInquiryValuesMoreInfo.put("clientDate1", getClientDateEditField().getValue().trim());
        Log.debug("Client Date: " + getClientDateEditField().getValue().trim());
        businessInquiryValuesMoreInfo.put("onlinePin1", getOnlinePinEditField().getValue().trim());
        Log.debug("Online Pin: " + getOnlinePinEditField().getValue().trim());
        businessInquiryValuesMoreInfo.put("onlinePinDate1", getOnlinePinDateEditField().getValue().trim());
        Log.debug("Online Pin Date: " + getOnlinePinDateEditField().getValue().trim());
        businessInquiryValuesMoreInfo.put("pinDateEntered1", getPinDateEnteredEditField().getValue().trim());
        Log.debug("Date Pin Entered: " + getPinDateEnteredEditField().getValue().trim());
        businessInquiryValuesMoreInfo.put("atTransit1", getAtTransitEditField().getValue().trim());
        Log.debug("At Transit: " + getAtTransitEditField().getValue().trim());
        businessInquiryValuesMoreInfo.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important: " + getImportantEditField().getValue().trim());

        return businessInquiryValuesMoreInfo;

    }

    public HashMap<String, String> getBusinessInquiryValuesAllAccounts() throws GeneralLeanFtException {
        HashMap<String, String> businessInquiryValuesAllAccounts = new HashMap<>();

        businessInquiryValuesAllAccounts.put("pageName1", "businessInquiryAllAccounts");

        businessInquiryValuesAllAccounts.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());

        businessInquiryValuesAllAccounts.put("primaryChequing1", getPrimaryChequingEditField().getValue().trim());
        Log.debug("Primary Chequing: " + getPrimaryChequingEditField().getValue().trim());

        businessInquiryValuesAllAccounts.put("atmAccess1", getAtmAccessEditField().getValue().trim());
        Log.debug("Atm Access: " + getAtmAccessEditField().getValue().trim());

        businessInquiryValuesAllAccounts.put("primarySavings1", getPrimarySavingsEditField().getValue().trim());
        Log.debug("Primary Savings: " + getPrimarySavingsEditField().getValue().trim());

        businessInquiryValuesAllAccounts.put("savingAtmAccess1", getSavingAtmAccessEditField().getValue().trim());
        Log.debug("Savings Atm Access: " + getSavingAtmAccessEditField().getValue().trim());

        businessInquiryValuesAllAccounts.put("creditCard1", getCreditCardEditField().getValue().trim());
        Log.debug("Credit Card: " + getCreditCardEditField().getValue().trim());

        businessInquiryValuesAllAccounts.put("creditCardAtmAccess1", getCreditCardAtmAccessEditField().getValue().trim());
        Log.debug("Credit Card Atm Access: " + getSavingAtmAccessEditField().getValue().trim());

        businessInquiryValuesAllAccounts.put("rcl1", getRclEditField().getValue().trim());
        Log.debug("RCL: " + getRclEditField().getValue().trim());

        businessInquiryValuesAllAccounts.put("rclAtmAccess1", getRclAtmAccessEditField().getValue().trim());
        Log.debug("RCL Atm Access: " + getRclAtmAccessEditField().getValue().trim());

        businessInquiryValuesAllAccounts.put("atm1", getAtmEditField().getValue().trim());
        Log.debug("ATM: " + getAtmEditField().getValue().trim());

        businessInquiryValuesAllAccounts.put("pin1", getPinEditField().getValue().trim());
        Log.debug("PIN: " + getPinEditField().getValue().trim());

        businessInquiryValuesAllAccounts.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important: " + getImportantEditField().getValue().trim());

        /**
         * Iterates through the getsAccountTable1 data.
         */
        int rowSize = getAccountsTableAllAccounts().getRows().size();
        int colSize = getAccountsTableAllAccounts().getColumnHeaders().size();

        String otherChequing = "", shortNumberAtmAccessChequing = "", otherSavings = "", shortNumberAtmAccessSavings = "", otherCredits = "", shortNumberAtmAccessOtherCredits = "",
                otherLoans = "", shortNumberAtmAccessOtherLoans = "";

        if (rowSize > 1) {
            for (int i = 2; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    String cellValue = getAccountsTableAllAccounts().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                otherChequing = otherChequing + cellValue + " ";
                                break;
                            case 1:
                                shortNumberAtmAccessChequing = shortNumberAtmAccessChequing + cellValue + " ";
                                break;
                            case 2:
                                otherSavings = otherSavings + cellValue + " ";
                            case 3:
                                shortNumberAtmAccessSavings = shortNumberAtmAccessSavings + cellValue + " ";
                                break;
                            case 4:
                                otherCredits = otherCredits + cellValue + " ";
                                break;
                            case 5:
                                shortNumberAtmAccessOtherCredits = shortNumberAtmAccessOtherCredits + cellValue + " ";
                                break;
                            case 7:
                                otherLoans = otherLoans + cellValue + " ";
                                break;
                            case 8:
                                shortNumberAtmAccessOtherLoans = shortNumberAtmAccessOtherLoans + cellValue + " ";
                                break;
                        }
                    }

                    /*try {
                        otherChequing = otherChequing.substring(0, otherChequing.length());
                    } catch (Exception e) {

                        try {
                            otherSavings = otherSavings.substring(0, otherSavings.length());
                        } catch (Exception f) {
                        }
                        try {
                            otherCredits = otherCredits.substring(0, otherCredits.length());
                        } catch (Exception g) {
                        }
                        try {
                            otherLoans = otherLoans.substring(0, otherLoans.length());
                        } catch (Exception h) {
                        }

                        break;

                    }*/
                }
            }

            businessInquiryValuesAllAccounts.put("otherChequing1", otherChequing);
            Log.debug("Other Chequing: " + otherChequing);
            businessInquiryValuesAllAccounts.put("shortNumberAtmAccessChequing1", shortNumberAtmAccessChequing);
            Log.debug("Short Number ATM Access Chequing: " + shortNumberAtmAccessChequing);
            businessInquiryValuesAllAccounts.put("otherSavings1", otherSavings);
            Log.debug("Other Savings: " + otherSavings);
            businessInquiryValuesAllAccounts.put("shortNumberAtmAccessSavings1", shortNumberAtmAccessSavings);
            Log.debug("Short Number ATM Access Savings: " + shortNumberAtmAccessSavings);
            businessInquiryValuesAllAccounts.put("otherCredits1", otherCredits);
            Log.debug("Other Credits: " + otherCredits);
            businessInquiryValuesAllAccounts.put("shortNumberAtmAccessOtherCredits1", shortNumberAtmAccessOtherCredits);
            Log.debug("Short Number ATM Access Other Credits: " + shortNumberAtmAccessOtherCredits);
            businessInquiryValuesAllAccounts.put("otherLoans1", otherLoans);
            Log.debug("Other Loans: " + otherLoans);
            businessInquiryValuesAllAccounts.put("shortNumberAtmAccessOtherLoans1", shortNumberAtmAccessOtherLoans);
            Log.debug("Short Number ATM Access Other Loans: " + shortNumberAtmAccessOtherLoans);


        }


        return businessInquiryValuesAllAccounts;

    }

    public HashMap<String, String> getBusinessInquiryPrimaryCardStatus() throws GeneralLeanFtException {
        HashMap<String, String> businessInquiryPrimaryCardStatus = new HashMap<>();
        businessInquiryPrimaryCardStatus.put("pageName1", "businessInquiryPrimaryCardStatus");
        businessInquiryPrimaryCardStatus.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());
        businessInquiryPrimaryCardStatus.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());
        businessInquiryPrimaryCardStatus.put("cardStatus1", getCardStatusEditField().getValue().trim());
        Log.debug("Card Status: " + getCardStatusEditField().getValue().trim());
        businessInquiryPrimaryCardStatus.put("date1", getDateEditField().getValue().trim());
        Log.debug("Date: " + getDateEditField().getValue().trim());
        businessInquiryPrimaryCardStatus.put("issueStatus1", getIssueStatusEditField().getValue().trim());
        Log.debug("Issue Status: " + getIssueStatusEditField().getValue().trim());
        businessInquiryPrimaryCardStatus.put("issueDate1", getIssueDateEditField().getValue().trim());
        Log.debug("Issue Date: " + getIssueDateEditField().getValue().trim());
        businessInquiryPrimaryCardStatus.put("clientStatus1", getClientStatusEditField().getValue().trim());
        Log.debug("Client Status: " + getClientStatusEditField().getValue().trim());
        businessInquiryPrimaryCardStatus.put("releaseAmountCurrent1", getReleaseAmountEditField().getValue().trim());
        Log.debug("Release Amount: " + getReleaseAmountEditField().getValue().trim());
        businessInquiryPrimaryCardStatus.put("currentWithdraw1", getCurrentWithdrawEditField().getValue().trim());
        Log.debug("ATMt Withdrawal: " + getCurrentWithdrawEditField().getValue().trim());
        businessInquiryPrimaryCardStatus.put("currentPos1", getCurrentPosEditField().getValue().trim());
        Log.debug("POS Transaction: " + getCurrentPosEditField().getValue().trim());
        businessInquiryPrimaryCardStatus.put("current3PP1", getCurrent3PPEditField().getValue().trim());
        Log.debug("3PP/IET/IOP Transaction: " + getCurrent3PPEditField().getValue().trim());
        businessInquiryPrimaryCardStatus.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits Entitlement: " + getDailyAccessLimitEntitlementEditField().getValue().trim());
        businessInquiryPrimaryCardStatus.put("accountPackageEntitlement1", getAccountPackageEntitlementEditField().getValue().trim());
        Log.debug("Account Package Entitlement: " + getAccountPackageEntitlementEditField().getValue().trim());

        return businessInquiryPrimaryCardStatus;

    }

    public HashMap<String, String> getBusinessInquiryValuesAccessLimits() throws GeneralLeanFtException {
        HashMap<String, String> businessInquiryValuesAccessLimits = new HashMap<>();

        businessInquiryValuesAccessLimits.put("pageName1", "businessInquiryAccessLimits");

        businessInquiryValuesAccessLimits.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());

        businessInquiryValuesAccessLimits.put("releaseAmountCurrent1", getReleaseAmountEditField().getValue().trim());
        Log.debug("Release Amount Current: " + getReleaseAmountEditField().getValue().trim());

        businessInquiryValuesAccessLimits.put("releaseAmountMaximum1", getReleaseAmountMaximumtEditField().getValue().trim());
        Log.debug("Release Amount Current: " + getReleaseAmountMaximumtEditField().getValue().trim());

        businessInquiryValuesAccessLimits.put("numberTemporaryIncreaseThisYear1", getNumberTemporaryIncreaseThisYearEditField().getValue().trim());
        Log.debug("Number Temporary Increase This Year: " + getNumberTemporaryIncreaseThisYearEditField().getValue().trim());

        businessInquiryValuesAccessLimits.put("temporaryIncreaseExpiresOn1", getTemporaryIncreaseExpiresOnEditField().getValue().trim());
        Log.debug("Temporary Increase Expires On: " + getTemporaryIncreaseExpiresOnEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTableAllAccounts data.
         */
        int rowSize = getAccountsTableAccessLimits().getRows().size();
        int colSize = getAccountsTableAccessLimits().getColumnHeaders().size();

        String current = "", maximum = "", overrride = "", offline = "";

        if (rowSize > 1) {
            for (int i = 2; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    String cellValue = getAccountsTableAccessLimits().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 1:
                                current = current + cellValue + " ";
                                break;
                            case 2:
                                maximum = maximum + cellValue + " ";
                                break;
                            case 3:
                                overrride = overrride + cellValue + " ";
                                break;
                            case 4:
                                offline = offline + cellValue + " ";
                                break;
                        }
                    }
                }
            }

            businessInquiryValuesAccessLimits.put("current1", current);
            Log.debug("Current: " + current);
            businessInquiryValuesAccessLimits.put("maximum1", maximum);
            Log.debug("Maximum: " + maximum);
            businessInquiryValuesAccessLimits.put("override1", overrride);
            Log.debug("Override: " + overrride);
            businessInquiryValuesAccessLimits.put("offline1", offline);
            Log.debug("Offline: " + offline);

        }


        return businessInquiryValuesAccessLimits;

    }

    public HashMap<String, String> getBusinessInquiryValuesPrimaryCardProfile() throws GeneralLeanFtException {
        HashMap<String, String> businessInquiryValuesPrimaryCardProfile = new HashMap<>();

        businessInquiryValuesPrimaryCardProfile.put("pageName1", "businessInquiryValuesPrimaryCardProfile");

        businessInquiryValuesPrimaryCardProfile.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        businessInquiryValuesPrimaryCardProfile.put("cardNumber1", getCardNumberEditField().getValue().trim());
        Log.debug("Card Number: " + getCardNumberEditField().getValue().trim());

        businessInquiryValuesPrimaryCardProfile.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits Entitlement: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTableAllAccounts data.
         */
        int rowSize = getAccountsTablePrimaryBusinessCardDetails().getRows().size();
        int colSize = getAccountsTablePrimaryBusinessCardDetails().getColumnHeaders().size();

        String cardType = "", contactlessCardStatus = " ";

        if (rowSize > 1) {
            for (int i = 2; i < rowSize; i++) {
                for (int j = 0; j <= colSize; j++) {
                    String cellValue = getAccountsTablePrimaryBusinessCardDetails().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                cardType = cardType + cellValue + " ";
                                break;
                            case 1:
                                contactlessCardStatus = contactlessCardStatus + cellValue + " ";
                                break;

                        }
                    }
                }
            }

            businessInquiryValuesPrimaryCardProfile.put("cardType1", cardType);
            Log.debug("Card Type: " + cardType);
            businessInquiryValuesPrimaryCardProfile.put("contactlessCardStatus1", contactlessCardStatus);
            Log.debug("Contactless Card Status: " + contactlessCardStatus);


        }

        String  merchantCLL = " ";

        int rowSize1 = getAccountsTablePrimaryBusinessCardContactlessLimits().getRows().size();
        int columnSize1 = getAccountsTablePrimaryBusinessCardContactlessLimits().getRows().get(1).getCells().size();

        if (rowSize > 1) {
            for (int i = 2; i < rowSize1; i++) {
                for (int j = 0; j < columnSize1; j++) {
                    String cellValue = getAccountsTablePrimaryBusinessCardContactlessLimits().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                merchantCLL = merchantCLL + cellValue + " ";
                                break;

                        }
                    }
                }
            }

            businessInquiryValuesPrimaryCardProfile.put("merchant1", merchantCLL);
            Log.debug("Merchant: " + merchantCLL);



        }

        businessInquiryValuesPrimaryCardProfile.put("clssOtherCurrentLimit1", getClssOtherCurrentLimitEditField().getValue().trim());
        Log.debug("Other Current Limit: " + getClssOtherCurrentLimitEditField().getValue().trim());
        businessInquiryValuesPrimaryCardProfile.put("clssGasCurrentLimit1", getClssGasCurrentLimitEditField().getValue().trim());
        Log.debug("Gas Current Limit: " + getClssGasCurrentLimitEditField().getValue().trim());
        businessInquiryValuesPrimaryCardProfile.put("clssGroceryCurrentLimit1", getClssGroceryCurrentLimitEditField().getValue().trim());
        Log.debug("Grocery Current Limit: " + getClssGroceryCurrentLimitEditField().getValue().trim());
        businessInquiryValuesPrimaryCardProfile.put("clssMaxOtherLimit1", getClssMaxOtherLimitEditField().getValue().trim());
        Log.debug("Other Maximum Limit: " + getClssMaxOtherLimitEditField().getValue().trim());
        businessInquiryValuesPrimaryCardProfile.put("clssMaxGasLimit1", getClssMaxGasLimitEditField().getValue().trim());
        Log.debug("Gas Maximum Limit: " + getClssMaxGasLimitEditField().getValue().trim());
        businessInquiryValuesPrimaryCardProfile.put("clssMaxGrocercyLimit1", getClssMaxGrocercyLimitEditField().getValue().trim());
        Log.debug("Grocery Maximum Limit: " + getClssMaxGrocercyLimitEditField().getValue().trim());

        return businessInquiryValuesPrimaryCardProfile;

    }

    public HashMap<String, String> getBusinessInquiryValuesPrimaryABCCList() throws GeneralLeanFtException {
        HashMap<String, String> businessInquiryValuesPrimaryABCCList = new HashMap<>();

        businessInquiryValuesPrimaryABCCList.put("pageName1", "businessInquiryValuesPrimaryABCCList");

        businessInquiryValuesPrimaryABCCList.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        businessInquiryValuesPrimaryABCCList.put("issueNumber1", getIssueNumberEditField().getValue().trim());
        Log.debug("Issue Number: " + getIssueNumberEditField().getValue().trim());

        businessInquiryValuesPrimaryABCCList.put("cardStatus1", getCardStatusEditField().getValue().trim());
        Log.debug("Card Status: " + getCardStatusEditField().getValue().trim());

        businessInquiryValuesPrimaryABCCList.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits Entitlement: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        businessInquiryValuesPrimaryABCCList.put("accountPackageEntitlement1", getAccountPackageEntitlementEditField().getValue().trim());
        Log.debug("Account Package Entitlement: " + getAccountPackageEntitlementEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTablePrimaryBusinessPrimaryABCCList data.
         */
        int rowSize = getAccountsTablePrimaryBusinessPrimaryABCCList().getRows().size();
        int colSize = getAccountsTablePrimaryBusinessPrimaryABCCList().getRows().get(1).getCells().size();

        String select = "", abccId = "", cardHolderSFRNumber = "";

        if (rowSize > 1) {
            for (int i = 2; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    String cellValue = getAccountsTablePrimaryBusinessPrimaryABCCList().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                select = select + cellValue + " ";
                                break;
                            case 1:
                                abccId = abccId + cellValue + " ";
                                break;
                            case 2:
                                cardHolderSFRNumber = cardHolderSFRNumber + cellValue + " ";
                                break;
                        }
                    }
                }
            }

            businessInquiryValuesPrimaryABCCList.put("select1", select);
            Log.debug("Select: " + select);
            businessInquiryValuesPrimaryABCCList.put("abccId1", abccId);
            Log.debug("ABCC Id: " + abccId);
            businessInquiryValuesPrimaryABCCList.put("cardHolderSFRNumber1", cardHolderSFRNumber);
            Log.debug("Card Holder SRF Number: " + cardHolderSFRNumber);

        }


        return businessInquiryValuesPrimaryABCCList;

    }

    public HashMap<String, String> getBusinessInquiryValuesBusinessPrimaryHistory() throws GeneralLeanFtException {
        HashMap<String, String> businessInquiryValuesBusinessPrimaryHistory = new HashMap<>();

        businessInquiryValuesBusinessPrimaryHistory.put("pageName1", "businessInquiryValuesBusinessPrimaryHistory");

        /**
         * Iterates through the getAccountsTableBusinessPrimaryHistory data.
         */
        int rowSize = 2; //Row size set, as history is too long to validate. Only validating column headers names.
        //int colSize = getAccountsTableBusinessPrimaryHistory().getColumnHeaders().size();
        int colSize = getAccountsTableBusinessPrimaryHistory().getRows().get(0).getCells().size();

        String dateIssue = " ", timeFromAcct = " ", transactionToAcct = " ", amountBranchTransit = " ", authorizedByErrorCode = " ";

        if (rowSize > 0) {
            for (int i = 0; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    String cellValue = getAccountsTableBusinessPrimaryHistory().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                dateIssue = dateIssue + cellValue + " ";
                                break;
                            case 1:
                                timeFromAcct = timeFromAcct + cellValue + " ";
                                break;
                            case 2:
                                transactionToAcct = transactionToAcct + cellValue + " ";
                                break;
                            case 3:
                                amountBranchTransit = amountBranchTransit + cellValue + " ";
                                break;
                            case 6:
                                authorizedByErrorCode = authorizedByErrorCode + cellValue + " ";
                                break;

                        }
                    }
                }
            }

            businessInquiryValuesBusinessPrimaryHistory.put("dateIssue1", dateIssue);
            Log.debug("Date Issue : " + dateIssue);
            businessInquiryValuesBusinessPrimaryHistory.put("timeFromAcct1", timeFromAcct);
            Log.debug("Time From Account: " + timeFromAcct);
            businessInquiryValuesBusinessPrimaryHistory.put("transactionToAcct1", transactionToAcct);
            Log.debug("Transaction To Acct: " + transactionToAcct);
            businessInquiryValuesBusinessPrimaryHistory.put("amountBranchTransit1", amountBranchTransit);
            Log.debug("Amount Branch Transit: " + amountBranchTransit);
            businessInquiryValuesBusinessPrimaryHistory.put("authorizedByErrorCode1", authorizedByErrorCode);
            Log.debug("Authorized By Error Code : " + authorizedByErrorCode);


        }

        return businessInquiryValuesBusinessPrimaryHistory;

    }

    public HashMap<String, String> getBusinessInquiryValuesBusinessPrimaryAgentCard() throws GeneralLeanFtException {
        HashMap<String, String> businessInquiryValuesBusinessPrimaryAgentCard = new HashMap<>();

        businessInquiryValuesBusinessPrimaryAgentCard.put("pageName1", "businessInquiryValuesBusinessPrimaryAgentCard");

        businessInquiryValuesBusinessPrimaryAgentCard.put("cardHolderId1", getCardHolderIdEditField().getValue().trim());
        Log.debug("Card Holder Id: " + getCardHolderIdEditField().getValue().trim());

        businessInquiryValuesBusinessPrimaryAgentCard.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits Entitlement: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTableBusinessPrimaryHistory() data.
         */
        int rowSize = getAccountsTablePrimaryBusinessAgentCard().getRows().size();
        int colSize = getAccountsTablePrimaryBusinessAgentCard().getRows().get(1).getCells().size();

        String agentId = " ", cardStatus = " ", issueNumber = " ", lastIssueUsed = " ";

        if (rowSize > 0) {
            for (int i = 2; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    String cellValue = getAccountsTablePrimaryBusinessAgentCard().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                agentId = agentId + cellValue + " ";
                                break;
                            case 1:
                                cardStatus = cardStatus + cellValue + " ";
                                break;
                            case 2:
                                issueNumber = issueNumber + cellValue + " ";
                                break;
                            case 3:
                                lastIssueUsed = lastIssueUsed + cellValue + " ";
                                break;

                        }
                    }
                }
            }

            businessInquiryValuesBusinessPrimaryAgentCard.put("agentId1", agentId);
            Log.debug("Agent Id: " + agentId);
            businessInquiryValuesBusinessPrimaryAgentCard.put("cardStatus1", cardStatus);
            Log.debug("Card Status: " + cardStatus);
            businessInquiryValuesBusinessPrimaryAgentCard.put("issueNumber1", issueNumber);
            Log.debug("Issue Number: " + issueNumber);
            businessInquiryValuesBusinessPrimaryAgentCard.put("lastIssueUsed1", lastIssueUsed);
            Log.debug("Last Issue Used: " + lastIssueUsed);

        }

        return businessInquiryValuesBusinessPrimaryAgentCard;

    }

    //Table

    private Table getAccountsTableAllAccounts() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Chequing Savings Credit Cards.*")).build());
    }

    private Table getAccountsTableBusinessPrimaryHistory() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*DateTimeTransactionAmountBanking Machine IDReceipt.*")).build());

    }

    private Table getAccountsTableAccessLimits() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Transaction Type Current Maximum Override Offline.*")).build());

    }

    private Table getAccountsTablePrimaryBusinessCardDetails() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Card Type Contactless Card Status.*")).build());

    }

    private Table getAccountsTablePrimaryBusinessCardContactlessLimits() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Merchant Current Maximum.*")).build());

    }

    private Table getAccountsTablePrimaryBusinessPrimaryABCCList() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*SelectABCC IDCardholder SRF Number.*")).build());

    }

    private Table getAccountsTablePrimaryBusinessAgentCard() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Agent IDCard StatusIssue NumberLast Issue Used.*")).build());

    }

    //    /* -- Get Objects --*/

    private EditField getCardNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("displayCardNumber").index(0).build());
    }

    private EditField getCardTypeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("cardType").build());
    }

    private EditField getCardHolderIdEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("cardHolderId").build());
    }

    private EditField getInquiryCodeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("inquiryCode").build());
    }

    private EditField getIssueNumberInputEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("issueNumberInput").build());
    }

    private EditField getIssueNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("issueNumber").build());
    }

    private RadioGroup getPrintIndicatorRadioGroup() {
        return GetObjectWeb.getRadioGroupObject(getMainPage(), new RadioGroupDescription.Builder()
                .tagName("INPUT").name("printIndicator").build());
    }

    private WebElement getInquiryHeaderWebElement() {
        return GetObjectWeb.getWebElementObject(mainPage, new WebElementDescription.Builder()
                .tagName("H1").innerText(new RegExpProperty(".*Inquiry.*|.*Interrogation.*")).build());
    }

    private EditField getClientNameEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clientName").build());

    }

    private EditField getAtmEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("atm").build());

    }

    private EditField getAtmLastDateUsedEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("atmLastDateUsed").build());

    }

    private EditField getBranchStatusEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("branchStatus").build());

    }

    private EditField getBranchStatusLastDateUsedEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("branchStatusLastDateUsed").build());

    }

    private EditField getAccountUpdatedEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("accountUpdated").build());

    }

    private EditField getAccountUpdateLastDateUsedEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("accountUpdateLastDateUsed").build());

    }

    private EditField getImportantEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("important").build());

    }

    private EditField getLanguageEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("language").index(0).build());

    }

    private EditField getCardStatusEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("cardStatus").index(1).build());

    }

    private EditField getDateEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("date").build());

    }

    private EditField getIssueStatusEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("issueStatus").build());

    }

    private EditField getIssueDateEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("issueDate").build());

    }

    private EditField getClientStatusEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clientStatus").build());

    }

    private EditField getClientDateEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clientDate").build());

    }

    private EditField getOnlinePinEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("onlinePin").build());

    }

    private EditField getOnlinePinDateEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("onlinePinDate").build());

    }

    private EditField getPinDateEnteredEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("pinDateEntered").build());

    }

    private EditField getAtTransitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("atTransit").build());

    }

    private EditField getReleaseAmountEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("releaseAmountCurrent").build());
    }

    private EditField getReleaseAmountMaximumtEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("releaseAmountMaximum").build());
    }

    private EditField getCurrentWithdrawEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("currentWithdraw").build());
    }

    private EditField getNumberTemporaryIncreaseThisYearEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("numberTemporaryIncreaseThisYear").build());
    }

    private EditField getTemporaryIncreaseExpiresOnEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("temporaryIncreaseExpiresOn").build());
    }

    private EditField getCurrentPosEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("currentPos").build());
    }

    private EditField getCurrent3PPEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("current3PP").build());
    }

    private EditField getDailyAccessLimitEntitlementEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("dailyAccessLimits").build());
    }

    private EditField getAccountPackageEntitlementEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("accountPackageEntitlement").build());
    }

    private EditField getPrimaryChequingEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("primaryChequing").build());
    }

    private EditField getAtmAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("atmAccess").build());
    }

    private EditField getPrimarySavingsEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("primarySavings").build());
    }

    private EditField getSavingAtmAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("savingAtmAccess").build());
    }

    private EditField getCreditCardEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("creditCard").build());

    }

    private EditField getCreditCardAtmAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("creditCardATMAccess").build());

    }

    private EditField getRclEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("rcl").build());

    }

    private EditField getRclAtmAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("rclATMAccess").build());

    }

    private EditField getPinEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("pin").build());

    }

    private EditField getClssOtherCurrentLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clssOtherCurrentLimit").build());

    }

    private EditField getClssGasCurrentLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clssGasCurrentLimit").build());

    }

    private EditField getClssGroceryCurrentLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clssGroceryCurrentLimit").build());

    }

    private EditField getClssMaxOtherLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clssMaxOtherLimit").build());

    }

    private EditField getClssMaxGasLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clssMaxGasLimit").build());

    }

    private EditField getClssMaxGrocercyLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clssMaxGrocercyLimit").build());

    }

}
