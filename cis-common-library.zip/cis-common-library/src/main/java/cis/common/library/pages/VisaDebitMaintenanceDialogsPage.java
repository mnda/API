package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.*;
import com.hp.lft.sdk.winforms.WindowDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class VisaDebitMaintenanceDialogsPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public VisaDebitMaintenanceDialogsPage() {
        mainPage = getVisaDebitDialogPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing VisaDebitMaintenanceDialogsPage...");
        SyncHelperWeb.waitForElementToAppear(getSubmitButton(mainPage));
        Log.debug("VisaDebitMaintenanceDialogsPage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        CoreFrameworkWeb.cleanupSDK();
    }

    public void enterClientNumber(String numberType, String number, String visaType) throws GeneralLeanFtException {
        CoreFrameworkWeb.click(getClearButtonImage());
        if (numberType.toLowerCase().contains("client")) {
            CoreFrameworkWeb.set(getClientCardNumberEditField(), number);
        } else {
            CoreFrameworkWeb.set(getVisaDebitCardNumberEditField(), number);
        }
        if (getVisaDebitTypeList().exists(1)) {
            int choice = 0;
            switch (visaType.toLowerCase()) {
                case "virtual visa Debit":
                    choice = 0;
                    break;
                case "we virtual visa debit":
                    choice = 1;
                    break;
                case "we impact virtual visa debit":
                    choice = 2;
                    break;
            }


            CoreFrameworkWeb.set(getVisaDebitTypeList(), choice);
        }
        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }


    public void enterClientandDebitNumbers(String clientCardNumber, String visaCardNumber, String visaType) throws GeneralLeanFtException {
        CoreFrameworkWeb.click(getClearButtonImage());
        CoreFrameworkWeb.set(getClientCardNumberEditField(), clientCardNumber);
        CoreFrameworkWeb.set(getVisaDebitCardNumberEditField(), visaCardNumber);
        if (getVisaDebitTypeList().exists(1)) {
            int choice = 0;
            switch (visaType.toLowerCase()) {
                case "virtual visa Debit":
                    choice = 0;
                    break;
                case "we virtual visa debit":
                    choice = 1;
                    break;
                case "we impact virtual visa debit":
                    choice = 2;
                    break;
            }


            CoreFrameworkWeb.set(getVisaDebitTypeList(), choice);
        }
        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }

    //    /* -- Get Objects --*/
    public Page getVisaDebitDialogPage() {
        return GetObjectWeb.getDialogPageObject(new WindowDescription.Builder()
                .windowTitleRegExp(new RegExpProperty(".*Client Identification System")).build(), new WindowDescription.Builder()
                .windowTitleRegExp(new RegExpProperty(".*SIC - Système d'identification des clients.*|.*CIS - Client Identification System.*")).build(), new PageDescription.Builder()
                .title(new RegExpProperty(".*SIC - Système d'identification des clients.*|.*CIS - Client Identification System.*")).build());
    }

    private Image getClearButtonImage() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .alt(new RegExpProperty("Clear Button|Bouton Effacer")).type(ImageType.LINK).tagName("IMG").build());
    }

    private EditField getVisaDebitCardNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("visaDebitCardNumber").build());
    }

    private EditField getClientCardNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clientCardNumber").build());
    }

    private ListBox getVisaDebitTypeList() {
        return GetObjectWeb.getListBoxObject(mainPage, new ListBoxDescription.Builder()
                .tagName("SELECT").name("visaDebitType").build());
    }

    private WebElement getCardErrorWebElement() {
        return GetObjectWeb.getWebElementObject(mainPage, new WebElementDescription.Builder()
                .tagName("H2").innerText("CIS101E - Invalid Card Entered").build());
    }


    //***** ENUMS *****//
    public enum VisaDebitFunctions {
        Replacement("Replacement"),
        LostStolenWithReplacement("LostStolenWithReplacement"),
        LostStolenWithoutReplacement("LostStolenWithoutReplacement"),
        VisaDebitHot("VisaDebitHot"),
        NormalStatus("NormalStatus"),
        CancelVisaDebit("CancelVisaDebit"),
        VisaDebitApplication("VisaDebitApplication"),
        VisaDebitLimitsChange("VisaDebitLimitsChange");

        private final String text;

        VisaDebitFunctions(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }
}
