//package cis.common.library.locators;
//
//import com.hp.lft.sdk.Desktop;
//import com.hp.lft.sdk.RegExpProperty;
//import com.hp.lft.sdk.winforms.Window;
//import com.hp.lft.sdk.winforms.WindowDescription;
//import com.manulife.auto.pom.core.CoreFramework;
//import com.manulife.auto.pom.core.helper.Log;
//
///**
// * Created by angmark on 6/6/2017.
// */
//public class Locators {
//
//    public static String strMachine;
//
//    private static String getTestMachine() {
//        try {
//            if (System.getProperty("testMachine").toLowerCase().contains("vm")) {
//
//                strMachine = "vm";
//            } else {
//                strMachine = "local";
//            }
//        } catch (Throwable t) {
//            strMachine = "local";
//        }
//        Log.debug("Environment being used is:" + strMachine);
//        return strMachine;
//    }
//
//    public static class LoginPage {
//        public static Window mainWindow() throws Exception {
//            Window window = Desktop.describe(Window.class, new WindowDescription.Builder()
//                    .windowClassRegExp("SunAwtFrame").windowTitleRegExp(new RegExpProperty("Apex Collateral.*Login")).build());
//            CoreFramework.maximizeWindow(window);
//            return window;
//        }
//
//        public static final String OK_BUTTON = "images/" + getTestMachine() + "/login_page/ok_button.png";
//        public static final String USER_FIELD = "images/" + getTestMachine() + "/login_page/user_editfield.png";
//        public static final String PASSWORD_FIELD = "images/" + getTestMachine() + "/login_page/password_editfield.png";
//    }
//
//    public static class MainPage {
//        public static Window mainWindow() throws Exception {
//            Window window = Desktop.describe(Window.class, new WindowDescription.Builder()
//                    .text(new RegExpProperty("Apex Collateral.*")).windowClassRegExp("SunAwtFrame").build());
//            CoreFramework.maximizeWindow(window);
//            return window;
//        }
//
//        public static final String COLLATERALRD_TAB = "images/" + getTestMachine() + "/main_page/collateralrd_tab.png";
//
//        public static class CollateralRDChunk {
//            public static final String TRADE_ID_COLUMN = "images/" + getTestMachine() + "/main_page/collateralrd_chunk/tradeid_column.png";
//            public static final String NEW_CASH_RECEIVE_MENU = "images/" + getTestMachine() + "/main_page/collateralrd_chunk/newcashcollateralreceive_menu.png";
//            public static final String NEW_CASH_DELIVER_MENU = "images/" + getTestMachine() + "/main_page/collateralrd_chunk/newcashcollateraldeliver_menu.png";
//            public static final String NEW_SEC_RECEIVE_MENU = "images/" + getTestMachine() + "/main_page/collateralrd_chunk/newcollateralreceive_menu.png";
//            public static final String NEW_SEC_DELIVER_MENU = "images/" + getTestMachine() + "/main_page/collateralrd_chunk/newcollateraldeliver_menu.png";
//            public static final String COPY_TRADE_MENU = "images/" + getTestMachine() + "/main_page/collateralrd_chunk/copytrade_menu.png";
//            public static final String EDIT_TRADE_MENU = "images/" + getTestMachine() + "/main_page/collateralrd_chunk/edittrade_menu.png";
//        }
//
//        public static class SettlementRDChunk {
//            public static class SettlementUpdateChunk {
//                public static Window mainWindow() throws Exception {
//                    Window window = Desktop.describe(Window.class, new WindowDescription.Builder()
//                            .text(new RegExpProperty("Apex Collateral.*")).windowClassRegExp("SunAwtFrame").build()).describe(Window.class, new WindowDescription.Builder()
//                            .windowClassRegExp("SunAwtDialog").windowTitleRegExp(new RegExpProperty("Settlement Update.*")).build());
//                    CoreFramework.maximizeWindow(window);
//                    return window;
//                }
//            }
//        }
//
//        public static class PartialReturnChunk {
//            public static Window mainWindow() throws Exception {
//                Window window = Desktop.describe(Window.class, new WindowDescription.Builder()
//                        .text(new RegExpProperty("Apex Collateral.*")).build()).describe(Window.class, new WindowDescription.Builder()
//                        .text(new RegExpProperty("Partial Return.*")).build());
//
////                        Desktop.describe(Window.class, new WindowDescription.Builder()
////                        .text(new RegExpProperty("Apex Collateral.*")).windowClassRegExp("SunAwtFrame").build()).describe(Window.class, new WindowDescription.Builder()
////                        .windowClassRegExp("SunAwtDialog").windowTitleRegExp(new RegExpProperty("Partial Return.*")).build());
//
//
//                CoreFramework.maximizeWindow(window);
//                return window;
//            }
//        }
//    }
//
//    public static class CashCollateralPage {
//        public static Window mainWindow() throws Exception {
//            Window window = Desktop.describe(Window.class, new WindowDescription.Builder()
//                    .text(new RegExpProperty("Apex Collateral.*")).windowClassRegExp("SunAwtFrame").build()).describe(Window.class, new WindowDescription.Builder()
//                    .text(new RegExpProperty("Cash Collateral.*")).windowClassRegExp("SunAwtDialog").build());
//            CoreFramework.maximizeWindow(window);
//            return window;
//        }
//
//        public static class TradedCashChunk {
//            public static final String CASHVALUE_FIELDS = "images/" + getTestMachine() + "/cashcollateral_page/tradedcash_chunk/cashvalue_fields.png";
//            public static final String MARGINTYPE_LISTFIELD = "images/" + getTestMachine() + "/cashcollateral_page/tradedcash_chunk/margintype_listfield.png";
//        }
//    }
//
//    public static class SharedCollateralPage {
//        public static Window mainWindow() throws Exception {
//            Window window = Desktop.describe(Window.class, new WindowDescription.Builder()
//                    .text(new RegExpProperty("Apex Collateral.*")).windowClassRegExp("SunAwtFrame").build()).describe(Window.class, new WindowDescription.Builder()
//                    .text(new RegExpProperty(".*Collateral.*")).windowClassRegExp("SunAwtDialog").build());
//            CoreFramework.maximizeWindow(window);
//            return window;
//        }
//
//        public static final String OPENINGSETTLEMENT_TAB = "images/" + getTestMachine() + "/cashcollateral_page/openingsettlement_tab.png";
//        public static final String CLOSINGSETTLEMENT_TAB = "images/" + getTestMachine() + "/cashcollateral_page/closingsettlement_tab.png";
//        public static final String EVENTHISTORY_TAB = "images/" + getTestMachine() + "/cashcollateral_page/eventhistory_tab.png";
//        public static final String OK_BUTTON = "images/" + getTestMachine() + "/cashcollateral_page/ok_button.png";
//
//        public static class OwnerChunk {
//            public static final String OWNER_LISTFIELD = "images/" + getTestMachine() + "/cashcollateral_page/owner_chunk/owner_listfield.png";
//        }
//
//        public static class CounterPartyChunk {
//
//            public static final String COUNTERPARTY_EDITFIELD = "images/" + getTestMachine() + "/cashcollateral_page/counterparty_chunk/counterparty_editfield.png";
//            public static final String FIND_BUTTON = "images/" + getTestMachine() + "/cashcollateral_page/counterparty_chunk/find_button.png";
//            public static final String AGREEMENT_LISTFIELD = "images/" + getTestMachine() + "/cashcollateral_page/counterparty_chunk/agreement_listfield.png";
//
//            public static class CounterPartySelectionChunk {
//                public static Window mainWindow() throws Exception {
//                    Window window = Desktop.describe(Window.class, new WindowDescription.Builder()
//                            .text(new RegExpProperty("Apex Collateral.*")).windowClassRegExp("SunAwtFrame").build()).describe(Window.class, new WindowDescription.Builder()
//                            .windowClassRegExp("SunAwtDialog").windowTitleRegExp("Counterparty Selection").build());
//                    CoreFramework.maximizeWindow(window);
//                    return window;
//                }
//
//                public static final String IDENTIFIER_COLUMN = "images/" + getTestMachine() + "/cashcollateral_page/counterpartyselection_chunk/identifier_column.png";
//                public static final String SELECT_BUTTON = "images/" + getTestMachine() + "/cashcollateral_page/counterpartyselection_chunk/select_button.png";
//            }
//        }
//
//        public static class OpeningClosingSettlementChunk {
//            public static final String TRADEDATE_EDITFIELD = "images/" + getTestMachine() + "/cashcollateral_page/openingsettlement_chunk/tradedate_editfield.png";
//            public static final String CPINSTRUCTIONS_EDITFIELD = "images/" + getTestMachine() + "/cashcollateral_page/openingsettlement_chunk/cpinstructions_editfield.png";
//            public static final String SETTLEMENTTYPE_LISTFIELD = "images/" + getTestMachine() + "/cashcollateral_page/openingsettlement_chunk/settlementtype_listfield.png";
//            public static final String CONFIRMATIONTYPE_LISTFIELD = "images/" + getTestMachine() + "/cashcollateral_page/openingsettlement_chunk/confirmationtype_listfield.png";
//            public static final String CPPAYMENTINSTRUCTIONS_LISTFIELD = "images/" + getTestMachine() + "/cashcollateral_page/openingsettlement_chunk/cppaymentinstructions_listfield.png";
//            public static final String OWNPAYMENTINSTRUCTIONS_LISTFIELD = "images/" + getTestMachine() + "/cashcollateral_page/openingsettlement_chunk/ownpaymentinstuctions_listfield.png";
//            public static final String CPINSTRUCTIONS_LISTFIELD = "images/" + getTestMachine() + "/cashcollateral_page/openingsettlement_chunk/cpinstructions_listfield.png";
//            public static final String OWNINSTRUCTIONS_LISTFIELD = "images/" + getTestMachine() + "/cashcollateral_page/openingsettlement_chunk/owninstuctions_listfield.png";
//            public static final String PAYMENT_DATE_EDITFIELD = "images/" + getTestMachine() + "/cashcollateral_page/openingsettlement_chunk/paymentdate_editfield.png";
//            public static final String SETTLEMENT_DATE_EDITFIELD = "images/" + getTestMachine() + "/cashcollateral_page/openingsettlement_chunk/settlementdate_editfield.png";
//        }
//
//        public static class IgnoreWarningsChunk {
//            public static Window mainWindow() throws Exception {
//                Window window = Desktop.describe(Window.class, new WindowDescription.Builder()
//                        .text(new RegExpProperty("Apex Collateral.*")).windowClassRegExp("SunAwtFrame").build()).describe(Window.class, new WindowDescription.Builder()
//                        .windowClassRegExp("SunAwtDialog").windowTitleRegExp("Ignore Warnings").build());
//                CoreFramework.maximizeWindow(window);
//                return window;
//            }
//
//            public static final String YES_BUTTON = "images/" + getTestMachine() + "/cashcollateral_page/ignorewarnings_chunk/yes_button.png";
//
//        }
//
//        public static class EventHistoryChunk {
//            public static final String REVERSEEVENT_BUTTON = "images/" + getTestMachine() + "/cashcollateral_page/eventhistory_chunk/reverseevent_button.png";
//            public static final String EVENTID_COLUMN = "images/" + getTestMachine() + "/cashcollateral_page/eventhistory_chunk/eventid_column.png";
//        }
//
//        public static class ConfirmReversalChunk {
//            public static Window mainWindow() throws Exception {
//                Window window = Desktop.describe(Window.class, new WindowDescription.Builder()
//                        .text(new RegExpProperty("Apex Collateral.*")).windowClassRegExp("SunAwtFrame").build()).describe(Window.class, new WindowDescription.Builder()
//                        .windowClassRegExp("SunAwtDialog").windowTitleRegExp(new RegExpProperty("Confirm reversal.*")).build());
//                CoreFramework.maximizeWindow(window);
//                return window;
//            }
//
//            public static final String REVERSALREASONTYPE_LISTFIELD = "images/" + getTestMachine() + "/cashcollateral_page/confirmreversal_chunk/reversalreasontype_listfield.png";
//            public static final String OK_BUTTON = "images/" + getTestMachine() + "/cashcollateral_page/confirmreversal_chunk/ok_button.png";
//            public static final String SWIFT_CHECKBOX = "images/" + getTestMachine() + "/cashcollateral_page/confirmreversal_chunk/swift_cancellation_checkbox.png";
//
//        }
//
//
//    }
//
//    public static class SecurityCollateralPage {
//        public static Window mainWindow() throws Exception {
//            Window window = Desktop.describe(Window.class, new WindowDescription.Builder()
//                    .text(new RegExpProperty("Apex Collateral.*")).windowClassRegExp("SunAwtFrame").build()).describe(Window.class, new WindowDescription.Builder()
//                    .text(new RegExpProperty("Collateral.*")).windowClassRegExp("SunAwtDialog").build());
//            CoreFramework.maximizeWindow(window);
//            return window;
//        }
//
//        public static class TradedSecurityChunk {
//            public static final String SECURITY_EDITFIELD = "images/" + getTestMachine() + "/securitycollateral_page/tradedsecurity_chunk/security_editfield.png";
//            public static final String QUANTITY_EDITFIELD = "images/" + getTestMachine() + "/securitycollateral_page/tradedsecurity_chunk/quantity_editfield.png";
//
//        }
//    }
//
//    // Allocation Page
//
//    public static class AllocationMainPage {
//        public static Window mainWindow() throws Exception {
//            Window window = Desktop.describe(Window.class, new WindowDescription.Builder()
//                    .text(new RegExpProperty("Apex Collateral.*Allocation.*")).windowClassRegExp("SunAwtFrame").build());
//            CoreFramework.maximizeWindow(window);
//            return window;
//        }
//    }
//
//
//}
