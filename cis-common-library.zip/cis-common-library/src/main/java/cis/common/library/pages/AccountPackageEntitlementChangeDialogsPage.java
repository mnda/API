package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.*;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class AccountPackageEntitlementChangeDialogsPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public AccountPackageEntitlementChangeDialogsPage() throws GeneralLeanFtException {
        mainPage = getDialogPage();
        //CoreFrameworkWeb.click(this.);
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing AccountPackageEntitlementChangeDialoguePage...");

        SyncHelperWeb.waitForElementToAppear(getOkButtonImage());
        Log.debug("AccountPackageEntitlementChangeDialoguePage successfully initialized");

    }

    public static void main(String[] args) throws Exception{
        CoreFrameworkWeb.instantiateSDK();
        AccountPackageEntitlementChangeDialogsPage page = new AccountPackageEntitlementChangeDialogsPage();
        //test page and function here...
        CoreFrameworkWeb.cleanupSDK();

    }

    //    /* -- Get Objects --*/

    private Image getOkButtonImage() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .alt("Ok Button").type(ImageType.LINK).tagName("IMG").build());
    }

}
