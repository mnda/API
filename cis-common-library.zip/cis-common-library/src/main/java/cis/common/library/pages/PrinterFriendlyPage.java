package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.*;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;

import java.util.HashMap;


/**
 * Created by angmark on 5/25/2017.
 */
public class PrinterFriendlyPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public PrinterFriendlyPage() {
        mainPage = getDialogPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        SyncHelperWeb.waitForElementToAppear(getRBCLogoImage());
        Log.debug("PrinterFriendlyPage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        System.setProperty("logDebug", "true");
        PrinterFriendlyPage page = new PrinterFriendlyPage();
        page.getPersonalDebitInquiryCardProfile();
        CoreFrameworkWeb.cleanupSDK();

    }

    public HashMap<String, String> getBusinessInquiryPrinterValues() throws GeneralLeanFtException {
        HashMap<String, String> businessInquiryPrinterValues = new HashMap<>();

        businessInquiryPrinterValues.put("pageName1", "businessInquiryPrinterValues");
        businessInquiryPrinterValues.put("atm1", getAtmEditField().getValue().trim());
        Log.debug("ATM: " + getAtmEditField().getValue().trim());
        businessInquiryPrinterValues.put("atmLastDateUsed1", getAtmLastDateUsedEditField().getValue().trim());
        Log.debug("ATM Last Date Used: " + getAtmLastDateUsedEditField().getValue().trim());
        businessInquiryPrinterValues.put("branchStatus1", getBranchStatusEditField().getValue().trim());
        Log.debug("Branch Status: " + getBranchStatusEditField().getValue().trim());
        businessInquiryPrinterValues.put("branchStatusLastDateUsed1", getBranchStatusLastDateUsedEditField().getValue().trim());
        Log.debug("Branch Status Last Date Used: " + getBranchStatusLastDateUsedEditField().getValue().trim());
        businessInquiryPrinterValues.put("accountUpdated1", getAccountUpdatedEditField().getValue().trim());
        Log.debug("Account Updated: " + getAccountUpdatedEditField().getValue().trim());
        businessInquiryPrinterValues.put("accountUpdateLastDateUsed1", getAccountUpdateLastDateUsedEditField().getValue().trim());
        Log.debug("Account Updated Last Date Used: " + getAccountUpdateLastDateUsedEditField().getValue().trim());
        businessInquiryPrinterValues.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important: " + getImportantEditField().getValue().trim());

        return businessInquiryPrinterValues;

    }

    public HashMap<String, String> getBusinessInquiryPrinterValuesMoreInfo() throws GeneralLeanFtException {
        HashMap<String, String> businessInquiryPrinterValuesMoreInfo = new HashMap<>();

        businessInquiryPrinterValuesMoreInfo.put("pageName1", "businessInquiryPrinterValuesMoreInfo");
        businessInquiryPrinterValuesMoreInfo.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());
        businessInquiryPrinterValuesMoreInfo.put("cardStatus1", getCardStatusEditField().getValue().trim());
        Log.debug("Card Status: " + getCardStatusEditField().getValue().trim());
        businessInquiryPrinterValuesMoreInfo.put("date1", getDateEditField().getValue().trim());
        Log.debug("Date: " + getDateEditField().getValue().trim());
        businessInquiryPrinterValuesMoreInfo.put("issueStatus1", getIssueStatusEditField().getValue().trim());
        Log.debug("Issue Status: " + getIssueStatusEditField().getValue().trim());
        businessInquiryPrinterValuesMoreInfo.put("issueDate1", getIssueDateEditField().getValue().trim());
        Log.debug("Issue Date: " + getIssueDateEditField().getValue().trim());
        businessInquiryPrinterValuesMoreInfo.put("clientStatus1", getClientStatusEditField().getValue().trim());
        Log.debug("Client Status: " + getClientStatusEditField().getValue().trim());
        businessInquiryPrinterValuesMoreInfo.put("clientDate1", getClientDateEditField().getValue().trim());
        Log.debug("Client Date: " + getClientDateEditField().getValue().trim());
        businessInquiryPrinterValuesMoreInfo.put("onlinePin1", getOnlinePinEditField().getValue().trim());
        Log.debug("Online Pin: " + getOnlinePinEditField().getValue().trim());
        businessInquiryPrinterValuesMoreInfo.put("onlinePinDate1", getOnlinePinDateEditField().getValue().trim());
        Log.debug("Online Pin Date: " + getOnlinePinDateEditField().getValue().trim());
        businessInquiryPrinterValuesMoreInfo.put("pinDateEntered1", getPinDateEnteredEditField().getValue().trim());
        Log.debug("Date Pin Entered: " + getPinDateEnteredEditField().getValue().trim());
        businessInquiryPrinterValuesMoreInfo.put("atTransit1", getAtTransitEditField().getValue().trim());
        Log.debug("At Transit: " + getAtTransitEditField().getValue().trim());
        businessInquiryPrinterValuesMoreInfo.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important: " + getImportantEditField().getValue().trim());

        return businessInquiryPrinterValuesMoreInfo;

    }

    public HashMap<String, String> getBusinessInquiryPrinterValuesWithTable() throws GeneralLeanFtException {
        HashMap<String, String> businessInquiryPrinterValuesWithTable = new HashMap<>();

        businessInquiryPrinterValuesWithTable.put("pageName1", "businessInquiryPrinterValuesWithTable");

        businessInquiryPrinterValuesWithTable.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());

        businessInquiryPrinterValuesWithTable.put("atm1", getAtmEditField().getValue().trim());
        Log.debug("ATM: " + getAtmEditField().getValue().trim());

        businessInquiryPrinterValuesWithTable.put("pin1", getPinEditField().getValue().trim());
        Log.debug("PIN: " + getPinEditField().getValue().trim());

        businessInquiryPrinterValuesWithTable.put("primaryChequing1", getPrimaryChequingEditField().getValue().trim());
        Log.debug("Primary Chequing: " + getPrimaryChequingEditField().getValue().trim());

        businessInquiryPrinterValuesWithTable.put("primarySavings1", getPrimarySavingsEditField().getValue().trim());
        Log.debug("Primary Savings: " + getPrimarySavingsEditField().getValue().trim());

        businessInquiryPrinterValuesWithTable.put("creditCard1", getCreditCardEditField().getValue().trim());
        Log.debug("Credit Card: " + getCreditCardEditField().getValue().trim());

        businessInquiryPrinterValuesWithTable.put("rcl1", getRclEditField().getValue().trim());
        Log.debug("RCL: " + getRclEditField().getValue().trim());

        businessInquiryPrinterValuesWithTable.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important: " + getImportantEditField().getValue().trim());

        /**
         * Iterates through the getsAccountTable1 data.
         */
        int rowSize = getAccountsTable1().getRows().size();
        int colSize = getAccountsTable1().getColumnHeaders().size();

        String otherChequing = "", otherSavings = "", otherCredits = "", otherLoans = "";
        if (rowSize > 1) {
            for (int i = 2; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    String cellValue = getAccountsTable1().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 1:
                                otherChequing = otherChequing + cellValue + "";
                                break;
                            case 3:
                                otherSavings = otherSavings + cellValue + "";
                                break;
                            case 5:
                                otherCredits = otherCredits + cellValue + "";
                                break;
                            case 7:
                                otherLoans = otherLoans + cellValue + "";
                                break;
                        }
                    }

                    /*try {
                        otherChequing = otherChequing.substring(0, otherChequing.length());
                    } catch (Exception e) {

                        try {
                            otherSavings = otherSavings.substring(0, otherSavings.length());
                        } catch (Exception f) {
                        }
                        try {
                            otherCredits = otherCredits.substring(0, otherCredits.length());
                        } catch (Exception g) {
                        }
                        try {
                            otherLoans = otherLoans.substring(0, otherLoans.length());
                        } catch (Exception h) {
                        }

                        break;

                    }*/
                }
            }

            businessInquiryPrinterValuesWithTable.put("otherChequing1", otherChequing);
            Log.debug("Other Chequing: " + otherChequing);
            businessInquiryPrinterValuesWithTable.put("otherSavings1", otherSavings);
            Log.debug("Other Savings: " + otherSavings);
            businessInquiryPrinterValuesWithTable.put("otherCredits1", otherCredits);
            Log.debug("Other Credits: " + otherCredits);
            businessInquiryPrinterValuesWithTable.put("otherLoans1", otherLoans);
            Log.debug("Other Loans: " + otherLoans);


        }


        return businessInquiryPrinterValuesWithTable;

    }

    public HashMap<String, String> getBusinessInquiryValuesBusinessPrimaryHistory() throws GeneralLeanFtException {
        HashMap<String, String> businessInquiryValuesBusinessPrimaryHistory = new HashMap<>();

        businessInquiryValuesBusinessPrimaryHistory.put("pageName1", "businessInquiryValuesBusinessPrimaryHistory");

        /**
         * Iterates through the getAccountsTableBusinessPrimaryHistory data.
         */

        int rowSize = 3; //Row set is set to 3, as validation of history is too long. Only validating column headers.
        int colSize = getAccountsTableBusinessPrimaryHistory().getColumnHeaders().size();

        String dateIssue = " ", timeFromAcct = " ", transactionToAcct = " ", amountBranchTransit = " ", authorizedByErrorCode = " ";

        if (rowSize > 0) {
            for (int i = 0; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    String cellValue = getAccountsTableBusinessPrimaryHistory().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                dateIssue = dateIssue + cellValue + " ";
                                break;
                            case 1:
                                timeFromAcct = timeFromAcct + cellValue + " ";
                                break;
                            case 2:
                                transactionToAcct = transactionToAcct + cellValue + " ";
                                break;
                            case 3:
                                amountBranchTransit = amountBranchTransit + cellValue + " ";
                                break;
                            case 6:
                                authorizedByErrorCode = authorizedByErrorCode + cellValue + " ";
                                break;

                        }
                    }
                }
            }

            businessInquiryValuesBusinessPrimaryHistory.put("dateIssue1", dateIssue);
            Log.debug("Date Issue : " + dateIssue);
            businessInquiryValuesBusinessPrimaryHistory.put("timeFromAcct1", timeFromAcct);
            Log.debug("Time From Account: " + timeFromAcct);
            businessInquiryValuesBusinessPrimaryHistory.put("transactionToAcct1", transactionToAcct);
            Log.debug("Transaction To Acct: " + transactionToAcct);
            businessInquiryValuesBusinessPrimaryHistory.put("amountBranchTransit1", amountBranchTransit);
            Log.debug("Amount Branch Transit: " + amountBranchTransit);
            businessInquiryValuesBusinessPrimaryHistory.put("authorizedByErrorCode1", authorizedByErrorCode);
            Log.debug("Authorized By Error Code : " + authorizedByErrorCode);


        }

        return businessInquiryValuesBusinessPrimaryHistory;

    }

    public HashMap<String, String> getBusinessInquiryPrinterValuesAllAccounts() throws GeneralLeanFtException {
        HashMap<String, String> businessInquiryPrinterValuesAllAccounts = new HashMap<>();

        businessInquiryPrinterValuesAllAccounts.put("pageName1", "businessInquiryAllAccounts");

        businessInquiryPrinterValuesAllAccounts.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());

        businessInquiryPrinterValuesAllAccounts.put("primaryChequing1", getPrimaryChequingEditField().getValue().trim());
        Log.debug("Primary Chequing: " + getPrimaryChequingEditField().getValue().trim());

        businessInquiryPrinterValuesAllAccounts.put("atmAccess1", getAtmAccessEditField().getValue().trim());
        Log.debug("Atm Access: " + getAtmAccessEditField().getValue().trim());

        businessInquiryPrinterValuesAllAccounts.put("primarySavings1", getPrimarySavingsEditField().getValue().trim());
        Log.debug("Primary Savings: " + getPrimarySavingsEditField().getValue().trim());

        businessInquiryPrinterValuesAllAccounts.put("savingAtmAccess1", getSavingAtmAccessEditField().getValue().trim());
        Log.debug("Savings Atm Access: " + getSavingAtmAccessEditField().getValue().trim());

        businessInquiryPrinterValuesAllAccounts.put("creditCard1", getCreditCardEditField().getValue().trim());
        Log.debug("Credit Card: " + getCreditCardEditField().getValue().trim());

        businessInquiryPrinterValuesAllAccounts.put("creditCardAtmAccess1", getCreditCardAtmAccessEditField().getValue().trim());
        Log.debug("Credit Card Atm Access: " + getSavingAtmAccessEditField().getValue().trim());

        businessInquiryPrinterValuesAllAccounts.put("rcl1", getRclEditField().getValue().trim());
        Log.debug("RCL: " + getRclEditField().getValue().trim());

        businessInquiryPrinterValuesAllAccounts.put("rclAtmAccess1", getRclAtmAccessEditField().getValue().trim());
        Log.debug("RCL Atm Access: " + getRclAtmAccessEditField().getValue().trim());

        businessInquiryPrinterValuesAllAccounts.put("atm1", getAtmEditField().getValue().trim());
        Log.debug("ATM: " + getAtmEditField().getValue().trim());

        businessInquiryPrinterValuesAllAccounts.put("pin1", getPinEditField().getValue().trim());
        Log.debug("PIN: " + getPinEditField().getValue().trim());

        businessInquiryPrinterValuesAllAccounts.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important: " + getImportantEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTableAllAccounts1 data.
         */
        int rowSize = getAccountsTableAllAccounts().getRows().size();
        int colSize = getAccountsTableAllAccounts().getColumnHeaders().size();

        String otherChequing = "", shortNumberAtmAccessChequing = "", otherSavings = "", shortNumberAtmAccessSavings = "", otherCredits = "", shortNumberAtmAccessOtherCredits = "",
                otherLoans = "", shortNumberAtmAccessOtherLoans = "";

        if (rowSize > 1) {
            for (int i = 2; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    String cellValue = getAccountsTableAllAccounts().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                otherChequing = otherChequing + cellValue + " ";
                                break;
                            case 1:
                                shortNumberAtmAccessChequing = shortNumberAtmAccessChequing + cellValue + " ";
                                break;
                            case 2:
                                otherSavings = otherSavings + cellValue + " ";
                            case 3:
                                shortNumberAtmAccessSavings = shortNumberAtmAccessSavings + cellValue + " ";
                                break;
                            case 4:
                                otherCredits = otherCredits + cellValue + " ";
                                break;
                            case 5:
                                shortNumberAtmAccessOtherCredits = shortNumberAtmAccessOtherCredits + cellValue + " ";
                                break;
                            case 7:
                                otherLoans = otherLoans + cellValue + " ";
                                break;
                            case 8:
                                shortNumberAtmAccessOtherLoans = shortNumberAtmAccessOtherLoans + cellValue + " ";
                                break;
                        }
                    }
                }
            }

            businessInquiryPrinterValuesAllAccounts.put("otherChequing1", otherChequing);
            Log.debug("Other Chequing: " + otherChequing);
            businessInquiryPrinterValuesAllAccounts.put("shortNumberAtmAccessChequing1", shortNumberAtmAccessChequing);
            Log.debug("Short Number ATM Access Chequing: " + shortNumberAtmAccessChequing);
            businessInquiryPrinterValuesAllAccounts.put("otherSavings1", otherSavings);
            Log.debug("Other Savings: " + otherSavings);
            businessInquiryPrinterValuesAllAccounts.put("shortNumberAtmAccessSavings1", shortNumberAtmAccessSavings);
            Log.debug("Short Number ATM Access Savings: " + shortNumberAtmAccessSavings);
            businessInquiryPrinterValuesAllAccounts.put("otherCredits1", otherCredits);
            Log.debug("Other Credits: " + otherCredits);
            businessInquiryPrinterValuesAllAccounts.put("shortNumberAtmAccessOtherCredits1", shortNumberAtmAccessOtherCredits);
            Log.debug("Short Number ATM Access Other Credits: " + shortNumberAtmAccessOtherCredits);
            businessInquiryPrinterValuesAllAccounts.put("otherLoans1", otherLoans);
            Log.debug("Other Loans: " + otherLoans);
            businessInquiryPrinterValuesAllAccounts.put("shortNumberAtmAccessOtherLoans1", shortNumberAtmAccessOtherLoans);
            Log.debug("Short Number ATM Access Other Loans: " + shortNumberAtmAccessOtherLoans);


        }


        return businessInquiryPrinterValuesAllAccounts;

    }

    public HashMap<String, String> getBusinessPrimaryDailyTotalsInquiry() throws GeneralLeanFtException {
        HashMap<String, String> businessPrimaryDailyTotalsInquiry = new HashMap<>();

        businessPrimaryDailyTotalsInquiry.put("pageName1", "businessPrimaryDailyTotalsInquiry");

        businessPrimaryDailyTotalsInquiry.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        businessPrimaryDailyTotalsInquiry.put("cardNumber1", getCardNumberEditField().getValue().trim());
        Log.debug("Card Number: " + getCardNumberEditField().getValue().trim());

        businessPrimaryDailyTotalsInquiry.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits Entitlement: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        businessPrimaryDailyTotalsInquiry.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important: " + getImportantEditField().getValue().trim());

        businessPrimaryDailyTotalsInquiry.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTableBusinessPrimaryDailyTotalsInquiry() data.
         */
        int rowSize = getAccountsTableBusinessPrimaryDailyTotalsInquiry().getRows().size();
        int colSize = getAccountsTableBusinessPrimaryDailyTotalsInquiry().getRows().get(2).getCells().size();


        String  deposits = "", creditCard = "", withdrawal = "", thirdPartyDebit = "", branchWithdrawal = "", totalWithdrawal = "";

        if (rowSize > 1) {
            for (int i = 2; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    String cellValue = getAccountsTableBusinessPrimaryDailyTotalsInquiry().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                deposits = deposits+ cellValue + " ";
                                break;
                            case 1:
                                creditCard = creditCard + cellValue + " ";
                                break;
                            case 2:
                                withdrawal = withdrawal + cellValue + " ";
                                break;
                            case 3:
                                thirdPartyDebit = thirdPartyDebit + cellValue + " ";
                                break;
                            case 4:
                                branchWithdrawal = branchWithdrawal + cellValue + " ";
                                break;
                            case 5:
                                totalWithdrawal = totalWithdrawal + cellValue + " ";
                                break;
                        }
                    }
                }
            }

            businessPrimaryDailyTotalsInquiry.put("deposits1", deposits);
            Log.debug("Deposits: " + deposits);
            businessPrimaryDailyTotalsInquiry.put("creditCard1", creditCard);
            Log.debug("Credit Card: " + creditCard);
            businessPrimaryDailyTotalsInquiry.put("withdrawal1", withdrawal);
            Log.debug("Withdrawal: " + withdrawal);
            businessPrimaryDailyTotalsInquiry.put("thirdPartyDebit1", thirdPartyDebit);
            Log.debug("Third Party Debit: " + thirdPartyDebit);
            businessPrimaryDailyTotalsInquiry.put("branchWithdrawal1", branchWithdrawal);
            Log.debug("Branch Withdrawal: " + branchWithdrawal);
            businessPrimaryDailyTotalsInquiry.put("totalWithdrawal1", totalWithdrawal);
            Log.debug("Total Withdrawal: " + totalWithdrawal);

        }

        return businessPrimaryDailyTotalsInquiry;

    }

    public HashMap<String, String> getBusinessPrimaryPointOfSale() throws GeneralLeanFtException {
        HashMap<String, String> businessPrimaryPointOfSale = new HashMap<>();

        businessPrimaryPointOfSale.put("pageName1", "businessPrimaryPointOfSale");

        businessPrimaryPointOfSale.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        businessPrimaryPointOfSale.put("cardNumber1", getCardNumberEditField().getValue().trim());
        Log.debug("Card Number: " + getCardNumberEditField().getValue().trim());

        businessPrimaryPointOfSale.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits Entitlement: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        businessPrimaryPointOfSale.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());

        businessPrimaryPointOfSale.put("cardStatus1",  getCardStatusEditField().getValue().trim());
        Log.debug("Card Status: " +  getCardStatusEditField().getValue().trim());

        businessPrimaryPointOfSale.put("date1", getDateEditField().getValue().trim());
        Log.debug("Date: " + getDateEditField().getValue().trim());

        businessPrimaryPointOfSale.put("issueStatus1", getIssueStatusEditField().getValue().trim());
        Log.debug("Issue Status: " + getIssueStatusEditField().getValue().trim());

        businessPrimaryPointOfSale.put("clientStatus1", getClientStatusEditField().getValue().trim());
        Log.debug("Client Status: " + getClientStatusEditField().getValue().trim());

        businessPrimaryPointOfSale.put("pinDateEntered1", getPinDateEnteredEditField().getValue().trim());
        Log.debug("Date Pin Entered: " + getPinDateEnteredEditField().getValue().trim());

        businessPrimaryPointOfSale.put("atTransit1", getAtTransitEditField().getValue().trim());
        Log.debug("At Transit: " + getAtTransitEditField().getValue().trim());

        businessPrimaryPointOfSale.put("pointOfSaleStatus1", getPointofSaleStatusEditField().getValue().trim());
        Log.debug("Point of Sale Status: " + getPointofSaleStatusEditField().getValue().trim());

        businessPrimaryPointOfSale.put("dateLastUsed1", getDateLastUsedEditField().getValue().trim());
        Log.debug("Date Last Used: " + getDateLastUsedEditField().getValue().trim());

        businessPrimaryPointOfSale.put("primaryChequing1", getPrimaryChequingEditField().getValue().trim());
        Log.debug("Primary Chequing: " + getPrimaryChequingEditField().getValue().trim());

        businessPrimaryPointOfSale.put("primarySavings1", getPrimarySavingsEditField().getValue().trim());
        Log.debug("Primary Savings: " + getPrimarySavingsEditField().getValue().trim());

        businessPrimaryPointOfSale.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important: " + getImportantEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTableBusinessPrimaryPointOfSale() data.
         */
        int rowSize = getAccountsTableBusinessPrimaryPointOfSale().getRows().size();
        int colSize = getAccountsTableBusinessPrimaryPointOfSale().getColumnHeaders().size();


        String  purchase = "", refund = "", online = "", backup = "";
        if (rowSize > 1) {
            for (int i = 2; i < rowSize; i++) {
                for (int j = 0; j <= colSize; j++) {
                    String cellValue = getAccountsTableBusinessPrimaryPointOfSale().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                purchase = purchase + cellValue + " ";
                                break;
                            case 1:
                                refund = refund + cellValue + " ";
                                break;
                            case 2:
                                online = online + cellValue + " ";
                                break;
                            case 3:
                                backup = backup + cellValue + " ";
                                break;
                        }
                    }
                }
            }

            businessPrimaryPointOfSale.put("purchase1", purchase);
            Log.debug("Purchase: " + purchase);
            businessPrimaryPointOfSale.put("refund1", refund);
            Log.debug("Refund: " + refund);
            businessPrimaryPointOfSale.put("online1", online);
            Log.debug("Online: " + online);
            businessPrimaryPointOfSale.put("backup1", backup);
            Log.debug("Backup: " + backup);

        }

        return  businessPrimaryPointOfSale;

    }

    public HashMap<String, String> getBusinessPrimaryAccessLimits() throws GeneralLeanFtException {
        HashMap<String, String> businessPrimaryAccessLimits = new HashMap<>();

        businessPrimaryAccessLimits.put("pageName1", "businessPrimaryAccessLimits");

        businessPrimaryAccessLimits.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        businessPrimaryAccessLimits.put("cardNumber1", getCardNumberEditField().getValue().trim());
        Log.debug("Card Number: " + getCardNumberEditField().getValue().trim());

        businessPrimaryAccessLimits.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits Entitlement: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        businessPrimaryAccessLimits.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());

        businessPrimaryAccessLimits.put("releaseAmountCurrent1", getReleaseAmountEditField().getValue().trim());
        Log.debug("Release Amount Current: " + getReleaseAmountEditField().getValue().trim());

        businessPrimaryAccessLimits.put("releaseAmountMaximum1", getReleaseAmountMaximumtEditField().getValue().trim());
        Log.debug("Release Amount Maximum: " + getReleaseAmountMaximumtEditField().getValue().trim());

        businessPrimaryAccessLimits.put("numberTemporaryIncreaseThisYear1", getNumberTemporaryIncreaseThisYearEditField().getValue().trim());
        Log.debug("Number Temporary Increase This Year: " + getNumberTemporaryIncreaseThisYearEditField().getValue().trim());

        businessPrimaryAccessLimits.put("temporaryIncreaseExpiresOn1", getTemporaryIncreaseExpiresOnEditField().getValue().trim());
        Log.debug("Temporary Increase Expires On: " + getTemporaryIncreaseExpiresOnEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTableAccessLimits() data.
         */
        int rowSize = getAccountsTableAccessLimits().getRows().size();
        int colSize = getAccountsTableAccessLimits().getColumnHeaders().size();

        String transactionType = "", current = "", maximum = "", overrride = "", offline = "";

        if (rowSize > 1) {
            for (int i = 1; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    String cellValue = getAccountsTableAccessLimits().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                transactionType = transactionType + cellValue + " ";
                                break;
                            case 1:
                                current = current + cellValue + " ";
                                break;
                            case 2:
                                maximum = maximum + cellValue + " ";
                                break;
                            case 3:
                                overrride = overrride + cellValue + " ";
                                break;
                            case 4:
                                offline = offline + cellValue + " ";
                                break;
                        }
                    }
                }
            }

            businessPrimaryAccessLimits.put("transactionType1", transactionType);
            Log.debug("Transaction Type: " + transactionType);
            businessPrimaryAccessLimits.put("current1", current);
            Log.debug("Current: " + current);
            businessPrimaryAccessLimits.put("maximum1", maximum);
            Log.debug("Maximum: " + maximum);
            businessPrimaryAccessLimits.put("override1", overrride);
            Log.debug("Override: " + overrride);
            businessPrimaryAccessLimits.put("offline1", offline);
            Log.debug("Offline: " + offline);

        }


        return businessPrimaryAccessLimits;

    }

    public HashMap<String, String> getBusinessPrimaryCardProfile() throws GeneralLeanFtException {
        HashMap<String, String> businessPrimaryCardProfile = new HashMap<>();

        businessPrimaryCardProfile.put("pageName1", "businessPrimaryCardProfile");

        businessPrimaryCardProfile.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        businessPrimaryCardProfile.put("cardNumber1", getCardNumberEditField().getValue().trim());
        Log.debug("Card Number: " + getCardNumberEditField().getValue().trim());

        businessPrimaryCardProfile.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits Entitlement: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTablePrimaryBusinessCardDetails data.
         */
        int rowSize = getAccountsTablePrimaryBusinessCardDetails().getRows().size();
        int colSize = getAccountsTablePrimaryBusinessCardDetails().getColumnHeaders().size();

        String cardType = "", contactlessCardStatus = " ";

        if (rowSize > 1) {
            for (int i = 2; i < rowSize; i++) {
                for (int j = 0; j <= colSize; j++) {
                    String cellValue = getAccountsTablePrimaryBusinessCardDetails().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                cardType = cardType + cellValue + " ";
                                break;
                            case 1:
                                contactlessCardStatus = contactlessCardStatus + cellValue + " ";
                                break;

                        }
                    }
                }
            }

            businessPrimaryCardProfile.put("cardType1", cardType);
            Log.debug("Card Type: " + cardType);
            businessPrimaryCardProfile.put("contactlessCardStatus1", contactlessCardStatus);
            Log.debug("Contactless Card Status: " + contactlessCardStatus);


        }

        /**
         * Iterates through the getAccountsTablePrimaryBusinessCardContactlessLimits data.
         */

        String  merchantCLL = " ";

        int rowSize1 = getAccountsTablePrimaryBusinessCardContactlessLimits().getRows().size();
        int columnSize1 = getAccountsTablePrimaryBusinessCardContactlessLimits().getRows().get(1).getCells().size();

        if (rowSize > 1) {
            for (int i = 2; i < rowSize1; i++) {
                for (int j = 0; j < columnSize1; j++) {
                    String cellValue = getAccountsTablePrimaryBusinessCardContactlessLimits().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                merchantCLL = merchantCLL + cellValue + " ";
                                break;

                        }
                    }
                }
            }

            businessPrimaryCardProfile.put("merchant1", merchantCLL);
            Log.debug("Merchant: " + merchantCLL);



        }

        businessPrimaryCardProfile.put("clssOtherCurrentLimit1", getClssOtherCurrentLimitEditField().getValue().trim());
        Log.debug("Other Current Limit: " + getClssOtherCurrentLimitEditField().getValue().trim());
        businessPrimaryCardProfile.put("clssGasCurrentLimit1", getClssGasCurrentLimitEditField().getValue().trim());
        Log.debug("Gas Current Limit: " + getClssGasCurrentLimitEditField().getValue().trim());
        businessPrimaryCardProfile.put("clssGroceryCurrentLimit1", getClssGroceryCurrentLimitEditField().getValue().trim());
        Log.debug("Grocery Current Limit: " + getClssGroceryCurrentLimitEditField().getValue().trim());
        businessPrimaryCardProfile.put("clssMaxOtherLimit1", getClssMaxOtherLimitEditField().getValue().trim());
        Log.debug("Other Maximum Limit: " + getClssMaxOtherLimitEditField().getValue().trim());
        businessPrimaryCardProfile.put("clssMaxGasLimit1", getClssMaxGasLimitEditField().getValue().trim());
        Log.debug("Gas Maximum Limit: " + getClssMaxGasLimitEditField().getValue().trim());
        businessPrimaryCardProfile.put("clssMaxGrocercyLimit1", getClssMaxGrocercyLimitEditField().getValue().trim());
        Log.debug("Grocery Maximum Limit: " + getClssMaxGrocercyLimitEditField().getValue().trim());

        return businessPrimaryCardProfile;

    }

    public HashMap<String, String> getBusinessPrimaryABCCList() throws GeneralLeanFtException {
        HashMap<String, String> businessPrimaryABCCList = new HashMap<>();

        businessPrimaryABCCList.put("pageName1", "businessPrimaryABCCList");

        businessPrimaryABCCList.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        businessPrimaryABCCList.put("issueNumber1", getIssueNumberEditField().getValue().trim());
        Log.debug("Issue Number: " + getIssueNumberEditField().getValue().trim());

        businessPrimaryABCCList.put("cardHolderId1", getCardHolderIdEditField().getValue().trim());
        Log.debug("Card Holder Id: " + getCardHolderIdEditField().getValue().trim());

        businessPrimaryABCCList.put("cardStatus1", getCardStatusEditField().getValue().trim());
        Log.debug("Card Status: " + getCardStatusEditField().getValue().trim());

        businessPrimaryABCCList.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits Entitlement: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        businessPrimaryABCCList.put("accountPackageEntitlement1", getAccountPackageEntitlementEditField().getValue().trim());
        Log.debug("Account Package Entitlement: " + getAccountPackageEntitlementEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTableBusinessPrimaryABCCList data.
         */
        int rowSize = getAccountsTableBusinessPrimaryABCCList().getRows().size();
        int colSize = getAccountsTableBusinessPrimaryABCCList().getRows().get(1).getCells().size();

        String select = "", abccId = "", cardHolderSFRNumber = "";

        if (rowSize > 1) {
            for (int i = 2; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    String cellValue = getAccountsTableBusinessPrimaryABCCList().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                select = select + cellValue + " ";
                                break;
                            case 1:
                                abccId = abccId + cellValue + " ";
                                break;
                            case 2:
                                cardHolderSFRNumber = cardHolderSFRNumber + cellValue + " ";
                                break;
                        }
                    }
                }
            }

            businessPrimaryABCCList.put("select1", select);
            Log.debug("Select: " + select);
            businessPrimaryABCCList.put("abccId1", abccId);
            Log.debug("ABCC Id: " + abccId);
            businessPrimaryABCCList.put("cardHolderSFRNumber1", cardHolderSFRNumber);
            Log.debug("Card Holder SRF Number: " + cardHolderSFRNumber);

        }


        return businessPrimaryABCCList;

    }

    public HashMap<String, String> getBusinessPrimaryAgentCard() throws GeneralLeanFtException {
        HashMap<String, String> businessPrimaryAgentCard = new HashMap<>();

        businessPrimaryAgentCard.put("pageName1", "businessPrimaryAgentCard");

        businessPrimaryAgentCard.put("cardHolderId1", getCardHolderIdEditField().getValue().trim());
        Log.debug("Card Holder Id: " + getCardHolderIdEditField().getValue().trim());

        businessPrimaryAgentCard.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits Entitlement: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTablePrimaryBusinessAgentCard() data.
         */
        int rowSize = getAccountsTablePrimaryBusinessAgentCard().getRows().size();
        int colSize = getAccountsTablePrimaryBusinessAgentCard().getRows().get(1).getCells().size();

        String agentId = " ", cardStatus = " ", issueNumber = " ", lastIssueUsed = " ";

        if (rowSize > 0) {
            for (int i = 2; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    String cellValue = getAccountsTablePrimaryBusinessAgentCard().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                agentId = agentId + cellValue + " ";
                                break;
                            case 1:
                                cardStatus = cardStatus + cellValue + " ";
                                break;
                            case 2:
                                issueNumber = issueNumber + cellValue + " ";
                                break;
                            case 3:
                                lastIssueUsed = lastIssueUsed + cellValue + " ";
                                break;

                        }
                    }
                }
            }

            businessPrimaryAgentCard.put("agentId1", agentId);
            Log.debug("Agent Id: " + agentId);
            businessPrimaryAgentCard.put("cardStatus1", cardStatus);
            Log.debug("Card Status: " + cardStatus);
            businessPrimaryAgentCard.put("issueNumber1", issueNumber);
            Log.debug("Issue Number: " + issueNumber);
            businessPrimaryAgentCard.put("lastIssueUsed1", lastIssueUsed);
            Log.debug("Last Issue Used: " + lastIssueUsed);

        }

        return businessPrimaryAgentCard;

    }

    public HashMap<String, String> getBusinessMobileDebitInquiry() throws GeneralLeanFtException {
        HashMap<String, String> businessMobileDebitInquiry = new HashMap<>();

        businessMobileDebitInquiry.put("pageName1", "businessMobileDebitInquiry");

        /**
         * Iterates through the getAccountsTableMobileDebitInquiry data.
         */
        int rowSize = getAccountsTableMobileDebitInquiry().getRows().size() - 1; //This will remove the last row - important header, which is not required for validation.
        int colSize = getAccountsTableMobileDebitInquiry().getRows().get(1).getCells().size();

        String mobileDebitIssueNumber = "", mobileDebitEnabledDisabled = " ";

        if (rowSize > 1) {
            for (int i = 2; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    String cellValue = getAccountsTableMobileDebitInquiry().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                mobileDebitIssueNumber = mobileDebitIssueNumber + cellValue + " ";
                                break;
                            case 2:
                                mobileDebitEnabledDisabled = mobileDebitEnabledDisabled + cellValue + " ";
                                break;

                        }
                    }
                }
            }

            businessMobileDebitInquiry.put("mobileDebitIssueNumber1", mobileDebitIssueNumber);
            Log.debug("Mobile Debit Issue Number: " + mobileDebitIssueNumber);
            businessMobileDebitInquiry.put("mobileDebitEnabledDisabled1", mobileDebitEnabledDisabled);
            Log.debug("Mobile Debit Enabled/Disabled: " + mobileDebitEnabledDisabled);


        }

        /**
         * Iterates through the getAccountsTableMobileDebitLimits data.
         */

        String  merchantCLL = " ";

        int rowSize1 = getAccountsTableMobileDebitLimits().getRows().size();
        int columnSize1 = getAccountsTableMobileDebitLimits().getRows().get(1).getCells().size();

        if (rowSize > 1) {
            for (int i = 2; i < rowSize1; i++) {
                for (int j = 0; j < columnSize1; j++) {
                    String cellValue = getAccountsTableMobileDebitLimits().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                merchantCLL = merchantCLL + cellValue + " ";
                                break;

                        }
                    }
                }
            }

            businessMobileDebitInquiry.put("merchant1", merchantCLL);
            Log.debug("Merchant: " + merchantCLL);



        }

        businessMobileDebitInquiry.put("clssOtherCurrentLimit1", getClssOtherCurrentLimitEditField().getValue().trim());
        Log.debug("Other Current Limit: " + getClssOtherCurrentLimitEditField().getValue().trim());
        businessMobileDebitInquiry.put("clssGasCurrentLimit1", getClssGasCurrentLimitEditField().getValue().trim());
        Log.debug("Gas Current Limit: " + getClssGasCurrentLimitEditField().getValue().trim());
        businessMobileDebitInquiry.put("clssGroceryCurrentLimit1", getClssGroceryCurrentLimitEditField().getValue().trim());
        Log.debug("Grocery Current Limit: " + getClssGroceryCurrentLimitEditField().getValue().trim());
        businessMobileDebitInquiry.put("clssMaxOtherLimit1", getClssMaxOtherLimitEditField().getValue().trim());
        Log.debug("Other Maximum Limit: " + getClssMaxOtherLimitEditField().getValue().trim());
        businessMobileDebitInquiry.put("clssMaxGasLimit1", getClssMaxGasLimitEditField().getValue().trim());
        Log.debug("Gas Maximum Limit: " + getClssMaxGasLimitEditField().getValue().trim());
        businessMobileDebitInquiry.put("clssMaxGrocercyLimit1", getClssMaxGrocercyLimitEditField().getValue().trim());
        Log.debug("Grocery Maximum Limit: " + getClssMaxGrocercyLimitEditField().getValue().trim());

        return businessMobileDebitInquiry;

    }

    public HashMap<String, String> getPersonalDebitInquiryAllAccounts() throws GeneralLeanFtException {
        HashMap<String, String> personalDebitInquiryAllAccounts = new HashMap<>();

        personalDebitInquiryAllAccounts.put("pageName1", "personalDebitInquiryAllAccounts");

        personalDebitInquiryAllAccounts.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        personalDebitInquiryAllAccounts.put("cardNumber1", getCardNumberEditField().getValue().trim());
        Log.debug("Card Number: " + getCardNumberEditField().getValue().trim());

        personalDebitInquiryAllAccounts.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits Entitlement: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        personalDebitInquiryAllAccounts.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());

        personalDebitInquiryAllAccounts.put("primaryChequing1", getPrimaryChequingEditField().getValue().trim());
        Log.debug("Primary Chequing: " + getPrimaryChequingEditField().getValue().trim());

        personalDebitInquiryAllAccounts.put("atmAccess1", getAtmAccessEditField().getValue().trim());
        Log.debug("ATM Access: " + getAtmAccessEditField().getValue().trim());

        personalDebitInquiryAllAccounts.put("primarySavings1", getPrimarySavingsEditField().getValue().trim());
        Log.debug("Primary Savings: " + getPrimarySavingsEditField().getValue().trim());

        personalDebitInquiryAllAccounts.put("savingAtmAccess1", getSavingAtmAccessEditField().getValue().trim());
        Log.debug("Savings ATM Access: " + getSavingAtmAccessEditField().getValue().trim());

        personalDebitInquiryAllAccounts.put("creditCard1", getCreditCardEditField().getValue().trim());
        Log.debug("Credit Card: " + getCreditCardEditField().getValue().trim());

        personalDebitInquiryAllAccounts.put("creditCardATMAccess1", getCreditCardAtmAccessEditField().getValue().trim());
        Log.debug("Credit Card ATM Access: " + getCreditCardAtmAccessEditField().getValue().trim());

        personalDebitInquiryAllAccounts.put("rcl1", getRclEditField().getValue().trim());
        Log.debug("RCL: " + getRclEditField().getValue().trim());

        personalDebitInquiryAllAccounts.put("rclAtmAccess1", getRclAtmAccessEditField().getValue().trim());
        Log.debug("RCL ATM Access: " + getRclAtmAccessEditField().getValue().trim());

        personalDebitInquiryAllAccounts.put("atm1", getAtmEditField().getValue().trim());
        Log.debug("ATM: " + getAtmEditField().getValue().trim());

        personalDebitInquiryAllAccounts.put("pin1", getPinEditField().getValue().trim());
        Log.debug("PIN: " + getPinEditField().getValue().trim());

        personalDebitInquiryAllAccounts.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important: " + getImportantEditField().getValue().trim());

        /**
         * Iterates through the  getAccountsTableAllAccounts() data.
         */

        String otherChequing = "", shortNumberAtmAccessChequing = "", otherSavings = "", shortNumberAtmAccessSavings = "", otherCredits = "", shortNumberAtmAccessOtherCredits = "",
                otherLoans = "", shortNumberAtmAccessOtherLoans = "";

        int rowSize =  getAccountsTableAllAccounts().getRows().size();
        int colSize =  getAccountsTableAllAccounts().getRows().get(1).getCells().size();

        if(rowSize > 1){
            for(int i = 2; i < rowSize; i++){
                for(int j = 0; j < colSize; j++){
                    String cellValue = getAccountsTableAllAccounts().getRows().get(i).getCells().get(j).getText();
                    if(!cellValue.equals("")){
                        switch (j){
                            case 0:
                                otherChequing = otherChequing + cellValue + " ";
                                break;
                            case 1:
                                shortNumberAtmAccessChequing = shortNumberAtmAccessChequing + cellValue + " ";
                                break;
                            case 2:
                                otherSavings = otherSavings + cellValue + " ";
                                break;
                            case 3:
                                shortNumberAtmAccessSavings = shortNumberAtmAccessSavings + cellValue + " ";
                                break;
                            case 4:
                                otherCredits = otherCredits + cellValue + " ";
                                break;
                            case 5:
                                shortNumberAtmAccessOtherCredits = shortNumberAtmAccessOtherCredits + cellValue + " ";
                                break;
                            case 7:
                                otherLoans = otherLoans + cellValue + " ";
                                break;
                            case 8:
                                shortNumberAtmAccessOtherLoans = shortNumberAtmAccessOtherLoans + cellValue + " ";
                                break;

                        }
                    }
                }
            }

            personalDebitInquiryAllAccounts.put("otherChequing1", otherChequing);
            Log.debug("Other Chequing: " + otherChequing);
            personalDebitInquiryAllAccounts.put("shortNumberAtmAccessChequing1", shortNumberAtmAccessChequing);
            Log.debug("Short Number ATM Access Chequing: " + shortNumberAtmAccessChequing);
            personalDebitInquiryAllAccounts.put("otherSavings1", otherSavings);
            Log.debug("Other Savings: " + otherSavings);
            personalDebitInquiryAllAccounts.put("shortNumberAtmAccessSavings1", shortNumberAtmAccessSavings);
            Log.debug("Short Number ATM Access Savings: " + shortNumberAtmAccessSavings);
            personalDebitInquiryAllAccounts.put("otherCredits1", otherCredits);
            Log.debug("Other Credits: " + otherCredits);
            personalDebitInquiryAllAccounts.put("shortNumberAtmAccessOtherCredits1", shortNumberAtmAccessOtherCredits);
            Log.debug("Short Number ATM Access Other Credits: " + shortNumberAtmAccessOtherCredits);
            personalDebitInquiryAllAccounts.put("otherLoans1", otherLoans);
            Log.debug("Other Loans: " + otherLoans);
            personalDebitInquiryAllAccounts.put("shortNumberAtmAccessOtherLoans1", shortNumberAtmAccessOtherLoans);
            Log.debug("Short Number ATM Access Other Loans: " + shortNumberAtmAccessOtherLoans);

        }


        return personalDebitInquiryAllAccounts;

    }

    public HashMap<String, String> getPersonalDebitInquiryHistory() throws GeneralLeanFtException {
        HashMap<String, String> personalDebitInquiryHistory = new HashMap<>();

        personalDebitInquiryHistory.put("pageName1", "personalDebitInquiryHistory");

        personalDebitInquiryHistory.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        personalDebitInquiryHistory.put("cardNumber1", getCardNumberEditField().getValue().trim());
        Log.debug("Card Number: " + getCardNumberEditField().getValue().trim());

        personalDebitInquiryHistory.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits Entitlement: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        personalDebitInquiryHistory.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());

        personalDebitInquiryHistory.put("lastFicheDate1", getLastFicheDateEditField().getValue().trim());
        Log.debug("Last Fiche Date: " + getLastFicheDateEditField().getValue().trim());

        personalDebitInquiryHistory.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important: " + getImportantEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTableBusinessPrimaryHistory data.
         */
        int rowSize = 3; //Setting row size to 3, as history is to long to validate. Only validating column headers.
        int colSize = getAccountsTableBusinessPrimaryHistory().getColumnHeaders().size();

        String dateIssue = " ", timeFromAcct = " ", transactionToAcct = " ", walletId = " ", amountBranchTransit = " ", bankingMachineId_AuthorizationNumber = " ",
                receiptNumber_CardTermAuth = " ", authorizedByErrorCode = " ";

        if (rowSize > 0) {
            for (int i = 0; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    String cellValue = getAccountsTableBusinessPrimaryHistory().getRows().get(i).getCells().get(j).getText();
                    if (!cellValue.equals("")) {
                        switch (j) {
                            case 0:
                                dateIssue = dateIssue + cellValue + " ";
                                break;
                            case 1:
                                timeFromAcct = timeFromAcct + cellValue + " ";
                                break;
                            case 2:
                                transactionToAcct = transactionToAcct + cellValue + " ";
                                break;
                            case 3:
                                walletId = walletId + cellValue + " ";
                                break;
                            case 4:
                                amountBranchTransit = amountBranchTransit + cellValue + " ";
                                break;
                            case 5:
                                bankingMachineId_AuthorizationNumber = bankingMachineId_AuthorizationNumber + cellValue + " ";
                                break;
                            case 6:
                                receiptNumber_CardTermAuth = receiptNumber_CardTermAuth + cellValue + " ";
                                break;
                            case 7:
                                authorizedByErrorCode = authorizedByErrorCode + cellValue + " ";
                                break;

                        }
                    }
                }
            }

            personalDebitInquiryHistory.put("dateIssue1", dateIssue);
            Log.debug("Date Issue : " + dateIssue);
            personalDebitInquiryHistory.put("timeFromAcct1", timeFromAcct);
            Log.debug("Time From Account: " + timeFromAcct);
            personalDebitInquiryHistory.put("transactionToAcct1", transactionToAcct);
            Log.debug("Transaction To Acct: " + transactionToAcct);
            personalDebitInquiryHistory.put("amountBranchTransit1", amountBranchTransit);
            Log.debug("Amount Branch Transit: " + amountBranchTransit);
            personalDebitInquiryHistory.put("bankingMachineId_AuthorizationNumber1", bankingMachineId_AuthorizationNumber);
            Log.debug("Banking Machine Id Authorization Number: " + bankingMachineId_AuthorizationNumber);
            personalDebitInquiryHistory.put("receiptNumber_CardTermAuth1", receiptNumber_CardTermAuth);
            Log.debug("Receipt Number Card Term Auth: " + receiptNumber_CardTermAuth);
            personalDebitInquiryHistory.put("authorizedByErrorCode1", authorizedByErrorCode);
            Log.debug("Authorized By Error Code: " + authorizedByErrorCode);


        }

        return personalDebitInquiryHistory;

    }

    public HashMap<String, String> getPersonalDebitInquiryDeliveryMethods() throws GeneralLeanFtException{
        HashMap<String, String> personalDebitInquiryDeliveryMethod = new HashMap<>();

        personalDebitInquiryDeliveryMethod.put("pageName1", "personalDebitInquiryDeliveryMethod");

        personalDebitInquiryDeliveryMethod.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        personalDebitInquiryDeliveryMethod.put("cardNumber1", getCardNumberEditField().getValue().trim());
        Log.debug("Card Number: " + getCardNumberEditField().getValue().trim());

        personalDebitInquiryDeliveryMethod.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        personalDebitInquiryDeliveryMethod.put("atm1", getAtmEditField().getValue().trim());
        Log.debug("ATM Status: " + getAtmEditField().getValue().trim());

        personalDebitInquiryDeliveryMethod.put("atmLastDateUsed1", getAtmLastDateUsedEditField().getValue().trim());
        Log.debug("ATM Last Date Used: " + getAtmLastDateUsedEditField().getValue().trim());

        personalDebitInquiryDeliveryMethod.put("branchStatus1", getBranchStatusEditField().getValue().trim());
        Log.debug("Branch Status: " + getBranchStatusEditField().getValue().trim());

        personalDebitInquiryDeliveryMethod.put("branchStatusLastDateUsed1", getBranchStatusLastDateUsedEditField().getValue().trim());
        Log.debug("Branch Status Last Date Used: " + getBranchStatusLastDateUsedEditField().getValue().trim());

        personalDebitInquiryDeliveryMethod.put("accountUpdatedStatus1", getAccountUpdatedEditField().getValue().trim());
        Log.debug("Account Updater Status: " + getAccountUpdatedEditField().getValue().trim());

        personalDebitInquiryDeliveryMethod.put("accountUpdatedStatusLastDateUsed1", getAccountUpdateLastDateUsedEditField().getValue().trim());
        Log.debug("Account Updater Status Last Date Used: " + getAccountUpdateLastDateUsedEditField().getValue().trim());

        personalDebitInquiryDeliveryMethod.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important " + getImportantEditField().getValue().trim());

        return personalDebitInquiryDeliveryMethod;
    }

    public HashMap<String, String> getPersonalDebitInquiryCardStatus() throws GeneralLeanFtException{
        HashMap<String, String> personalDebitInquiryCardStatus = new HashMap<>();

        personalDebitInquiryCardStatus.put("pageName1", "personalDebitInquiryCardStatus");

        personalDebitInquiryCardStatus.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        personalDebitInquiryCardStatus.put("cardNumber1", getCardNumberEditField().getValue().trim());
        Log.debug("Card Number: " + getCardNumberEditField().getValue().trim());

        personalDebitInquiryCardStatus.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits Entitlement: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        personalDebitInquiryCardStatus.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());

        personalDebitInquiryCardStatus.put("cardStatus1", getCardStatusEditField().getValue().trim());
        Log.debug("Card Status: " + getCardStatusEditField().getValue().trim());

        personalDebitInquiryCardStatus.put("date1", getDateEditField().getValue().trim());
        Log.debug("Date: " + getDateEditField().getValue().trim());

        personalDebitInquiryCardStatus.put("issueStatus1", getIssueStatusEditField().getValue().trim());
        Log.debug("Issue Status: " + getIssueStatusEditField().getValue().trim());

        personalDebitInquiryCardStatus.put("clientStatus1", getClientStatusEditField().getValue().trim());
        Log.debug("Client Status: " + getClientStatusEditField().getValue().trim());

        personalDebitInquiryCardStatus.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important: " + getImportantEditField().getValue().trim());

        return personalDebitInquiryCardStatus;

    }

    public HashMap<String, String> getPersonalDebitInquiryABMAccounts() throws GeneralLeanFtException {
        HashMap<String, String> personalDebitInquiryABMAccounts = new HashMap<>();

        personalDebitInquiryABMAccounts.put("pageName1", "personalDebitInquiryABMAccounts");

        personalDebitInquiryABMAccounts.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        personalDebitInquiryABMAccounts.put("cardNumber1", getCardNumberEditField().getValue().trim());
        Log.debug("Card Number: " + getCardNumberEditField().getValue().trim());

        personalDebitInquiryABMAccounts.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits Entitlement: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        personalDebitInquiryABMAccounts.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());

        personalDebitInquiryABMAccounts.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important: " + getImportantEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTable1 data.
         */

        int rowSize = getAccountsTable1().getRows().size();
        int colSize = getAccountsTable1().getColumnHeaders().size();

        String otherChequing = " ", otherSavings = " ", otherCreditCards = " ", otherLoans = " ";

        if(rowSize > 1){
            for(int i = 1; i < rowSize; i++){
                for(int j = 0; j < colSize; j++){
                    String cellValue = getAccountsTable1().getRows().get(i).getCells().get(j).getText();
                    if(!cellValue.equals("")){
                        switch(j){
                            case 1:
                                otherChequing = otherChequing + cellValue + " ";
                                break;
                            case 3:
                                otherSavings = otherSavings + cellValue + " ";
                                break;
                            case 5:
                                otherCreditCards = otherCreditCards + cellValue + " ";
                                break;
                            case 7:
                                otherLoans = otherLoans + cellValue + " ";
                                break;
                        }
                    }
                }
            }
        }

        personalDebitInquiryABMAccounts.put("otherChequeing1", otherChequing);
        Log.debug("Other Chequing: " + otherChequing);

        personalDebitInquiryABMAccounts.put("otherSavings1", otherSavings);
        Log.debug("Other Savings: " + otherSavings);

        personalDebitInquiryABMAccounts.put("otherCreditCards1", otherCreditCards);
        Log.debug("Other Credit Cards: " + otherCreditCards);

        personalDebitInquiryABMAccounts.put("otherLoans1", otherLoans);
        Log.debug("Other Loans: " + otherLoans);

        return personalDebitInquiryABMAccounts;

    }

    public HashMap<String, String> getPersonalDebitInquiryDailyTotals() throws GeneralLeanFtException {
        HashMap<String, String> personalDebitInquiryDailyTotals = new HashMap<>();

        personalDebitInquiryDailyTotals.put("pageName1", "personalDebitInquiryDailyTotals");

        personalDebitInquiryDailyTotals.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        personalDebitInquiryDailyTotals.put("cardNumber1", getCardNumberEditField().getValue().trim());
        Log.debug("Card Number: " + getCardNumberEditField().getValue().trim());

        personalDebitInquiryDailyTotals.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronic Access Limits Entitlement " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        personalDebitInquiryDailyTotals.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());

        personalDebitInquiryDailyTotals.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important " + getImportantEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTableBusinessPrimaryDailyTotalsInquiry() data.
         */

        int rowSize = getAccountsTableBusinessPrimaryDailyTotalsInquiry().getRows().size();
        int colSize = getAccountsTableBusinessPrimaryDailyTotalsInquiry().getRows().get(0).getCells().size();

        String deposits = " ", creditCard = " ", withdrawal = " ", thirdPartyDebit = " ", branchWithdrawal = " ", totalWithdrawal = " ";

        if(rowSize > 1){
            for(int i = 3; i < rowSize; i++){
                for(int j = 0; j <= colSize; j++){
                    String cellValue = getAccountsTableBusinessPrimaryDailyTotalsInquiry().getRows().get(i).getCells().get(j).getText();
                    if(!cellValue.equals(" ")){
                        switch(j){
                            case 0:
                                deposits = deposits + cellValue + " ";
                                break;
                            case 1:
                                creditCard = creditCard + cellValue + " ";
                                break;
                            case 2:
                                withdrawal = withdrawal + cellValue + " ";
                                break;
                            case 3:
                                thirdPartyDebit = thirdPartyDebit + cellValue + " ";
                                break;
                            case 4:
                                branchWithdrawal = branchWithdrawal + cellValue + " ";
                                break;
                            case 5:
                                totalWithdrawal = totalWithdrawal + cellValue + " ";
                                break;

                        }
                    }
                }
            }
        }

        personalDebitInquiryDailyTotals.put("deposits1", deposits);
        Log.debug("Deposits: " + deposits);

        personalDebitInquiryDailyTotals.put("creditCard1", creditCard);
        Log.debug("Credit Card: " + creditCard);

        personalDebitInquiryDailyTotals.put("withdrawal1", withdrawal);
        Log.debug("Withdrawal: " + withdrawal);

        personalDebitInquiryDailyTotals.put("thirdPartyDebit1", thirdPartyDebit);
        Log.debug("Third  Party Debit: " + thirdPartyDebit);

        personalDebitInquiryDailyTotals.put("branchWithdrawal1", branchWithdrawal);
        Log.debug("Branch Withdrawal: " + branchWithdrawal);

        personalDebitInquiryDailyTotals.put("totalWithdrawal1", totalWithdrawal);
        Log.debug("Withdrawal: " + totalWithdrawal);

        return personalDebitInquiryDailyTotals;
    }

    public HashMap<String, String> getPersonalDebitInquiryPOS() throws GeneralLeanFtException {
        HashMap<String, String> personalDebitInquiryPOS = new HashMap<>();

        personalDebitInquiryPOS.put("pageName1", "personalDebitInquiryPOS");

        personalDebitInquiryPOS.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        personalDebitInquiryPOS.put("cardNumber1", getCardNumberEditField().getValue().trim());
        Log.debug("Card Number: " + getCardNumberEditField().getValue().trim());

        personalDebitInquiryPOS.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Electronics Access Limits Entitlement: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        personalDebitInquiryPOS.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());

        personalDebitInquiryPOS.put("cardStatus1", getCardStatusEditField().getValue().trim());
        Log.debug("Card Status: " + getCardStatusEditField().getValue().trim());

        personalDebitInquiryPOS.put("date1", getDateEditField().getValue().trim());
        Log.debug("Date: " + getDateEditField().getValue().trim());

        personalDebitInquiryPOS.put("issueStatus1", getIssueStatusEditField().getValue().trim());
        Log.debug("Issue Status: " + getIssueStatusEditField().getValue().trim());

        personalDebitInquiryPOS.put("clientStatus1", getClientStatusEditField().getValue().trim());
        Log.debug("Client Status: " + getClientStatusEditField().getValue().trim());

        personalDebitInquiryPOS.put("pointOfSaleStatus1", getPointofSaleStatusEditField().getValue().trim());
        Log.debug("Point of Sale Status: " + getPointofSaleStatusEditField().getValue().trim());

        personalDebitInquiryPOS.put("important1", getImportantEditField().getValue().trim());
        Log.debug("Important: " + getImportantEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTablePersonalDebitInquiryPOS() data.
         */

        int rowSize = getAccountsTableBusinessPrimaryPointOfSale().getRows().size();
        int colSize = getAccountsTableBusinessPrimaryPointOfSale().getRows().get(1).getCells().size();

        String purchase = " ", refund = " ", online = " ", backup = " ";

        if(rowSize > 1){
            for(int i = 2; i < rowSize; i++){
                for(int j = 0; j < colSize; j++){
                    String cellValue = getAccountsTableBusinessPrimaryPointOfSale().getRows().get(i).getCells().get(j).getText();
                    if(!cellValue.equals(" ")){
                        switch (j){
                            case 0:
                                purchase = purchase + cellValue + " ";
                                break;
                            case 1:
                                refund = refund + cellValue + " ";
                                break;
                            case 2:
                                online = online + cellValue + " ";
                                break;
                            case 3:
                                backup = backup + cellValue + " ";
                                break;
                        }
                    }
                }
            }
        }

        personalDebitInquiryPOS.put("purchase1", purchase);
        Log.debug("Purchase: " + purchase);

        personalDebitInquiryPOS.put("refund1", refund);
        Log.debug("Refund: " +  refund);

        personalDebitInquiryPOS.put("online1", online);
        Log.debug("Online: " + online);

        personalDebitInquiryPOS.put("backup1", backup);
        Log.debug("Backup: " + backup);

        return personalDebitInquiryPOS;

    }

    public HashMap<String, String> getPersonalDebitInquiryAccessLimits() throws GeneralLeanFtException {
        HashMap<String, String> personalDebitInquiryAccessLimits = new HashMap<>();

        personalDebitInquiryAccessLimits.put("pageName1", "personalDebitInquiryAccessLimits");

        personalDebitInquiryAccessLimits.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        personalDebitInquiryAccessLimits.put("cardNumber1", getCardNumberEditField().getValue().trim());
        Log.debug("Card Number: " + getCardNumberEditField().getValue().trim());

        personalDebitInquiryAccessLimits.put("language1", getLanguageEditField().getValue().trim());
        Log.debug("Language: " + getLanguageEditField().getValue().trim());

        personalDebitInquiryAccessLimits.put("releaseAmountCurrent1", getReleaseAmountEditField().getValue().trim());
        Log.debug("Release Amount Current: " + getReleaseAmountEditField().getValue().trim());

        personalDebitInquiryAccessLimits.put("releaseAmountMaximum1", getReleaseAmountMaximumtEditField().getValue().trim());
        Log.debug("Release Amount Maximum: " + getReleaseAmountMaximumtEditField().getValue().trim());

        personalDebitInquiryAccessLimits.put("numberTemporaryIncreaseThisYear1", getNumberTemporaryIncreaseThisYearEditField().getValue().trim());
        Log.debug("Number Temporary Increase This Year: " + getNumberTemporaryIncreaseThisYearEditField().getValue().trim());

        personalDebitInquiryAccessLimits.put("temporaryIncreaseExpiresOn1", getTemporaryIncreaseExpiresOnEditField().getValue().trim());
        Log.debug("Temporary Increase Expires On: " + getTemporaryIncreaseExpiresOnEditField().getValue().trim());


        /**
         * Iterates through the getAccountsTableAccessLimits data.
         */

        int rowSize = getAccountsTableAccessLimits().getRows().size();
        int colSize = getAccountsTableAccessLimits().getColumnHeaders().size();

        String transactionType = " ", current = " ", maximum = " ", override = " ", offline = " ";

        if(rowSize > 1){
            for(int i = 1; i < rowSize; i++){
                for(int j = 0; j < colSize; j++){
                    String cellValue = getAccountsTableAccessLimits().getRows().get(i).getCells().get(j).getText();
                    if(!cellValue.equals(" ")){
                        switch (j){
                            case 0:
                                transactionType = transactionType + cellValue + " ";
                                break;
                            case 1:
                                current = current + cellValue + " ";
                                break;
                            case 2:
                                maximum = maximum + cellValue + " ";
                                break;
                            case 3:
                                override = override + cellValue + " ";
                                break;
                            case 4:
                                offline = offline + cellValue + " ";
                                break;

                        }
                    }
                }
            }
        }

        personalDebitInquiryAccessLimits.put("transactionType1", transactionType);
        Log.debug("Transaction Type: " + transactionType);

        personalDebitInquiryAccessLimits.put("current1", current);
        Log.debug("Current: " + current);

        personalDebitInquiryAccessLimits.put("maximum1", maximum);
        Log.debug("Maximum: " + maximum);

        personalDebitInquiryAccessLimits.put("override1", override);
        Log.debug("Override: " + override);

        personalDebitInquiryAccessLimits.put("offline1", offline);
        Log.debug("Offline: " + offline);

        return personalDebitInquiryAccessLimits;
    }

    public HashMap<String, String> getPersonalDebitInquiryCardProfile() throws GeneralLeanFtException {
        HashMap<String, String> personalDebitInquiryCardProfile = new HashMap<>();

        personalDebitInquiryCardProfile.put("pageName1", "personalDebitInquiryCardProfile");

        personalDebitInquiryCardProfile.put("clientName1", getClientNameEditField().getValue().trim());
        Log.debug("Client Name: " + getClientNameEditField().getValue().trim());

        personalDebitInquiryCardProfile.put("cardNumber1", getCardNumberEditField().getValue().trim());
        Log.debug("Card Number: " + getCardNumberEditField().getValue().trim());

        personalDebitInquiryCardProfile.put("dailyAccessLimits1", getDailyAccessLimitEntitlementEditField().getValue().trim());
        Log.debug("Daily Access Limits: " + getDailyAccessLimitEntitlementEditField().getValue().trim());

        /**
         * Iterates through the getAccountsTablePrimaryBusinessCardDetails data.
         */

        int rowSize = getAccountsTablePrimaryBusinessCardDetails().getRows().size();
        int colSize = getAccountsTablePrimaryBusinessCardDetails().getColumnHeaders().size();

        String cardType = " ", contactlessCardStatus = " ";

        if(rowSize > 1){
            for(int i = 2; i < rowSize; i++){
                for(int j = 0; j <= colSize; j++) {
                    String cellValue = getAccountsTablePrimaryBusinessCardDetails().getRows().get(i).getCells().get(j).getText();
                    if(!cellValue.equals(" ")){
                        switch (j){
                            case 0:
                                cardType = cardType + cellValue + " ";
                                break;
                            case 1:
                                contactlessCardStatus = contactlessCardStatus + cellValue + " ";
                                break;
                        }
                    }
                }
            }
        }

        personalDebitInquiryCardProfile.put("cardType1", cardType);
        Log.debug("Card Type: " + cardType);

        personalDebitInquiryCardProfile.put("contactlessCardStatus1", contactlessCardStatus);
        Log.debug("Contactless Card Status: " + contactlessCardStatus);

        /**
         * Iterates through the getAccountsTablePrimaryBusinessCardContactlessLimits data.
         */

        int rowSize1 = getAccountsTablePrimaryBusinessCardContactlessLimits().getRows().size();
        int colSize1 = getAccountsTablePrimaryBusinessCardContactlessLimits().getColumnHeaders().size();

        String merchant = " ";

        if(rowSize1 > 1){
            for(int i = 2; i < rowSize1; i++){
                for(int j = 0; j <= colSize1; j++){
                    String cellValue = getAccountsTablePrimaryBusinessCardContactlessLimits().getRows().get(i).getCells().get(j).getText();
                    if(!cellValue.equals(" ")){
                        switch (j){
                            case 0:
                                merchant = merchant + cellValue + " ";
                                break;

                        }
                    }
                }
            }
        }

        personalDebitInquiryCardProfile.put("merchant1", merchant);
        Log.debug("Merchant: " + merchant);

        personalDebitInquiryCardProfile.put("clssOtherCurrentLimit1", getClssOtherCurrentLimitEditField().getValue().trim());
        Log.debug("Other Current Limit: " + getClssOtherCurrentLimitEditField().getValue().trim());

        personalDebitInquiryCardProfile.put("clssGasCurrentLimit1", getClssGasCurrentLimitEditField().getValue().trim());
        Log.debug("Gas Current Limit: " + getClssGasCurrentLimitEditField().getValue().trim());

        personalDebitInquiryCardProfile.put("clssGroceryCurrentLimit1", getClssGroceryCurrentLimitEditField().getValue().trim());
        Log.debug("Grocery Current Limit: " + getClssGroceryCurrentLimitEditField().getValue().trim());

        personalDebitInquiryCardProfile.put("clssMaxOtherLimit1", getClssMaxOtherLimitEditField().getValue().trim());
        Log.debug("Other Maximum Limit: " + getClssMaxOtherLimitEditField().getValue().trim());

        personalDebitInquiryCardProfile.put("clssMaxGasLimit1", getClssMaxGasLimitEditField().getValue().trim());
        Log.debug("Gas Maximum Limit: " + getClssMaxGasLimitEditField().getValue().trim());

        personalDebitInquiryCardProfile.put("clssMaxGrocercyLimit1", getClssMaxGrocercyLimitEditField().getValue().trim());
        Log.debug("Grocery Maximum Limit: " + getClssMaxGrocercyLimitEditField().getValue().trim());


        return personalDebitInquiryCardProfile;

    }

    //Table*******

    private Table getAccountsTable1() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Other Chequing  Other Savings.*")).build());
    }

    private Table getAccountsTableAllAccounts() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Chequing Savings Credit Cards.*")).build());
    }

    private Table getAccountsTableBusinessPrimaryHistory() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Date Time.*")).build());

    }

    private Table getAccountsTableBusinessPrimaryDailyTotalsInquiry() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*ATM Totals.*")).build());

    }

    private Table getAccountsTableBusinessPrimaryPointOfSale() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Total POS.*")).build());

    }

    private Table getAccountsTableAccessLimits() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Transaction Type Current Maximum Override Offline.*")).build());

    }

    private Table getAccountsTablePrimaryBusinessCardDetails() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Card Details.*")).build());

    }

    private Table getAccountsTablePrimaryBusinessCardContactlessLimits() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Contactless Limits.*")).build());

    }

    private Table getAccountsTableBusinessPrimaryABCCList() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Select ABCC ID Cardholder SRF Number.*")).build());

    }

    private Table getAccountsTablePrimaryBusinessAgentCard() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Agent ID Card Status Issue Number Last Issue Used.*")).build());

    }

    private Table getAccountsTableMobileDebitInquiry() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Mobile Debit Details Mobile DebitMobile.*")).build());

    }

    private Table getAccountsTableMobileDebitLimits() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Mobile Debit Limits.*")).build());

    }

    //*************

    private EditField getClientNameEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clientName").build());

    }

    private EditField getDisplayCardNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("displayCardNumber").build());
    }

    private EditField getCardNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("displayCardNumber").index(0).build());
    }

    private EditField getCardStatusEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("cardStatus").index(1).build());

    }

    private EditField getDailyAccessLimitEntitlementEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("dailyAccessLimits").build());
    }

    private EditField getAtmEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("atm").build());

    }

    private EditField getBranchStatusEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("branchStatus").build());

    }

    private EditField getAccountUpdatedEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("accountUpdated").build());

    }

    private EditField getImportantEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("important").build());

    }

    private EditField getAtmLastDateUsedEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("atmLastDateUsed").build());

    }

    private EditField getBranchStatusLastDateUsedEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("branchStatusLastDateUsed").build());

    }

    private EditField getAccountUpdateLastDateUsedEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("accountUpdateLastDateUsed").build());

    }

    private EditField getLanguageEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("language").index(0).build());

    }


    private EditField getDateEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("date").build());

    }

    private EditField getIssueStatusEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("issueStatus").build());

    }

    private EditField getIssueDateEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("issueDate").build());

    }

    private EditField getClientStatusEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clientStatus").build());

    }

    private EditField getClientDateEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clientDate").build());

    }

    private EditField getOnlinePinEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("onlinePin").build());

    }

    private EditField getOnlinePinDateEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("onlinePinDate").build());

    }

    private EditField getPinDateEnteredEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("pinDateEntered").build());

    }

    private EditField getAtTransitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("atTransit").build());

    }

    private EditField getPinEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("pin").build());

    }

    private EditField getPrimaryChequingEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("primaryChequing").build());

    }

    private EditField getPrimarySavingsEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("primarySavings").build());

    }

    private EditField getCreditCardEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("creditCard").build());

    }

    private EditField getRclEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("rcl").build());

    }

    private EditField getReleaseAmountEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("releaseAmountCurrent").build());
    }

    private EditField getReleaseAmountMaximumtEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("releaseAmountMaximum").build());
    }

    private EditField getNumberTemporaryIncreaseThisYearEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("numberTemporaryIncreaseThisYear").build());
    }

    private EditField getTemporaryIncreaseExpiresOnEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("temporaryIncreaseExpiresOn").build());
    }

    private EditField getOtherChequeingEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("otherChequing").build());

    }

    private EditField getOtherSavingsEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("otherSavings").build());

    }

    private EditField getOtherCreditsEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("otherCredits").build());

    }

    private EditField getOtherLoansEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("otherLoans").build());

    }

    private EditField getAtmAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("atmAccess").build());

    }

    private EditField getSavingAtmAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("savingAtmAccess").build());

    }

    private EditField getCreditCardAtmAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("creditCardATMAccess").build());

    }

    private EditField getRclAtmAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("rclATMAccess").build());

    }

    private EditField getPointofSaleStatusEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("pointOfSaleStatus").build());

    }

    private EditField getDateLastUsedEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("dateLastUsed").build());

    }

    private Image getRBCLogoImage() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .type(ImageType.NORMAL).tagName("IMG").alt("RBC Logo").build());
    }

    private EditField getClssOtherCurrentLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clssOtherCurrentLimit").build());

    }

    private EditField getClssGasCurrentLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clssGasCurrentLimit").build());

    }

    private EditField getClssGroceryCurrentLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clssGroceryCurrentLimit").build());

    }

    private EditField getClssMaxOtherLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clssMaxOtherLimit").build());

    }

    private EditField getClssMaxGasLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clssMaxGasLimit").build());

    }

    private EditField getClssMaxGrocercyLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clssMaxGrocercyLimit").build());

    }

    private EditField getIssueNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("issueNumber").build());
    }

    private EditField getAccountPackageEntitlementEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("accountPackageEntitlement").build());
    }

    private EditField getCardHolderIdEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("cardHolderId").build());
    }

    private EditField getLastFicheDateEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("ficheDate").build());
    }

}
