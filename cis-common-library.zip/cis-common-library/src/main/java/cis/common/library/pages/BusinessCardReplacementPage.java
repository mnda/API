package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.*;
import com.hp.lft.sdk.winforms.WindowDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.AbstractPageWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class BusinessCardReplacementPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public BusinessCardReplacementPage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }


    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing BusinessReplacementPage...");
        SyncHelperWeb.waitForElementToAppear(getDisplayCardNumberEditField());
        Log.debug("BusinessReplacementPage successfully initialized");
    }

    //    /* -- Get Objects --*/


    private Link getBusinessMenuLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").innerText("Business Menu").build());
    }

    /////////////////////////////////////////////////////
    private EditField getDisplayCardNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("displayCardNumber").build());
    }

    private EditField getCardTypeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("cardType").build());
    }

    private EditField getCardHolderIdEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .tagName("INPUT").name("cardHolderId").build());
    }

    private Image getClearButtonImage() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .alt("Clear Button").type(ImageType.LINK).tagName("IMG").build());
    }

}