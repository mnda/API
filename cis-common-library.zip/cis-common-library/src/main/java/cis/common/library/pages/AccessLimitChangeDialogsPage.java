package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.stdwin.Window;
import com.hp.lft.sdk.web.*;
import com.hp.lft.sdk.winforms.WindowDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;

/**
 * Created by angmark on 5/25/2017.
 */
public class AccessLimitChangeDialogsPage extends BasePageWeb {
    public AccessLimitChangeDialogsPage() {
        mainPage = getDialogPage();
        waitUntilVisible();
    }


    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing AccessLimitChangeDialogsPage...");
        SyncHelperWeb.waitForElementToAppear(getYesButton(mainPage));
        Log.debug("AccessLimitChangeDialogsPage successfully initialized");
    }

//
//    public static void main(String[] args) throws Exception, Throwable {
//        CoreFrameworkWeb.instantiateSDK();
//        System.setProperty("logDebug", "true");
//        // AccessLimitChangeDialogsChunk chunk = new AccessLimitChangeDialogsChunk(new AccessLimitsChangePage().getMainPage());
//        //  chunk.setTemporaryChange("yes", "test", "test", "test");
//        CoreFrameworkWeb.cleanupSDK();
//    }

    public void setTemporaryChange(String answer, String date, String print, String printSuccessfully) throws GeneralLeanFtException {
        if (answer.toLowerCase().contains("yes")) {
            CoreFrameworkWeb.click(getYesButton(mainPage));
            setExpiryDate(date);
            doPrintActions(print, printSuccessfully);
        } else {
            getNoButton(mainPage);
        }
    }


    public void setTemporaryChange(String answer, String date) throws GeneralLeanFtException {
        if (answer.toLowerCase().contains("yes")) {
            CoreFrameworkWeb.click(getYesButton(mainPage));
            setExpiryDate(date);
        } else {
            getNoButton(mainPage);
        }
    }

    public void setExpiryDate(String date) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getExpiryDateYearEditField(), date.split("/", -1)[2]);
        CoreFrameworkWeb.set(getExpiryDateMonthEditField(), date.split("/", -1)[0]);
        CoreFrameworkWeb.set(getExpiryDateDayEditField(), date.split("/", -1)[1]);
        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }

    public void doPrintActions(String print, String successfulAnswer) throws GeneralLeanFtException {
        if (print.toLowerCase().contains("yes")) {
            CoreFrameworkWeb.click(getPrintButton());
            validatePrint(successfulAnswer);
        } else {
            getStdWinDialogWindow().close();
        }
    }

    public void validatePrint(String answer) throws GeneralLeanFtException {
        if (answer.toLowerCase().contains("yes")) {
            CoreFrameworkWeb.click(getPrintSuccessfulButton());
        } else {
            CoreFrameworkWeb.click(getPrintFailButton());
        }
    }


    //** Get Objects **/

    //Print Temporary Dialog
    public Page getTemporaryDialogPage() {
        return GetObjectWeb.getDialogPageObject(new WindowDescription.Builder()
                .windowTitleRegExp(" Client Identification System").build(), new WindowDescription.Builder()
                .windowTitleRegExp(new RegExpProperty(".*Webpage Dialog.*")).build(), new PageDescription.Builder()
                .title("CIS - Client Identification System").index(0).build());
    }

    //IC - Système d'identification des clients -- Webpage Dialog


    //Expiry Date
    public EditField getExpiryDateYearEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("expiryYear").build());
    }


    public EditField getExpiryDateMonthEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("expiryMonth").build());
    }

    public EditField getExpiryDateDayEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("expiryDay").build());
    }

    //Print Dialog

    public Image getPrintButton() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .alt("Print Button").type(ImageType.LINK).tagName("IMG").build());
    }

    //Print Confirmation

    public Image getPrintSuccessfulButton() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .alt("Yes Button").type(ImageType.LINK).tagName("IMG").build());
    }

    public Image getPrintFailButton() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .alt("Yes Button").type(ImageType.LINK).tagName("IMG").build());
    }

    public Window getStdWinDialogWindow() throws GeneralLeanFtException {
        return Desktop.describe(Window.class, new WindowDescription.Builder()
                .windowTitleRegExp(" Client Identification System").build()).describe(Window.class, new WindowDescription.Builder()
                .windowTitleRegExp("CIS - Client Identification System -- Webpage Dialog").build());
    }
}
