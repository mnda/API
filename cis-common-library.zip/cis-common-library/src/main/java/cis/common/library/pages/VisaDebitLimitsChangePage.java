package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.*;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class VisaDebitLimitsChangePage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public VisaDebitLimitsChangePage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing VisaDebitLimitsChangePage...");
        SyncHelperWeb.waitForElementToAppear(getPreAuthorizedPaymentsPerTransactionEditField());
        Log.debug("VisaDebitLimitsChangePage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        CoreFrameworkWeb.cleanupSDK();
    }

    public void changeLimit(String preAuthorizedLimit, String purchaseLimit) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getPreAuthorizedPaymentsPerTransactionEditField(), preAuthorizedLimit);
        CoreFrameworkWeb.set(getPurchaseLimitEditField(), purchaseLimit);
        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }

//    public String getErrorMessage() throws GeneralLeanFtException {
//        String errMsg = "";
//        if (getErrorTable().exists()) {
//            errMsg = getErrorTable().getInnerText();
//        }
//        return errMsg;
//    }


    public String getMaxPreAuthorizedPaymentsPerTransactionValue() throws GeneralLeanFtException {
        return getMaxPreAuthorizedPaymentsPerTransactionEditField().getValue().trim();
    }

    public String getMaxPurchaseLimitValue() throws GeneralLeanFtException {
        return getMaxPurchaseLimitEditField().getValue().trim();
    }

    public String getCurrentPreAuthorizedPaymentsPerTransactionValue() throws GeneralLeanFtException {
        return getCurrentPreAuthorizedPaymentsPerTransactionEditField().getValue().trim();
    }

    public String getCurrentPurchaseLimitValue() throws GeneralLeanFtException {
        return getCurrentPurchaseLimitEditField().getValue().trim();
    }

    public void clickCancel() throws GeneralLeanFtException {
        CoreFrameworkWeb.click(getCancelButton(mainPage));
    }


    //    /* -- Get Objects --*/

    private EditField getPreAuthorizedPaymentsPerTransactionEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("preAuthorisedPayementNewLimit").build());
    }

    private EditField getPurchaseLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("purchaseNewLimit").build());
    }

    private EditField getMaxPreAuthorizedPaymentsPerTransactionEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("preAuthorisedPayementMaxLimit").build());
    }

    private EditField getMaxPurchaseLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("purchaseMaxLimit").build());
    }

    private EditField getCurrentPreAuthorizedPaymentsPerTransactionEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("preAuthorisedCurrentLimit").build());
    }

    private EditField getCurrentPurchaseLimitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("purchaseCurrentLimit").build());
    }


}
