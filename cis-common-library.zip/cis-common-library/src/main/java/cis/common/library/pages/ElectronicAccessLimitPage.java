package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.*;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class ElectronicAccessLimitPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public ElectronicAccessLimitPage() throws GeneralLeanFtException, InterruptedException {
        mainPage = getMainPage();
        waitUntilVisible();
    }


    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing ElectronicAccessLimitPage...");
        SyncHelperWeb.waitForElementToAppear(getClientNumberEditField());
        Log.debug("ElectronicAccessLimitPage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        System.setProperty("logDebug", "true");
        ElectronicAccessLimitPage page = new ElectronicAccessLimitPage();
        page.searchClientNumber("144080967", "0");
        new EntitlementPage().checkEntitlements("005");
        CoreFrameworkWeb.cleanupSDK();
    }

    public void searchClientNumber(String clientNumber, String index) throws Exception {
        CoreFrameworkWeb.set(getClientNumberEditField(), clientNumber);
        CoreFrameworkWeb.click(getDisplayButton());
        new ClientProfilePage().clickContinue();
        CoreFrameworkWeb.set(getClientListRadioGroup(), Integer.parseInt(index));
        CoreFrameworkWeb.click(getContinueButton(getMainPage()));
    }


    //    /* -- Get Objects --*/

    private Image getDisplayButton() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .alt("Display Button").type(ImageType.LINK).tagName("IMG").build());
    }

    private EditField getClientNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clientNumber").build());
    }


    private RadioGroup getClientListRadioGroup() {
        return GetObjectWeb.getRadioGroupObject(getMainPage(), new RadioGroupDescription.Builder()
                .tagName("INPUT").name("clientList").build());
    }


}
