package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.EditField;
import com.hp.lft.sdk.web.EditFieldDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class AdditionalBccAndAgentCardCancelPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public AdditionalBccAndAgentCardCancelPage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing AdditionalBCCAndAgentCardCancelPage...");
        SyncHelperWeb.waitForElementToAppear(getClientNumberEditField());
        Log.debug("AdditionalBCCAndAgentCardCancelPage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        AdditionalBccAndAgentCardCancelPage page = new AdditionalBccAndAgentCardCancelPage();
        // page.purgeCardNumber("4519031550702469", "60", "05", "1", "00001", "5260906");
        CoreFrameworkWeb.cleanupSDK();

    }

    public void searchClient(String clientNumber, String cardType, String cardHolderID) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getClientNumberEditField(), clientNumber);
        CoreFrameworkWeb.set(getCardTypeEditField(), cardType);
        CoreFrameworkWeb.set(getCardHolderIdEditField(), cardHolderID);
        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }

    //    /* -- Get Objects --*/


    private EditField getClientNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clientNumber").build());
    }


    private EditField getCardTypeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("cardType").build());
    }

    private EditField getCardHolderIdEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("cardHolderId").build());
    }

}
