package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.internal.web.WebListBox;
import com.hp.lft.sdk.java.List;
import com.hp.lft.sdk.web.*;
import com.hp.lft.sdk.winforms.WindowDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.AbstractPageWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class EntitlementAndDeliveryMethodsPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public EntitlementAndDeliveryMethodsPage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing AccountPackageEntitlementChange...");
        SyncHelperWeb.waitForElementToAppear(getMainMenuLink());
        Log.debug("AccountPackageEntitlementChange successfully initialized");
    }


    //    /* -- Get Objects --*/

    private ListBox getRecommendedEntitlementList() {
        return GetObjectWeb.getListBoxObject(mainPage, new ListBoxDescription.Builder()
                .tagName("SELECT").name("recommendedEntitlement").build());
    }

    private RadioGroup getAutomatedTellerMachineRadioGroup() {
        return GetObjectWeb.getRadioGroupObject(mainPage, new RadioGroupDescription.Builder()
                .tagName("INPUT").name("automatedTellerMachinesRadio").build());
    }

    private RadioGroup getBranchServicesRadioGroup() {
        return GetObjectWeb.getRadioGroupObject(mainPage, new RadioGroupDescription.Builder()
                .tagName("INPUT").name("branchServicesRadio").build());
    }

    private RadioGroup getAccountUpdaterRadioGroup() {
        return GetObjectWeb.getRadioGroupObject(mainPage, new RadioGroupDescription.Builder()
                .tagName("INPUT").name("accountUpdaterRadio").build());
    }

    private RadioGroup getPointOfSaleRadioGroup() {
        return GetObjectWeb.getRadioGroupObject(mainPage, new RadioGroupDescription.Builder()
                .tagName("INPUT").name("pointOfSaleRadio").build());
    }

    private Image getEndClientSessionButtonImage() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .alt("End Client Session Button").type(ImageType.LINK).tagName("IMG").build());
    }

}
