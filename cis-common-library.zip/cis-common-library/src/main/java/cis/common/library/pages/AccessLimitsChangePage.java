package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.EditField;
import com.hp.lft.sdk.web.EditFieldDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class AccessLimitsChangePage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public AccessLimitsChangePage() throws GeneralLeanFtException, InterruptedException {
        mainPage = getMainPage();
        waitUntilVisible();
    }


    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing AccessLimitsChangePage...");
        SyncHelperWeb.waitForElementToAppear(getDepositReleaseAmountEditField());
        Log.debug("AccessLimitsChangePage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        System.setProperty("logDebug", "true");
        AccessLimitsChangePage page = new AccessLimitsChangePage();
        page.changeLimitValues("test", "test2", "test3", "test4");
        CoreFrameworkWeb.cleanupSDK();
    }

    public void changeLimitValues(String depositReleaseAmount, String withdrawal, String purchase,
                                  String thirdParyPayment) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getDepositReleaseAmountEditField(), depositReleaseAmount);
        CoreFrameworkWeb.set(getWithdrawalEditField(), withdrawal);
        CoreFrameworkWeb.set(getPurchasePOSEditField(), purchase);
        CoreFrameworkWeb.set(get3PPEditField(), thirdParyPayment);
        CoreFrameworkWeb.click(getContinueButton(mainPage));
    }

    //    /* -- Get Objects --*/


    private EditField getDepositReleaseAmountEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("depositRelAmtNew").build());
    }

    private EditField getWithdrawalEditField() throws GeneralLeanFtException {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("withdrawalNew").build());
    }


    private EditField getPurchasePOSEditField() throws GeneralLeanFtException {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("purchaseNew").build());
    }

    private EditField get3PPEditField() throws GeneralLeanFtException {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("thirdPartyNew").build());
    }

//    //Table
//    private Table getErrorTable() {
//        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
//                .tagName("TABLE").name(new RegExpProperty(".*Alert.*|.*Confirmation.*")).index(1).build());
//    }


}
