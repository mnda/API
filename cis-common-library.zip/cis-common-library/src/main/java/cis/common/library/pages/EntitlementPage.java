package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.RadioGroup;
import com.hp.lft.sdk.web.RadioGroupDescription;
import com.hp.lft.sdk.web.Table;
import com.hp.lft.sdk.web.TableDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;

import java.util.List;


/**
 * Created by angmark on 5/25/2017.
 */
public class EntitlementPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public EntitlementPage() throws GeneralLeanFtException, InterruptedException {
        mainPage = getMainPage();
        waitUntilVisible();
    }


    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing EntitlementPage...");
        SyncHelperWeb.waitForElementToAppear(getSubmitButton(mainPage));
        Log.debug("EntitlementPage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        System.setProperty("logDebug", "true");
        new EntitlementPage().checkEntitlements("005");
        CoreFrameworkWeb.cleanupSDK();
    }


    public boolean checkEntitlements(String itemSearch) throws GeneralLeanFtException {
        List<String> test2 = getClientListRadioGroup().getItems();
        boolean tempexist = false;
        for (String item : test2) {
            if (item.contains(itemSearch)) {
                tempexist = true;
                Log.debug("Found entitlement " + itemSearch + " from the list of entitlements");
            }
        }
        return tempexist;
    }


    //    /* -- Get Objects --*/

    private RadioGroup getClientListRadioGroup() {
        return GetObjectWeb.getRadioGroupObject(getMainPage(), new RadioGroupDescription.Builder()
                .tagName("INPUT").name("selectEntitlement").build());
    }

    private Table getElectronicAccessTable() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").name(new RegExpProperty("Electronic Access Limits Select .*")).index(1).build());
    }


}
