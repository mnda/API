package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.EditField;
import com.hp.lft.sdk.web.EditFieldDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class ReplacementPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public ReplacementPage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }


    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing ReplacementPage...");
        SyncHelperWeb.waitForElementToAppear(getClientCentreCodeField());
        Log.debug("ReplacementPage successfully initialized");

    }

    //    /* -- Get Objects  - May 3 - form fill--*/

    private EditField getClientCentreCodeField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clientCenterCode").build());
    }

    private EditField getClientSRFNumberField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clientSRFNumber").build());
    }

}


