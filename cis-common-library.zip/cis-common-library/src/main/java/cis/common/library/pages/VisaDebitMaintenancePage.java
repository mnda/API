package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.RadioGroup;
import com.hp.lft.sdk.web.RadioGroupDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class VisaDebitMaintenancePage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public VisaDebitMaintenancePage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing VisaDebitMaintenancePage...");
        SyncHelperWeb.waitForElementToAppear(getVisaDebitFunctionsRadioGroup());
        Log.debug("VisaDebitMaintenancePage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        CoreFrameworkWeb.cleanupSDK();
    }


    public void selectVisaDebitFunction(String function) throws GeneralLeanFtException {
        switch (function.toLowerCase()) {
            case "replacement":
                CoreFrameworkWeb.set(getVisaDebitFunctionsRadioGroup(), 0);
                break;
            case "loststolenwithreplacement":
                CoreFrameworkWeb.set(getVisaDebitFunctionsRadioGroup(), 1);
                break;
            case "loststolenwithoutreplacement":
                CoreFrameworkWeb.set(getVisaDebitFunctionsRadioGroup(), 2);
                break;
            case "visadebithot":
                CoreFrameworkWeb.set(getVisaDebitFunctionsRadioGroup(), 3);
                break;
            case "normalstatus":
                CoreFrameworkWeb.set(getVisaDebitFunctionsRadioGroup(), 4);
                break;
            case "cancelvisadebit":
                CoreFrameworkWeb.set(getVisaDebitFunctionsRadioGroup(), 5);
                break;
            case "visadebitapplication":
                CoreFrameworkWeb.set(getVisaDebitFunctionsRadioGroup(), 6);
                break;
            case "visadebitlimitschange":
                CoreFrameworkWeb.set(getVisaDebitFunctionsRadioGroup(), 7);
                break;
            default:
                CoreFrameworkWeb.set(getVisaDebitFunctionsRadioGroup(), 8);
                break;
        }
        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }

    //    /* -- Get Objects --*/
    private RadioGroup getVisaDebitFunctionsRadioGroup() {
        return GetObjectWeb.getRadioGroupObject(mainPage, new RadioGroupDescription.Builder()
                .tagName("INPUT").name("selectedFunction").build());
    }


    //***** ENUMS *****//
    public enum VisaDebitFunctions {
        Replacement("Replacement"),
        LostStolenWithReplacement("LostStolenWithReplacement"),
        LostStolenWithoutReplacement("LostStolenWithoutReplacement"),
        VisaDebitHot("VisaDebitHot"),
        NormalStatus("NormalStatus"),
        CancelVisaDebit("CancelVisaDebit"),
        VisaDebitApplication("VisaDebitApplication"),
        VisaDebitLimitsChange("VisaDebitLimitsChange");

        private final String text;

        VisaDebitFunctions(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }
}
