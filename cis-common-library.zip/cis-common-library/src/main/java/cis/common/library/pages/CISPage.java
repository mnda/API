package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.*;
import com.hp.lft.sdk.winforms.Window;
import com.hp.lft.sdk.winforms.WindowDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;
import pcb.auto.pom.core.windows.GetObjectWindows;


/**
 * Created by angmark on 5/25/2017.
 */
public class CISPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */

    private boolean engLanguage = true;

    public CISPage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        try {
            while (getCancelButton(getDialogPage()).exists(1) || getCancelButton(getMainPage()).exists(1) || getCancelLink(getDialogPage()).exists(1)) {
                if (getCancelLink(getDialogPage()).exists(1)) {
                    Log.debug("Navigating back to CIS ALP Home page");
                    getCancelLink(getDialogPage()).click();
                }
                if (getCancelButton(getDialogPage()).exists(1)) {
                    Log.debug("Navigating back to CIS ALP Home page");
                    getCancelButton(getDialogPage()).click();
                }
                if (getCancelButton(getMainPage()).exists(1)) {
                    Log.debug("Navigating back to CIS ALP Home page");
                    getCancelButton(getMainPage()).click();
                }
            }
            if (getEnglishLanguageLink().exists(1) && System.getProperty("applanguage").equals("english")) {
                Log.debug("Changing language to default: English");
                getEnglishLanguageLink().click();
            }
        } catch (Exception e) {

        }
        Log.debug("Initializing CISPage...");
        SyncHelperWeb.waitForElementToAppear(getVisaDebitInquiryLink());
        Log.debug("CIS Page successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        CISPage cisPage = new CISPage();
//        alpPage.launchALP("C:\\RBFG\\ru\\ru07\\", "RUAppBar.exe left");
//        clientIdentification().click();
        cisPage.getVisaDebitInquiryLink().click();
        CoreFrameworkWeb.cleanupSDK();
    }

    public void closeDialog(String answer) {
        if (answer.toLowerCase().contains("yes")) {
            getYesButton(mainPage);
        } else {
            getNoButton(mainPage);
        }
    }

    public void changeLanguage(String language) throws GeneralLeanFtException {
        if (language.toLowerCase().contains("english")) {
            CoreFrameworkWeb.click(getEnglishLanguageLink());
        } else {
            CoreFrameworkWeb.click(getFenchLanguageLink());
            //sets global property to french from english
            System.setProperty("applanguage", "french");
        }
    }

    public void navigateUsingFastPath(String shortcut) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getFastPathEditField(), shortcut);
        CoreFrameworkWeb.click(getGoButton());
    }

    public void navigateToCISFunctions(String function) throws GeneralLeanFtException {
        switch (function.toLowerCase()) {
            case "accesslimitsmaintenance":
                CoreFrameworkWeb.click(getAccessLimitsMaintenanceLink());
                break;
            case "inquiry":
                CoreFrameworkWeb.click(getInquiryLink());
                break;
            case "visadebitmaintenance":
                CoreFrameworkWeb.click(getVisaDebitMaintenanceLink());
                break;
            case "visadebitinquiry":
                CoreFrameworkWeb.click(getVisaDebitInquiryLink());
                break;
            case "electronicaccesslimitschange":
                CoreFrameworkWeb.click(getElectronicAccessLimitsChangeLink());
                break;
            case "maintenance":
                CoreFrameworkWeb.click(getMaintenanceLink());
                break;
            case "additionalbccandagentcardcancel":
                CoreFrameworkWeb.click(getAdditionalBCCAndAgentCardCancelLink());
                break;
            case "businesscardinquiry":
                CoreFrameworkWeb.click(getBusinessCardInquiryLink());
                break;
            case "cancelcard":
                CoreFrameworkWeb.click(getCancelCardLink());
                break;
            case "contactlessmaintenance":
                CoreFrameworkWeb.click(getContactlessMaintenanceLink());
                break;
            case "mobiledebitloststolen":
                CoreFrameworkWeb.click(getMobileDebitLostStolenLink());
                break;
            case "mobiledebitinquiry":
                CoreFrameworkWeb.click(getMobileDebitInquiryLink());
                break;
            case "mobiledebitmaintenance":
                CoreFrameworkWeb.click(getMobileDebitMaintenanceLink());
                break;
            case "clientcardapplication":
                CoreFrameworkWeb.click(getClientCardApplicationLink());
                break;
            case "businessmaintenance":
                CoreFrameworkWeb.click(getBusinessMaintenanceLink());
                break;
            case "businesscontactlessmaintenance":
                CoreFrameworkWeb.click(getBusinessContactlessMaintenanceLink());
                break;
            case "accountpackageentitlementchange":
                CoreFrameworkWeb.click(getAccountPackageEntitlementChange());

        }

    }

    public void closeCISWindow() throws GeneralLeanFtException {
        if (getMainWindow().exists(5)) {
            getMainWindow().close();
        }
    }


    public String getErrorMessage() throws GeneralLeanFtException {
        String errMsg = "";
        if (this.getErrorTable().exists()) {
            errMsg = this.getErrorTable().getInnerText();
        }

        return errMsg;
    }

    //    /* -- Get Objects --*/

    private Window getMainWindow() {
        return GetObjectWindows.getPageObject(new WindowDescription.Builder()
                .objectName("CustomAppBar").windowTitleRegExp("Application Launch Pad").build());
    }

    private Link getAccessLimitsMaintenanceLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*goToAccessLimits.*")).build());
    }

    private Link getInquiryLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*goToInquiry.*")).build());
    }

    private Link getVisaDebitMaintenanceLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*goToVisaDebitMaintenance.*")).build());
    }

    private Link getVisaDebitInquiryLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*goToVisaDebitInquiry.*")).build());
    }


    private Link getFenchLanguageLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").innerText("Français").build());
    }

    private Link getEnglishLanguageLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").innerText("English").build());
    }

    private Link getElectronicAccessLimitsChangeLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").innerText("Electronic Access Limits Change ").build());
    }

    private Link getMaintenanceLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*goToMaintenance.*")).build());
    }

    private Link getAdditionalBCCAndAgentCardCancelLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*goToBusinessCancelCard.*")).build());
    }

    private Link getBusinessCardInquiryLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*goToBusinessInquiry.*")).build());
    }

    private Link getCancelCardLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*goToCancelCard.*")).build());
    }


    private Link getContactlessMaintenanceLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*goToContactlessMaintenance.*")).build());
    }

    private Link getMobileDebitLostStolenLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*goToMobileDebitLostStolen.*")).build());
    }

    private Link getMobileDebitInquiryLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*goToMobileDebitInquiry.*")).build());
    }

    private Link getMobileDebitMaintenanceLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*goToMobileDebitMaintenance.*")).build());
    }

    private Link getClientCardApplicationLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*goToClientCardApplication.*")).build());
    }

    private Link getBusinessMaintenanceLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*goToBusinessMaintenance.*")).build());
    }

    private EditField getFastPathEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .tagName("INPUT").name("fastpath").build());
    }

    public Image getGoButton() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_go.*")).type(ImageType.LINK).tagName("IMG").build());
    }

    private Link getBusinessContactlessMaintenanceLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*goToBusinessContactlessMaint.*")).build());
    }

    private Link getAccountPackageEntitlementChange() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").outerHTML(new RegExpProperty(".*Account Package Entitlement Change.*")).build());
    }

    //Table
    private Table getErrorTable() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").name(new RegExpProperty(".*Alert.*|.*Confirmation.*")).index(1).build());
    }


    //***** ENUMS *****//
    public enum CISFunctions {
        AccessLimitsMaintenance("AccessLimitsMaintenance"),
        Inquiry("Inquiry"),
        VisaDebitMaintenance("VisaDebitMaintenance"),
        VisaDebitInquiry("VisaDebitInquiry"),
        ElectronicAccessLimitsChange("ElectronicAccessLimitsChange"),
        Maintenance("Maintenance"),
        AdditionalBCCAndAgentCardCancel("AdditionalBCCAndAgentCardCancel"),
        BusinessCardInquiry("BusinessCardInquiry"),
        CancelCard("CancelCard"),
        ContactlessMaintenance("ContactlessMaintenance"),
        MobileDebitLostStolen("MobileDebitLostStolen"),
        MobileDebitInquiry("MobileDebitInquiry"),
        MobileDebitMaintenance("MobileDebitMaintenance"),
        ClientCardApplication("ClientCardApplication"),
        BusinessMaintenance("BusinessMaintenance"),
        BusinessContactlessMaintenance("BusinessContactlessMaintenance"),
        AccountPackageEntitlementChange("AccountPackageEntitlementChange");

        private final String text;

        CISFunctions(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

}
