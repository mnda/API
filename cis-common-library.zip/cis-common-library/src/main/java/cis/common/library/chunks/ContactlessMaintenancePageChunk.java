package cis.common.library.chunks;


import cis.common.library.BaseChunkWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.*;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;

import java.util.HashMap;

/**
 * Created by angmark on 5/25/2017.
 */
public class ContactlessMaintenancePageChunk extends BaseChunkWeb {
    public static Page mainPage;


    public ContactlessMaintenancePageChunk(Page parent) {
        super(parent);
        mainPage = parent;
        Log.debug("ContactlessMaintenancePageChunk successfully initialized");
    }

    public void selectClientSelection(String enableContactless, String disableContactless, String changeContactlessLimits) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getEnableContactlessCheckBox(), enableContactless);
        CoreFrameworkWeb.set(getDisableContactlessCheckBox(), disableContactless);
        if(changeContactlessLimits.equals("validate")){
            changeContactlessLimits = "true";
        }
        CoreFrameworkWeb.set(getUpdateLimitsCheckBox(), changeContactlessLimits);
        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }

    public void setContactlessLimitsChanges(String otherPersonalisedAmt, String gasPersonalisedAmt, String groceryPersonalisedAmt) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getOtherPersonalisedAmtEditField(), otherPersonalisedAmt);
        CoreFrameworkWeb.set(getGasPersonalisedAmtEditField(), gasPersonalisedAmt);
        CoreFrameworkWeb.set(getGroceryPersonalisedAmtEditField(), groceryPersonalisedAmt);
        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }


    public HashMap<String, String> getCurrentLimits() throws GeneralLeanFtException {
        HashMap contactlessLimitsSection = new HashMap<>();
        contactlessLimitsSection.put("CurrentOtherLimit1", getOtherCurrentAmtEditField().getValue().trim());
        contactlessLimitsSection.put("CurrentGasLimit1", getGasCurrentAmtEditField().getValue().trim());
        contactlessLimitsSection.put("CurrentGroceryLimit1", getGroceryCurrentAmtEditField().getValue().trim());
        return contactlessLimitsSection;
    }


    private CheckBox getEnableContactlessCheckBox() {
        return GetObjectWeb.getCheckBoxObject(mainPage, new CheckBoxDescription.Builder()
                .type("checkbox").tagName("INPUT").name("enableContactless").build());

    }

    private CheckBox getDisableContactlessCheckBox() {
        return GetObjectWeb.getCheckBoxObject(mainPage, new CheckBoxDescription.Builder()
                .type("checkbox").tagName("INPUT").name("disableContactless").build());

    }

    private CheckBox getUpdateLimitsCheckBox() {
        return GetObjectWeb.getCheckBoxObject(mainPage, new CheckBoxDescription.Builder()
                .type("checkbox").tagName("INPUT").name("updateLimits").build());

    }


    private EditField getOtherPersonalisedAmtEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("otherPersonalisedAmt").build());

    }

    private EditField getGasPersonalisedAmtEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("gasPersonalisedAmt").build());

    }

    private EditField getGroceryPersonalisedAmtEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("groceryPersonalisedAmt").build());

    }

    private EditField getOtherCurrentAmtEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("otherCurentAmt").build());

    }

    private EditField getGasCurrentAmtEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("gasCurentAmt").build());

    }

    private EditField getGroceryCurrentAmtEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("groceryCurentAmt").build());

    }

}
