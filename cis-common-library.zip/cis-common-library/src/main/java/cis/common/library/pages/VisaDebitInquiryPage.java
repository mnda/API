package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.RadioGroup;
import com.hp.lft.sdk.web.RadioGroupDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.Report;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;


/**
 * Created by angmark on 5/25/2017.
 */
public class VisaDebitInquiryPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public VisaDebitInquiryPage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing VisaDebitInquiryPage...");
        SyncHelperWeb.waitForElementToAppear(getVisaDebitInquiryFunctionsRadioGroup());
        Log.debug("VisaDebitInquiryPage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        CISPage cisPage = new CISPage();
        cisPage.navigateToCISFunctions(CISPage.CISFunctions.VisaDebitInquiry.toString());
//        VisaDebitInquiryPage visaDebitInquiryPage = new VisaDebitInquiryPage();
//        visaDebitInquiryPage.selectVisaDebitInquiryFunction("listvisadebitnumbers");
        VisaDebitInquiryDialogsPage visaDebitInquiryDialogsPage = new VisaDebitInquiryDialogsPage();
//        visaDebitInquiryDialogsPage.enterClientNumber("client","4519031444516307");
        VisaDebitPage visaDebitPage = new VisaDebitPage();

        HashMap<String, String> test = visaDebitPage.getVisaDebitNumbersTableContent();

        Collection<String> list = test.values();
        int rowCount = Integer.parseInt(test.get("rowscount"));
        String strCollection = "";
        for (int i = 1; i < rowCount; i++) {
            String curNum = test.get("visadebitnumber" + i).trim();
            //check if card number already validated
            if (!strCollection.contains(curNum)) {
                //add card to string
                strCollection = strCollection + curNum + "-";

                Log.info("Validating that " + curNum + " is not displayed more than 3 times and that no expiry date are the same");
                String currentDebit = curNum + "-" + test.get("expiry" + i).trim();
                int cardCount = Collections.frequency(list, curNum);
                if (cardCount > 2) {
                    Report.reportStatus("Validate occurrence of debit number " + curNum + " is less than or equal to 3", "<=3", String.valueOf(cardCount), false, true);
                }
                for (int x = 1; x < rowCount; x++) {
                    String loopDebit = test.get("visadebitnumber" + x).trim() + "-" + test.get("expiry" + x).trim();
                    if (i != x && currentDebit.equals(loopDebit)) {
                        Report.reportStatus("Validate that debit number" + curNum + " should not have the same expry date", currentDebit, loopDebit, false, true);
                    }
                }
            }
        }


        CoreFrameworkWeb.cleanupSDK();
    }


    public void selectVisaDebitInquiryFunction(String function) throws GeneralLeanFtException {
        switch (function.toLowerCase()) {
            case "listvisadebitnumbers":
                CoreFrameworkWeb.set(getVisaDebitInquiryFunctionsRadioGroup(), 0);
                break;
            case "visadebittransactions":
                CoreFrameworkWeb.set(getVisaDebitInquiryFunctionsRadioGroup(), 1);
                break;
            case "visadebitlimitsinquiry":
                CoreFrameworkWeb.set(getVisaDebitInquiryFunctionsRadioGroup(), 2);
                break;
        }
        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }

    //    /* -- Get Objects --*/

    private RadioGroup getVisaDebitInquiryFunctionsRadioGroup() {
        return GetObjectWeb.getRadioGroupObject(mainPage, new RadioGroupDescription.Builder()
                .tagName("INPUT").name("selectedFunction").build());
    }


    //***** ENUMS *****//
    public enum VisaDebitInquiryFunctions {
        ListVisaDebitNumbers("ListVisaDebitNumbers"),
        VisaDebitNumberTransactions("VisaDebitNumberTransactions"),
        VisaDebitLimitsInquiry("VisaDebitLimitsInquiry");

        private final String text;

        VisaDebitInquiryFunctions(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }
}
