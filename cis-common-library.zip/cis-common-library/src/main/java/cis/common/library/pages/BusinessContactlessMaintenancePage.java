package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.EditField;
import com.hp.lft.sdk.web.EditFieldDescription;
import com.hp.lft.sdk.web.WebElement;
import com.hp.lft.sdk.web.WebElementDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class BusinessContactlessMaintenancePage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public BusinessContactlessMaintenancePage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing BusinessContactlessMaintenancePage...");
        SyncHelperWeb.waitForElementToAppear(getHeaderWebElement());
        Log.debug("BusinessContactlessMaintenancePage successfully initialized");
    }


    public void searchBusinessContactlessMaintenancePage(String displayCardNumber, String cardType, String cardHolderID) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getDisplayCardNumberEditField(), displayCardNumber);
        CoreFrameworkWeb.set(getCardTypeEditField(), cardType);
        CoreFrameworkWeb.set(getCardHolderIdEditField(), cardHolderID);
        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }


    //    /* -- Get Objects --*/

    private EditField getDisplayCardNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("displayCardNumber").build());

    }

    private EditField getCardTypeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("cardType").build());

    }

    private EditField getCardHolderIdEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("cardHolderId").build());

    }

    private WebElement getHeaderWebElement() {
        return GetObjectWeb.getWebElementObject(mainPage, new WebElementDescription.Builder()
                .tagName("H1").innerText(new RegExpProperty(".*Contactless Maintenance.*|.*Maintenance de l'option sans contact.*")).build());
    }

}