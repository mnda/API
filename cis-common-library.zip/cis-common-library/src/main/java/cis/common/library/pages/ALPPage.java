package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.Button;
import com.hp.lft.sdk.web.ButtonDescription;
import com.hp.lft.sdk.web.Page;
import com.hp.lft.sdk.web.PageDescription;
import com.hp.lft.sdk.winforms.Window;
import com.hp.lft.sdk.winforms.WindowDescription;
import org.apache.commons.lang.exception.ExceptionUtils;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.AbstractPageWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;
import pcb.auto.pom.core.windows.GetObjectWindows;

import java.awt.*;
import java.io.File;


/**
 * Created by angmark on 5/25/2017.
 */
public class ALPPage extends AbstractPageWeb {
    /**
     * Constructs the page while ensuring that element is visible before proceeding
     */
    public ALPPage() {
        mainPage = getMainPage();
    }

    /**
     * Overrides waitUntilVisible method to ensure page loaded correctly
     */
    @Override
    protected void waitUntilVisible() {
        Log.debug("ALPPage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        ALPPage alpPage = new ALPPage();
        alpPage.launchALP("C:\\RBFG\\ru\\ru07\\", "RUAppBar.exe left");
//        alpPage.getClientIdentificationLink().click();
//        alpPage.getClientIdentificationLink().getDescription();
        CoreFrameworkWeb.cleanupSDK();
    }

    /**
     * Launches ALP
     *
     * @param location location of the exe file
     * @param exeName  name of the exe file
     */
    public void launchALP(String location, String exeName) {
        try {

            Desktop desktop = Desktop.getDesktop();
            boolean check = true;
            int counter = 0;
            while (check && counter < 30) {
                try {
                    desktop.open(new File(location + "\\" + exeName.replace(" left", "")));
                    String temp = mainPage.getTitle();
                    break;
                } catch (Exception e) { // or your specific exception
                    Log.debug("ALP was NOT successfully launched, trying again in 2 seconds");
                    SyncHelperWeb.explicitWait(2000);
                    check = true;
                    counter++;
                }
            }
            if (counter < 10) {
                Log.debug("ALP was successfully launched");
            } else {
                Log.fatal("ALP was not launched within 60 seconds");
            }
        } catch (Exception e) {
            Log.error(ExceptionUtils.getStackTrace(e));
        }
    }

    public void closeALPWindow() throws GeneralLeanFtException {
        if (getMainWindow().exists(5)) {
            getMainWindow().close();
        }
    }


    public void navigateToSystem(String system) throws GeneralLeanFtException, InterruptedException {
        switch (system.toLowerCase()) {
            case "cis":
                CoreFrameworkWeb.click(getClientIdentificationButton());
            default:

        }
    }


    //    /* -- Get Objects --*/

    public Page getMainPage() {
        return GetObjectWeb.getPageObject(new WindowDescription.Builder()
                .objectName("CustomAppBar").windowTitleRegExp("Application Launch Pad").build(), new PageDescription());
    }


    public Window getMainWindow() {
        return GetObjectWindows.getPageObject(new WindowDescription.Builder()
                .objectName("CustomAppBar").windowTitleRegExp("Application Launch Pad").build());
    }

    private Button getClientIdentificationButton() {
        return GetObjectWeb.getButtonObject(getMainPage(), new ButtonDescription.Builder()
                .buttonType("button").name(new RegExpProperty(".*Client Identification.*")).build());
    }

    //***** ENUMS *****//
    public enum ALPSystems {
        CIS("CIS");

        private final String text;

        ALPSystems(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }
}
