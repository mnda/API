package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.web.CoreFrameworkWeb;

/**
 * Created by angmark on 5/25/2017.
 */
public class GenericPage extends BasePageWeb {
    public GenericPage() {
        waitUntilVisible();
    }

    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        System.setProperty("logDebug", "true");
        new GenericPage().getHeaderTitle();
        CoreFrameworkWeb.cleanupSDK();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing GenericPage...");
        //SyncHelperWeb.waitForElementToAppear(getYesButton(mainPage));
        mainPage = getMainPage();
        try {
            if (!mainPage.exists(1)) {
                mainPage = getMainPage2();
            }
            if (!mainPage.exists(1)) {
                mainPage = getDialogPage();
            }
        } catch (Exception e) {
        }
        Log.debug("GenericPage successfully initialized");
    }


}
