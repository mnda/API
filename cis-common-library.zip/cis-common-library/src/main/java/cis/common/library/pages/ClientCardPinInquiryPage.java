package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.*;
import com.hp.lft.sdk.winforms.WindowDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class ClientCardPinInquiryPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public ClientCardPinInquiryPage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing ClientCardPinInquiryPage...");
        SyncHelperWeb.waitForElementToAppear(getDisplayVisaCardNumberEditField());
        Log.debug("ClientCardPinInquiryPage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        ClientCardPinInquiryPage page = new ClientCardPinInquiryPage();
//        page.searchClient("test");
        CoreFrameworkWeb.cleanupSDK();
    }

    //    /* -- Get Objects --*/

    private EditField getDisplayVisaCardNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("displayVisaCardNumber").build());
    }

    private RadioGroup getPrintIndicatorGroup() {
        return GetObjectWeb.getRadioGroupObject(mainPage, new RadioGroupDescription.Builder()
                .tagName("INPUT").name("printIndicator").build());
    }

}
