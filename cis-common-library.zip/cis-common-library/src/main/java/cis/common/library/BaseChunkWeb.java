package cis.common.library;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.*;
import com.hp.lft.sdk.winforms.WindowDescription;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.GetObjectWeb;

/**
 * Created by angmark on 6/5/2017.
 */
public abstract class BaseChunkWeb extends BasePageWeb {
    protected BaseChunkWeb(Page page) {
        SyncHelperWeb.waitForPageToAppear(page);
    }

    //Dialog Page
    public Page getDialogPage() {
        return GetObjectWeb.getDialogPageObject(new WindowDescription.Builder()
                .windowTitleRegExp(new RegExpProperty(".*Client Identification System.*")).index(0).build(), new WindowDescription.Builder()
                .windowTitleRegExp(new RegExpProperty(".*Webpage Dialog.*")).build(), new PageDescription.Builder()
                .title(new RegExpProperty(".*SIC - Système d'identification des clients.*|.*CIS - Client Identification System.*")).index(0).build());
    }

    //Re-usable Buttons
    public Image getContinueButton(Page page) {
        return GetObjectWeb.getImageObject(page, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_continue.*")).type(ImageType.LINK).tagName("IMG").build());
    }

    public Image getCancelButton(Page page) {
        return GetObjectWeb.getImageObject(page, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_cancel.*")).type(ImageType.LINK).tagName("IMG").build());
    }

    public Image getSubmitButton(Page page) {
        return GetObjectWeb.getImageObject(page, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_submit.*")).type(ImageType.LINK).tagName("IMG").build());
    }


    public Image getYesButton(Page page) {
        return GetObjectWeb.getImageObject(page, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_yes.*")).type(ImageType.LINK).tagName("IMG").build());
    }

    public Image getNoButton(Page page) {
        return GetObjectWeb.getImageObject(page, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_no.*")).type(ImageType.LINK).tagName("IMG").build());
    }

    public Image getOkButton(Page page) {
        return GetObjectWeb.getImageObject(page, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_ok.*")).type(ImageType.LINK).tagName("IMG").build());
    }

    public Image getClearButton(Page page) {
        return GetObjectWeb.getImageObject(page, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_clear.*")).type(ImageType.LINK).tagName("IMG").build());
    }

    //Table
    private Table getErrorTable(Page page) {
        return GetObjectWeb.getTableObject(page, new TableDescription.Builder()
                .tagName("TABLE").name(new RegExpProperty(".*Alert.*|.*Confirmation.*")).index(1).build());
    }

    public String getErrorMessage(Page page) throws GeneralLeanFtException {
        String errMsg = "";
        if (getErrorTable(page).exists()) {
            errMsg = getErrorTable(page).getInnerText();
        }
        return errMsg;
    }

    //Links

    public Link getPrintLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").innerText("Print").build());
    }

    public Link getHelpLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").innerText("Help").build());
    }

    public Link getExitLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").innerText("Exit").build());
    }

    public Link getMainMenuLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").innerText("Main Menu").build());
    }


    protected void waitUntilVisible() {
    }

}
