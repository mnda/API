package cis.common.library.testdata;

/**
 * Created by angmark on 5/25/2017.
 */

public enum TradingQueryValueIdentifier {
    DEAL_NUM(0),
    REF(1),
    INS_TYPE(4);


    private int rowNum;

    TradingQueryValueIdentifier(int rowNum) {
        this.rowNum = rowNum;
    }

    public int getRowNumber() {
        return rowNum;
    }
}
