package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.Keyboard;
import com.hp.lft.sdk.Keys;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.EditField;
import com.hp.lft.sdk.web.EditFieldDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class MaintenancePage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public MaintenancePage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing MaintenancePage...");
        SyncHelperWeb.waitForElementToAppear(getDisplayCardNumberEditField());
        Log.debug("MaintenancePage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        MaintenancePage page = new MaintenancePage();
        // page.purgeCardNumber("4519031550702469", "60", "05", "1", "00001", "5260906");
        Log.info(page.getMessage().trim());
        CoreFrameworkWeb.cleanupSDK();


    }

    public String getMessage() throws GeneralLeanFtException {
        return getMessageEditField().getValue();
    }

    public void searchCardNumber(String cardNumber, String transactionCode, String maintenanceCode, String accountType,
                                 String transit, String account, String accountShortNoAddDeleteAccess,
                                 String moveAccountCode, String accountShortMoveToPrimary, String primaryAccountType) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getDisplayCardNumberEditField(), cardNumber);
        Keyboard.sendString(Keys.TAB);
        CoreFrameworkWeb.set(getTransactionCodeEditField(), transactionCode);
        Keyboard.sendString(Keys.TAB);
        if (getMaintenanceCodeAccessEditField().exists(1) && getMaintenanceCodeAccessEditField().isVisible()
                && (!maintenanceCode.equals("") && !maintenanceCode.equals("NA"))) {
            CoreFrameworkWeb.set(getMaintenanceCodeAccessEditField(), maintenanceCode);
            Keyboard.sendString(Keys.TAB);
        }
        if (getMaintenanceCodeStatusEditField().exists(1) && getMaintenanceCodeStatusEditField().isVisible()
                && (!maintenanceCode.equals("") && !maintenanceCode.equals("NA"))) {
            CoreFrameworkWeb.set(getMaintenanceCodeStatusEditField(), maintenanceCode);
            Keyboard.sendString(Keys.TAB);
        }
        if (getAccountTypeEditField().exists(1) && getAccountTypeEditField().isVisible()
                && (!accountType.equals("") && !accountType.equals("NA"))) {
            CoreFrameworkWeb.set(getAccountTypeEditField(), accountType);
            Keyboard.sendString(Keys.TAB);
        }
        if (getAccountCodeAddDeleteAccessEditField().exists(1) && getAccountCodeAddDeleteAccessEditField().isVisible()
                && (!accountType.equals("") && !accountType.equals("NA"))) {
            CoreFrameworkWeb.set(getAccountCodeAddDeleteAccessEditField(), accountType);
            Keyboard.sendString(Keys.TAB);
        }
        if (getAccountShortNoAddDeleteAccessEditField().exists(1)
                && !accountShortNoAddDeleteAccess.equals("") && !accountShortNoAddDeleteAccess.equals("NA")) {
            CoreFrameworkWeb.set(getAccountShortNoAddDeleteAccessEditField(), accountShortNoAddDeleteAccess);
            Keyboard.sendString(Keys.TAB);
        }
        if (getTransitEditField().exists(1)
                && (!transit.equals("") && !transit.equals("NA"))) {
            CoreFrameworkWeb.set(getTransitEditField(), transit);
            Keyboard.sendString(Keys.TAB);
        }
        if (getAccountCodeAccessEditField().exists(1)
                && (!account.equals("") && !account.equals("NA"))) {
            CoreFrameworkWeb.set(getAccountCodeAccessEditField(), account);
        }


        if (getMoveAccountCodeEditField().exists(1)
                && (!moveAccountCode.equals("") && !moveAccountCode.equals("NA"))) {
            CoreFrameworkWeb.set(getMoveAccountCodeEditField(), moveAccountCode);
        }
        if (getAccountShortMoveToPrimaryEditField().exists(1)
                && (!accountShortMoveToPrimary.equals("") && !accountShortMoveToPrimary.equals("NA"))) {
            CoreFrameworkWeb.set(getAccountShortMoveToPrimaryEditField(), accountShortMoveToPrimary);
        }
        if (getPrimaryAccountTypeEditField().exists(1)
                && (!primaryAccountType.equals("") && !primaryAccountType.equals("NA"))) {
            CoreFrameworkWeb.set(getPrimaryAccountTypeEditField(), primaryAccountType);
        }
        CoreFrameworkWeb.click(getSubmitButton(mainPage));


    }

    public void clickOKButton() throws GeneralLeanFtException {
        if (getOkButton(getDialogPage()).exists(1)) {
            CoreFrameworkWeb.click(getOkButton(getDialogPage()));
        }
    }

    //CHeck if dialog opens up
    public void clickYesButton() throws GeneralLeanFtException {
        if (getYesButton(getDialogPage()).exists(1)) {
            CoreFrameworkWeb.click(getYesButton(getDialogPage()));
        }
    }

    //    /* -- Get Objects --*/


    private EditField getDisplayCardNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("displayCardNumber").build());
    }


    private EditField getTransactionCodeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("transactionCode").build());
    }

    private EditField getMaintenanceCodeStatusEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").
                        name(new RegExpProperty("maintenanceCodeStatus")).index(0).build());
    }

    private EditField getMaintenanceCodeAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").
                        name(new RegExpProperty("maintenanceCodeAccess")).build());
    }


    private EditField getAccountTypeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("accountType").build());
    }


    private EditField getAccountCodeAddDeleteAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("accountCodeAddDeleteAccess").build());
    }


    private EditField getAccountShortNoAddDeleteAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("accountShortNoAddDeleteAccess").build());
    }


    private EditField getTransitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("transit").build());
    }

    private EditField getAccountCodeAccessEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("account").build());
    }


    private EditField getMessageEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("message").build());
    }

    private EditField getMoveAccountCodeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("moveAccountCode").build());
    }

    private EditField getAccountShortMoveToPrimaryEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("accountShortMoveToPrimary").build());
    }

    private EditField getPrimaryAccountTypeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("primaryAccountType").build());
    }


}
