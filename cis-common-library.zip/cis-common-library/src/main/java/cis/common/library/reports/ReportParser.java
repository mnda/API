package cis.common.library.reports;

import com.auxilii.msgparser.Message;
import com.auxilii.msgparser.MsgParser;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.Report;
import pcb.auto.pom.core.web.CoreFrameworkWeb;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static pcb.auto.pom.core.helper.CoreFrameworkHelper.regexChecker;

public class ReportParser {
    private static HashMap<String, String> transactionsReport = new HashMap<String, String>();
    private static int counter = 0;
    private static String bankMachineID, cardholdernumber;

    public static void main(String[] args) throws Exception {

        CoreFrameworkWeb.instantiateSDK();
        String reportNumber, cardHolderNumber, bankingMachine, transCode, refNumber;
        MsgParser msgp = new MsgParser();

        reportNumber = "700";
        cardHolderNumber = "143244358";
        bankingMachine = "MRX0";
        Message msg = msgp.parseMsg("C:\\LeanFTTests\\CISALP\\reports\\SDSF P5MRPTS  (JOB57626).msg");
        transCode = "TSF";
        refNumber = "2993";
//        cardHolderNumber = "4519 03 14595969 88";
//        bankingMachine = "MIN0";
//        Message msg = msgp.parseMsg("C:\\LeanFTTests\\CISALP\\reports\\testreport.msg");
//        transCode = "TSF";
//        cardHolderNumber = "4519 03 57019022 33";
//        bankingMachine = "LI92";
//        Message msg = msgp.parseMsg("C:\\LeanFTTests\\CISALP\\reports\\testreport3.msg");
//        transCode = "WD";


        String body = msg.getBodyText();

        System.setProperty("logDebug", "true");
        HashMap<String, String> transactionsUI = ReportParser.getReportTransactionsOneByOne(reportNumber, cardHolderNumber,
                bankingMachine, body, transCode, refNumber);

//        Report.reportStatus("Validate transaction count from UI and Report is matching", transactionsUI.get("transactionscount"), transactionsReport.get("transactionscount"), false, false);

//        compareUIVsReport(transactionsUI, transactionsReport, reportNumber);
        CoreFrameworkWeb.cleanupSDK();
    }


    public static HashMap<String, String> getReportTransactions(String reportNumber, String cardHolderNumber,
                                                                String bankingMachine, String body, String transCode) throws Exception {
        transactionsReport = new HashMap<>();
        counter = 0;
        if (reportNumber.equals("710")) {
            cardHolderNumber = cardHolderNumber.replace("4519", "");
        }
        Log.debug("Reading report with the following search criteria, reportNumber:" + reportNumber + ", cardHolderNumber:" + cardHolderNumber
                + ", bankingMachine:" + bankingMachine + ", transCode:" + transCode);
        String[] reports = ReportParser.getReports(reportNumber, bankingMachine, cardHolderNumber, body);
        for (int i = 0; i < reports.length - 1; i++) {
            try {
                String[] arSplitTrans = reports[i].split("\\$AMOUNT", -1)[1].split("\r\n ", -1);
                switch (reportNumber) {
                    case "700":
                        String transactionCode = handleFormatting("transdesc", transCode, reportNumber);
                        getBankMachineID(reports[i]);
                        for (int x = 0; x < arSplitTrans.length; x++) {
                            if (arSplitTrans[x].trim().contains(cardHolderNumber) && arSplitTrans[x].trim().contains(transactionCode)) {
                                Log.info("Found transaction line: " + arSplitTrans[x].replace("\r\n", " "));
                                pushToHashMap(reportNumber, arSplitTrans[x], handleFormatting("transdesc", transCode, reportNumber));

                                //add condition for 3PD and 3PC assuming 3PC and 3PD follows each other in the report
                                String debitAcct = "";
                                String creditAcct = "";
                                try {
                                    if (transactionCode.contains("3PD")) {
                                        Log.info("Getting 3PC/3PD Counterpart");
                                        if (arSplitTrans[x - 1].contains(transactionsReport.get("rectnum" + String.valueOf(counter - 1))) && arSplitTrans[x - 1].trim().contains("3PC")) {
                                            Log.debug("Found transaction line: " + arSplitTrans[x].replace("\r\n", " "));
                                            creditAcct = getReportColumnValue(reportNumber, arSplitTrans[x - 1], handleFormatting("transdesc", "3PC", reportNumber), "creditacct");
                                        }
                                        if (arSplitTrans[x + 1].contains(transactionsReport.get("rectnum" + String.valueOf(counter - 1))) && arSplitTrans[x + 1].trim().contains("3PC")) {
                                            Log.debug("Found transaction line: " + arSplitTrans[x].replace("\r\n", " "));
                                            creditAcct = getReportColumnValue(reportNumber, arSplitTrans[x - 1], handleFormatting("transdesc", "3PC", reportNumber), "creditacct");
                                        }
                                        Log.debug("Updating 3PC to account from " + transactionsReport.get("creditacct" + String.valueOf(counter - 1)) + " to " + creditAcct);
                                        transactionsReport.put("creditacct" + String.valueOf(counter - 1), creditAcct);
                                    }

                                    //add condition for 3PD and 3PC
                                    if (transactionCode.contains("3PC")) {
                                        Log.info("Getting 3PC/3PD Counterpart");
                                        if (arSplitTrans[x - 1].contains(transactionsReport.get("rectnum" + String.valueOf(counter - 1))) && arSplitTrans[x - 1].trim().contains("3PD")) {
                                            Log.debug("Found transaction line: " + arSplitTrans[x].replace("\r\n", " "));
                                            debitAcct = getReportColumnValue(reportNumber, arSplitTrans[x - 1], handleFormatting("transdesc", "3PD", reportNumber), "debitacct");
                                        }
                                        if (arSplitTrans[x + 1].contains(transactionsReport.get("rectnum" + String.valueOf(counter - 1))) && arSplitTrans[x + 1].trim().contains("3PD")) {
                                            Log.debug("Found transaction line: " + arSplitTrans[x].replace("\r\n", " "));
                                            debitAcct = getReportColumnValue(reportNumber, arSplitTrans[x - 1], handleFormatting("transdesc", "3PD", reportNumber), "debitacct");
                                        }
                                        Log.debug("Updating 3PD from account from " + transactionsReport.get("debitacct" + String.valueOf(counter - 1)) + " to " + debitAcct);
                                        transactionsReport.put("debitacct" + String.valueOf(counter - 1), debitAcct);
                                    }
                                } catch (Exception e) {

                                }


                            }
                        }
                        break;
                    case "710":
                        for (int x = 0; x < arSplitTrans.length; x++) {
                            if (arSplitTrans[x].trim().contains(cardHolderNumber)) {
                                Log.info("Found transaction line: " + arSplitTrans[x].replace("\r\n", " "));
                                pushToHashMap(reportNumber, arSplitTrans[x], handleFormatting("transdesc", transCode, reportNumber));
                            }
                        }
                        break;
                }
            } catch (Exception e) {

            }
        }
        return transactionsReport;
    }

    public static HashMap<String, String> getReportTransactionsOneByOne(String reportNumber, String cardHolderNumber,
                                                                        String bankingMachine, String body, String transCode, String refNumber) throws Exception {
        transactionsReport = new HashMap<>();
        counter = 0;
        if (reportNumber.equals("710")) {
            cardHolderNumber = cardHolderNumber.replace("4519", "");
        }
        Log.debug("Reading report with the following search criteria, reportNumber:" + reportNumber + ", cardHolderNumber/SRF Number:" + cardHolderNumber
                + ", bankingMachine:" + bankingMachine + ", transCode:" + transCode);
        String[] reports = ReportParser.getReports(reportNumber, bankingMachine, cardHolderNumber, body);
        for (int i = 0; i < reports.length - 1; i++) {
            try {
                String[] arSplitTrans = reports[i].split("\\$AMOUNT", -1)[1].split("\r\n ", -1);
                switch (reportNumber) {
                    case "700":
                        String transactionCode = handleFormatting("transdesc", transCode, reportNumber);
                        getBankMachineID(reports[i]);
                        for (int x = 0; x < arSplitTrans.length; x++) {
                            if (arSplitTrans[x].trim().contains(cardHolderNumber) && arSplitTrans[x].trim().contains(transactionCode) && arSplitTrans[x].trim().contains(refNumber)) {

                                Log.info("Found transaction line: " + arSplitTrans[x].replace("\r\n", " "));
                                //handle when card holder name is "/r/n"
                                String transactionCleaned = arSplitTrans[x].replace("\r\n", " ");
                                if (transactionCleaned.contains(cardHolderNumber + " " + handleFormatting("transdesc", transCode, reportNumber))) {
                                    String[] arSplitTransactionCleaned = transactionCleaned.split(cardHolderNumber + " " + handleFormatting("transdesc", transCode, reportNumber));
                                    transactionCleaned = arSplitTransactionCleaned[0] + cardHolderNumber + "                               "
                                            + handleFormatting("transdesc", transCode, reportNumber) + arSplitTransactionCleaned[1];
                                }
                                pushToHashMap(reportNumber, transactionCleaned, handleFormatting("transdesc", transCode, reportNumber));

                                //add condition for 3PD and 3PC assuming 3PC and 3PD follows each other in the report
                                String debitAcct = "";
                                String creditAcct = "";
                                try {
                                    if (transactionCode.contains("3PD")) {
                                        Log.info("Getting 3PC/3PD Counterpart");
                                        if (arSplitTrans[x - 1].contains(transactionsReport.get("rectnum" + String.valueOf(counter - 1))) && arSplitTrans[x - 1].trim().contains("3PC")) {
                                            Log.debug("Found transaction line: " + arSplitTrans[x].replace("\r\n", " "));
                                            creditAcct = getReportColumnValue(reportNumber, arSplitTrans[x - 1], handleFormatting("transdesc", "3PC", reportNumber), "creditacct");
                                        }
                                        if (arSplitTrans[x + 1].contains(transactionsReport.get("rectnum" + String.valueOf(counter - 1))) && arSplitTrans[x + 1].trim().contains("3PC")) {
                                            Log.debug("Found transaction line: " + arSplitTrans[x].replace("\r\n", " "));
                                            creditAcct = getReportColumnValue(reportNumber, arSplitTrans[x - 1], handleFormatting("transdesc", "3PC", reportNumber), "creditacct");
                                        }
                                        Log.debug("Updating 3PC to account from " + transactionsReport.get("creditacct" + String.valueOf(counter - 1)) + " to " + creditAcct);
                                        transactionsReport.put("creditacct" + String.valueOf(counter - 1), creditAcct);
                                    }

                                    //add condition for 3PD and 3PC
                                    if (transactionCode.contains("3PC")) {
                                        Log.info("Getting 3PC/3PD Counterpart");
                                        if (arSplitTrans[x - 1].contains(transactionsReport.get("rectnum" + String.valueOf(counter - 1))) && arSplitTrans[x - 1].trim().contains("3PD")) {
                                            Log.debug("Found transaction line: " + arSplitTrans[x].replace("\r\n", " "));
                                            debitAcct = getReportColumnValue(reportNumber, arSplitTrans[x - 1], handleFormatting("transdesc", "3PD", reportNumber), "debitacct");
                                        }
                                        if (arSplitTrans[x + 1].contains(transactionsReport.get("rectnum" + String.valueOf(counter - 1))) && arSplitTrans[x + 1].trim().contains("3PD")) {
                                            Log.debug("Found transaction line: " + arSplitTrans[x].replace("\r\n", " "));
                                            debitAcct = getReportColumnValue(reportNumber, arSplitTrans[x - 1], handleFormatting("transdesc", "3PD", reportNumber), "debitacct");
                                        }
                                        Log.debug("Updating 3PD from account from " + transactionsReport.get("debitacct" + String.valueOf(counter - 1)) + " to " + debitAcct);
                                        transactionsReport.put("debitacct" + String.valueOf(counter - 1), debitAcct);
                                    }
                                } catch (Exception e) {

                                }


                            }
                        }
                        break;
                    case "710":
                        for (int x = 0; x < arSplitTrans.length; x++) {
                            if (arSplitTrans[x].trim().contains(cardHolderNumber)) {
                                Log.info("Found transaction line: " + arSplitTrans[x].replace("\r\n", " "));
                                pushToHashMap(reportNumber, arSplitTrans[x], handleFormatting("transdesc", transCode, reportNumber));
                            }
                        }
                        break;
                }
            } catch (Exception e) {

            }
        }
        return transactionsReport;
    }


    public static String getReportBody(String reportFile) throws Exception {
        MsgParser msgp = new MsgParser();
        Message msg = msgp.parseMsg(reportFile);
        return msg.getBodyText();
    }


    public static void compareUIVsReport(HashMap<String, String> transactionsUI, HashMap<String, String> transactionsReport, String reportNumber) {
        LinkedHashMap<String, String> colsMap = getColumnMapUIToReport(reportNumber);
        int uiColCount = colsMap.size();
        for (int i = 0; i < Integer.parseInt(transactionsReport.get("transactionscount")); i++) {
            String id = transactionsReport.get(String.valueOf(Integer.parseInt(transactionsUI.get("receipt" + i))));
            String errorCode = transactionsReport.get("errorcode" + i);
            if (errorCode == null) {
                errorCode = "";
            }
            Log.nonStepInfo("****************************************************" + "\n"
                    + "Transaction for receipt id: " + transactionsReport.get("rectnum" + i) + " Validation"
                    + "\n" + "****************************************************");
            Iterator it = colsMap.entrySet().iterator();
            while (it.hasNext()) {
                HashMap.Entry pair = (HashMap.Entry) it.next();
                //compare UI vs report -> First parameter us UI, second is Report
                if (!errorCode.equals("") && pair.getKey().toString().contains("name")) {
                    Log.debug("Skipping card holder name validation due to error. Overriding expected and actual value.");
                    Report.reportStatus("Validate field " + pair.getKey(), transactionsReport.get(pair.getKey().toString() + i),
                            transactionsReport.get(pair.getKey().toString() + i), true, true);
                } else {
                    Report.reportStatus("Validate field " + pair.getKey(), handleFormatting(pair.getKey().toString(), transactionsUI.get(pair.getValue().toString() + id), reportNumber),
                            transactionsReport.get(pair.getKey().toString() + i), true, true);
                }
            }
            if (Log.returnCurrentReportString().toLowerCase().contains("fail")) {
                Log.error("Failure encountered while comparing Transaction History and Report...");
            }
        }
    }

    private static String handleFormatting(String fieldName, String value, String reportNumber) {
        //Convert UI to report format
        String valueTemp = value;
        if (fieldName.toLowerCase().contains("rectnum") || fieldName.toLowerCase().contains("issuenumber")) {
            valueTemp = String.valueOf(Integer.parseInt(value));
        }
        if (fieldName.toLowerCase().contains("date")) {
            valueTemp = value.toUpperCase();
        }
        if (fieldName.toLowerCase().contains("transdesc")) {
            valueTemp = getTransactionCodeEquivalent(value, reportNumber);
        }
        Log.debug("Formatting field " + fieldName + "'s UI value " + value + " to " + valueTemp);
        return valueTemp;
    }


    private static String[] getReports(String report, String bankingMachine, String cardHolderNumber, String body) {
        String[] reportBody = new String[20];
        int counter = 0;
        String[] arrBody = body.split("________________________________", -1);
        for (int i = 0; i < arrBody.length; i++) {
            //Report 700
            if (report.equals("700") && arrBody[i].trim().contains("PTB REPORT  " + report) && arrBody[i].trim().contains(cardHolderNumber)
                    && arrBody[i].trim().contains(bankingMachine)) {
                reportBody[counter] = arrBody[i];
                counter++;
            }
            //Report 710
            if (report.equals("710") && arrBody[i].trim().contains("PTB REPORT  " + report) && arrBody[i].trim().contains(cardHolderNumber)
                    && arrBody[i].trim().contains(bankingMachine)) {
                reportBody[counter] = arrBody[i];
                counter++;
            }
        }
        return reportBody;
    }

    private static LinkedHashMap<String, Integer> getColumnMap(String reportNumber, String transaction, String transDesc) {
        LinkedHashMap<String, Integer> colsMap = new LinkedHashMap<String, Integer>();
        int breakLoc = transaction.indexOf(transDesc);
        String[] arrBreak = transaction.split(transDesc, -1);
        switch (reportNumber) {
            case "700":
                //get name split
                colsMap.put("rectnum", 5);
                colsMap.put("date", 8);
                colsMap.put("time", 9);
                colsMap.put("cardholdernumber", 20);
                //handle reports with conversion
                if (transaction.contains("@")) {
                    String a = "";
                    colsMap.put("cardholdername", breakLoc - 43 - 3 - 5);
                    colsMap.put("errorcode", 5);
                    colsMap.put("issuenumber", 2);
                    colsMap.put("transdesc", 6);
                    colsMap.put("exchangerate", 14);
                    colsMap.put("transferamount", transaction.indexOf("FROM") - getHashmapTotalLength(colsMap));
                    //word from to the end of the account number
                    colsMap.put("debitacct", 4 + 16);
                    colsMap.put("currencycode", 2);
                    colsMap.put("settlementamount", transaction.indexOf("TO") - getHashmapTotalLength(colsMap));
                    colsMap.put("creditacct", 2 + transaction.length() - getHashmapTotalLength(colsMap));
                } else {
                    if (regexChecker(" (.)*(\\d)(\\d)(\\d)(.)* ", transaction.substring(breakLoc - 9 - 2, breakLoc).replace("\r\n", " "))) {
                        colsMap.put("cardholdername", breakLoc - 43 - 3 - 5);
                        colsMap.put("errorcode", 5);
                    } else {
                        colsMap.put("cardholdername", breakLoc - 43 - 3);
                        colsMap.put("errorcode", 0);
                    }

                    colsMap.put("issuenumber", 2);
                    colsMap.put("transdesc", 6);
                    colsMap.put("debitacct", 17);
                    colsMap.put("creditacct", 18);
                    colsMap.put("amount", arrBreak[1].length() - 35);
                }
                // colsMap.put("currency", 4);
                break;
            case "710":
                colsMap.put("transitaccount", 17);
                colsMap.put("cardholdername", 31);
                colsMap.put("cardholdernumber", 16);
                colsMap.put("rectnum", 6);
                colsMap.put("date", 8);
                colsMap.put("time", 9);
                colsMap.put("bankingmachineid", 6);
                colsMap.put("transdesc", 10);
                colsMap.put("fromacct", 21);
                colsMap.put("amount", 10);
        }
        return colsMap;
    }

    private static int getHashmapTotalLength(LinkedHashMap<String, Integer> map) {
        int sum = 0;
        for (int f : map.values()) {
            sum += f;
        }
        return sum;
    }


    private static void pushToHashMap(String reportNumber, String transaction, String transDesc) {
        String transactionCleaned = transaction.replace("\r\n", " ") + " ";
        LinkedHashMap<String, Integer> colsMap = getColumnMap(reportNumber, transaction, transDesc);
        Iterator it = colsMap.entrySet().iterator();
        int temp = 0;
        switch (reportNumber) {
            case "700":
                while (it.hasNext()) {
                    HashMap.Entry pair = (HashMap.Entry) it.next();
                    int length = 0;

                    //handle /r/n parsing for report body
                    if (temp + Integer.parseInt(pair.getValue().toString()) > transaction.length()) {
                        length = transaction.length();
                    } else {
                        length = temp + Integer.parseInt(pair.getValue().toString());
                    }

                    String value = transactionCleaned.substring(temp, length).trim();
                    //Clean amount value, add condition to exchange rate
                    if (pair.getKey().toString().contains("amount")) {
                        if (!transaction.contains("@")) {
                            transactionsReport.put("amount" + counter, getDecimal(value));
                            Log.debug("Report Column: " + pair.getKey().toString() + counter + " = " + getDecimal(value));
                            transactionsReport.put("currency" + counter, getCurrency(value));
                            Log.debug("Report Column: " + "currency" + counter + " = " + getCurrency(value));
                        } else {
                            transactionsReport.put(pair.getKey().toString() + counter, value);
                            Log.debug("Report Column: " + pair.getKey().toString() + counter + " = " + getDecimal(value));
                        }
                    }
                    //Clean conditions for entries with exchange rate
                    else if (pair.getKey().toString().contains("exchange")) {
                        transactionsReport.put(pair.getKey().toString() + counter, value.replace("@", "").trim());
                        Log.debug("Report Column: " + pair.getKey().toString() + counter + " = " + value.replace("@", "").trim());
                    } else if (pair.getKey().toString().contains("debit") || pair.getKey().toString().contains("credit")) {
                        transactionsReport.put(pair.getKey().toString() + counter, value.replace("TO", "").replace("FROM", "").trim());
                        Log.debug("Report Column: " + pair.getKey().toString() + counter + " = " + value.replace("TO", "").replace("FROM", "").trim());
                    } else if (pair.getKey().toString().contains("settlement")) {
                        transactionsReport.put(pair.getKey().toString() + counter, value.replace("TO", "").trim());
                        Log.debug("Report Column: " + pair.getKey().toString() + counter + " = " + value.replace("TO", "").trim());
                    } else if (pair.getKey().toString().contains("transferam")) {
                        transactionsReport.put(pair.getKey().toString() + counter, value.replace("FROM", "").trim());
                        Log.debug("Report Column: " + pair.getKey().toString() + counter + " = " + value.replace("FROM", "").trim());
                    } else {
                        transactionsReport.put(pair.getKey().toString() + counter, value);
                        Log.debug("Report Column: " + pair.getKey().toString() + counter + " = " + value);
                    }

                    temp = temp + Integer.parseInt(pair.getValue().toString());
                }
                Log.debug("Key: bankmachineid" + counter + " = " + bankMachineID);
                transactionsReport.put("bankingmachineid" + counter, bankMachineID);
                //add receipt reference as key for transaction
                transactionsReport.put(String.valueOf(Integer.parseInt(transactionsReport.get("rectnum" + counter))), String.valueOf(counter));
                transactionsReport.put("transactionscount", String.valueOf(counter + 1));
                counter++;
                break;
            case "710":
                while (it.hasNext()) {
                    HashMap.Entry pair = (HashMap.Entry) it.next();
                    int length = 0;

                    //handle /r/n parsing for report body
                    if (temp + Integer.parseInt(pair.getValue().toString()) > transaction.length()) {
                        length = transaction.length();
                    } else {
                        length = temp + Integer.parseInt(pair.getValue().toString());
                    }
                    String value = transactionCleaned.substring(temp, length).trim();
                    if (pair.getKey().toString().contains("amount")) {
                        transactionsReport.put("amount" + counter, getDecimal(value));
                        Log.debug("Report Column: " + pair.getKey().toString() + counter + " = " + getDecimal(value));
                    } else {
                        transactionsReport.put(pair.getKey().toString() + counter, value);
                        Log.debug("Report Column: " + pair.getKey().toString() + counter + " = " + value);
                    }
                    temp = temp + Integer.parseInt(pair.getValue().toString());
                }
                transactionsReport.put(String.valueOf(Integer.parseInt(transactionsReport.get("rectnum" + counter))), String.valueOf(counter));
                transactionsReport.put("transactionscount", String.valueOf(counter + 1));
                counter++;
                break;

        }
    }


    private static String getReportColumnValue(String reportNumber, String transaction, String transDesc, String column) {
        String transactionCleaned = transaction.replace("\r\n", " ") + " ";
        LinkedHashMap<String, Integer> colsMap = getColumnMap(reportNumber, transaction, transDesc);
        Iterator it = colsMap.entrySet().iterator();
        int temp = 0;
        switch (reportNumber) {
            case "700":
                while (it.hasNext()) {
                    HashMap.Entry pair = (HashMap.Entry) it.next();
                    int length = 0;

                    //handle /r/n parsing for report body
                    if (temp + Integer.parseInt(pair.getValue().toString()) > transaction.length()) {
                        length = transaction.length();
                    } else {
                        length = temp + Integer.parseInt(pair.getValue().toString());
                    }

                    if (column.equals(pair.getKey().toString())) {
                        String value = transactionCleaned.substring(temp, length).trim();
                        if (pair.getKey().toString().contains("amount")) {
                            Log.debug("Got Report Column: " + pair.getKey().toString() + counter + " = " + getDecimal(value));
                            return getDecimal(value);
                        } else if (pair.getKey().toString().contains("currency")) {
                            Log.debug("Got Report Column: " + "currency" + counter + " = " + getCurrency(value));
                            return getCurrency(value);
                        } else {
                            Log.debug("Got Report Column: " + pair.getKey().toString() + counter + " = " + value);
                            return value;
                        }
                    }
                    temp = temp + Integer.parseInt(pair.getValue().toString());
                }
                break;
            case "710":
                while (it.hasNext()) {
                    HashMap.Entry pair = (HashMap.Entry) it.next();
                    int length = 0;

                    //handle /r/n parsing for report body
                    if (temp + Integer.parseInt(pair.getValue().toString()) > transaction.length()) {
                        length = transaction.length();
                    } else {
                        length = temp + Integer.parseInt(pair.getValue().toString());
                    }
                    String value = transactionCleaned.substring(temp, length).trim();
                    if (column.equals(pair.getKey().toString())) {
                        if (pair.getKey().toString().contains("amount")) {
                            Log.debug("Got Report Column: " + pair.getKey().toString() + counter + " = " + getDecimal(value));
                            return getDecimal(value);
                        } else {
                            Log.debug("Got Report Column: " + pair.getKey().toString() + counter + " = " + value);
                            return value;
                        }
                    }
                    temp = temp + Integer.parseInt(pair.getValue().toString());
                }
                break;
            default:
                Log.debug("Got no value from column: " + column);
                return "";
        }
        return "";
    }


    private static LinkedHashMap<String, String> getColumnMapUIToReport(String reportNumber) {
        LinkedHashMap<String, String> colsMap = new LinkedHashMap<String, String>();
        switch (reportNumber) {
            case "700":
                //get name split
                colsMap.put("rectnum", "receipt");
                colsMap.put("date", "date");
                colsMap.put("time", "time");
                colsMap.put("cardholdernumber", "cardholdernumber");
                colsMap.put("cardholdername", "cardholdername");
                colsMap.put("bankingmachineid", "bankingmachineid");
                colsMap.put("issuenumber", "issue");
                colsMap.put("transdesc", "transaction");
                colsMap.put("debitacct", "fromacct");
                colsMap.put("creditacct", "toacct");
                colsMap.put("amount", "amount");
                colsMap.put("errorcode", "authorizedbyerrorcode");
                break;
            case "700RBCExpress":
                //get name split
                colsMap.put("rectnum", "receipt");
                colsMap.put("date", "date");
                colsMap.put("cardholdernumber", "cardholdernumber");
                colsMap.put("cardholdername", "cardholdername");
                colsMap.put("bankingmachineid", "bankingmachineid");
                colsMap.put("transdesc", "transaction");
                colsMap.put("debitacct", "fromacct");
                colsMap.put("creditacct", "toacct");
                colsMap.put("transferamount", "transferamount");
                colsMap.put("settlementamount", "settlementamount");
                colsMap.put("exchangerate", "exchangerate");
                break;
            case "700RBCExpress2":
                //get name split
                colsMap.put("rectnum", "receipt");
                colsMap.put("date", "date");
                colsMap.put("cardholdernumber", "cardholdernumber");
                colsMap.put("cardholdername", "cardholdername");
                colsMap.put("bankingmachineid", "bankingmachineid");
                colsMap.put("transdesc", "transaction");
                colsMap.put("debitacct", "fromacct");
                colsMap.put("creditacct", "toacct");
                colsMap.put("amount", "amount");
                break;
            case "710":
                //get name split
                colsMap.put("rectnum", "receipt");
                colsMap.put("date", "date");
                colsMap.put("time", "time");
                colsMap.put("cardholdernumber", "cardholdernumber");
                colsMap.put("cardholdername", "cardholdername");
                colsMap.put("bankingmachineid", "bankingmachineid");
                colsMap.put("transdesc", "transaction");
                colsMap.put("fromacct", "toacct");
                colsMap.put("amount", "amount");
                break;
        }
        return colsMap;
    }

    private static void getBankMachineID(String report) {
        bankMachineID = report.split("BANKING MACHINE", -1)[1].substring(0, 5).trim();
    }

    private static String getTransactionCodeEquivalent(String code, String reportNumber) {
        switch (code.toLowerCase()) {
            case "tsf":
                return "TSFR";
            case "bp":
                return "PMNT";
            default:
                return code;
        }
    }

    private static String getDecimal(String input) {
        if (input.substring(0, 1).equals(".")) {
            input = "0" + input;
        }
        Pattern regex = Pattern.compile("(\\d+(?:\\.\\d+)?)");
        Matcher matcher = regex.matcher(input);
        String temp = "";
        while (matcher.find()) {
            temp = matcher.group(1);
        }
        if (temp.substring(0, 2).equals("0.")) {
            temp = temp.replace("0.", ".");
            temp = temp.indexOf(".") < 0 ? temp : temp.replaceAll("0*$", "").replaceAll("\\.$", "");
        }
        return temp;
    }


    private static String getCurrency(String input) {
        if (input.substring(0, 1).equals(".")) {
            input = "0" + input;
        }
        String[] tempString = input.split(input, -1);
        if (tempString.length > 1) {
            return tempString[1];
        } else {
            return "";
        }
    }


}