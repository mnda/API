package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.*;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class InquiryPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public InquiryPage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing InquiryPage...");
        SyncHelperWeb.waitForElementToAppear(getInquiryHeaderWebElement());
        Log.debug("InquiryPage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        InquiryPage page = new InquiryPage();
//        page.searchClient("test");
        CoreFrameworkWeb.cleanupSDK();
    }


    public void inquire(String cardNumber, String inquiryCode, String issueNumber, String printIndicator) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getCardNumberEditField(), cardNumber);
        CoreFrameworkWeb.set(getInquiryCodeEditField(), inquiryCode);
        CoreFrameworkWeb.set(getIssueNumberEditField(), issueNumber);

        if (!printIndicator.toLowerCase().contains("na")) {
            if (printIndicator.toLowerCase().contains("yes")) {
                CoreFrameworkWeb.set(getPrintIndicatorRadioGroup(), 0);
            } else {
                CoreFrameworkWeb.set(getPrintIndicatorRadioGroup(), 1);
            }
        }

        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }

    //    /* -- Get Objects --*/

    private WebElement getInquiryHeaderWebElement() {
        return GetObjectWeb.getWebElementObject(mainPage, new WebElementDescription.Builder()
                .tagName("H1").innerText(new RegExpProperty(".*Inquiry.*|.*Interrogation.*")).build());
    }

    private EditField getCardNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("displayCardNumber").build());
    }

    private EditField getInquiryCodeEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("inquiryCode").build());
    }

    private EditField getIssueNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("issueNumberInput").build());
    }

    private RadioGroup getPrintIndicatorRadioGroup() {
        return GetObjectWeb.getRadioGroupObject(getMainPage(), new RadioGroupDescription.Builder()
                .tagName("INPUT").name("printIndicator").build());
    }


}
