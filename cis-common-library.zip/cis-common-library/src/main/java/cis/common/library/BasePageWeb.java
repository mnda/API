package cis.common.library;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.*;
import com.hp.lft.sdk.winforms.WindowDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.web.AbstractPageWeb;
import pcb.auto.pom.core.web.GetObjectWeb;

/**
 * Created by angmark on 6/5/2017.
 */
public abstract class BasePageWeb extends AbstractPageWeb {
    protected BasePageWeb() {
    }

    protected static Page mainPage;

    //    /* -- Get Objects --*/
    public Page getMainPage() {
        return GetObjectWeb.getPageObject(new WindowDescription.Builder()
                        .windowTitleRegExp(new RegExpProperty(".*Client Identification System.*")).build(),
                new PageDescription.Builder().title(new RegExpProperty(".*SIC - Système d'identification des clients.*|.*CIS - Client Identification System.*")).build());
    }

    //    /* -- Get Objects --*/
    public Page getMainPage2() {
        return GetObjectWeb.getPageObject(new WindowDescription.Builder()
                        .windowTitleRegExp(new RegExpProperty(".*Client Identification System.*")).build(),
                new PageDescription.Builder().title("").build());


    }

    public String getHeaderTitle() throws GeneralLeanFtException {
        String headerTitle = getHeaderWebElement(mainPage).getInnerText();
        Log.debug("Got header title: " + headerTitle);
        return headerTitle;
    }

    //Dialog Page
    public Page getDialogPage() {
        return GetObjectWeb.getDialogPageObject(new WindowDescription.Builder()
                .windowTitleRegExp(new RegExpProperty(".*Client Identification System.*")).index(0).build(), new WindowDescription.Builder()
                .windowTitleRegExp(new RegExpProperty(".*Webpage Dialog.*")).build(), new PageDescription.Builder()
                .title(new RegExpProperty(".*Printer.*|.*SIC - Système d'identification des clients.*|.*CIS - Client Identification System.*")).index(0).build());
    }

    //Re-usable Buttons
    public Image getContinueButton(Page page) {
        return GetObjectWeb.getImageObject(page, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_continue.*")).type(ImageType.LINK).tagName("IMG").build());
    }

    public Image getCancelButton(Page page) {
        return GetObjectWeb.getImageObject(page, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_cancel.*")).type(ImageType.LINK).tagName("IMG").build());
    }

    public Image getSubmitButton(Page page) {
        return GetObjectWeb.getImageObject(page, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_submit.*")).type(ImageType.LINK).tagName("IMG").build());
    }

    public Image getDisplayButton(Page page) {
        return GetObjectWeb.getImageObject(page, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_display.*")).type(ImageType.LINK).tagName("IMG").build());
    }

    public Image getYesButton(Page page) {
        return GetObjectWeb.getImageObject(page, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_yes.*")).type(ImageType.LINK).tagName("IMG").build());
    }

    public Image getNoButton(Page page) {
        return GetObjectWeb.getImageObject(page, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_no.*")).type(ImageType.LINK).tagName("IMG").build());
    }

    public Image getOkButton(Page page) {
        return GetObjectWeb.getImageObject(page, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_ok.*")).type(ImageType.LINK).tagName("IMG").build());
    }

    public Image getClearButton(Page page) {
        return GetObjectWeb.getImageObject(page, new ImageDescription.Builder()
                .outerHTML(new RegExpProperty(".*btn_clear.*")).type(ImageType.LINK).tagName("IMG").build());
    }

    //Table
    private Table getErrorTable(Page page) {
        return GetObjectWeb.getTableObject(page, new TableDescription.Builder()
                .tagName("TABLE").name(new RegExpProperty(".*Alert.*|.*Confirmation.*")).index(1).build());
    }

    public String getErrorMessage(Page page) throws GeneralLeanFtException {
        String errMsg = "";
        if (getErrorTable(page).exists()) {
            errMsg = getErrorTable(page).getInnerText().trim();
        }
        return errMsg;
    }

    //Links

    public Link getPrintLink(Page page) {
        return GetObjectWeb.getLinkObject(page, new LinkDescription.Builder()
                .tagName("A").innerText("Print").index(0).build());
    }

    public Link getCancelLink(Page page) {
        return GetObjectWeb.getLinkObject(page, new LinkDescription.Builder()
                .tagName("A").innerText("Cancel").index(0).build());
    }

    public Link getHelpLink(Page page) {
        return GetObjectWeb.getLinkObject(page, new LinkDescription.Builder()
                .tagName("A").innerText("Help").build());
    }

    public Link getExitLink(Page page) {
        return GetObjectWeb.getLinkObject(page, new LinkDescription.Builder()
                .tagName("A").innerText("Exit").build());
    }

    public Link getMainMenuLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").innerText("Main Menu").build());
    }

    //header
    public WebElement getHeaderWebElement(Page page) {
        return GetObjectWeb.getWebElementObject(page, new WebElementDescription.Builder()
                .tagName("H1").index(0).build());
    }


    protected void waitUntilVisible() {
    }

}
