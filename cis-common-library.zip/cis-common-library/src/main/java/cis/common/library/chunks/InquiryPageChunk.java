package cis.common.library.chunks;


import cis.common.library.BaseChunkWeb;
import cis.common.library.helper.CISALPHelper;
import cis.common.library.pages.InquiryPage;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.*;
import cucumber.api.Scenario;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.Report;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;
import pcb.auto.pom.core.web.internal.click.ClickWeb;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * Created by angmark on 5/25/2017.
 */
public class InquiryPageChunk extends BaseChunkWeb {
    public static Page mainPage;


    public InquiryPageChunk(Page parent) {
        super(parent);
        mainPage = parent;
        Log.debug("InquiryPageChunk successfully initialized");
    }

    public static void main(String[] args) throws Exception, Throwable {
        Scenario scenario = null;
        CoreFrameworkWeb.instantiateSDK();
        System.setProperty("logDebug", "true");

        InquiryPage inquiryPage = new InquiryPage();
        InquiryPageChunk inquiryPageChunk = new InquiryPageChunk(inquiryPage.getMainPage());
        inquiryPageChunk.getTransactionTableValues2("18Jul11", "TSF", "700", "MIN0", scenario);
        CoreFrameworkWeb.cleanupSDK();
    }

    HashMap<String, String> tableMap;

    //Adding table to hashmap because LeanFT implementation is too slow
    private void putTransactionTableToMap() throws GeneralLeanFtException {
        tableMap = new HashMap<String, String>();
        String tableHTML = getTransactionTable().getInnerHTML().replace("<TR class=tableDarkRow>", "").replace("<TD class=infoText headers=", "").replace("<TD class=spacerheader1></TD>", "");
        String[] arRows = tableHTML.split("</TR>");
        int totalRows = -1;
        for (int i = 3; i < arRows.length; i++) {
            String[] arColumnsSplit = arRows[i].split("</TD>");
            for (int x = 0; x < arColumnsSplit.length; x++) {
                if (arColumnsSplit[x].contains("date")) {
                    totalRows++;
                }
                if (arColumnsSplit[x].contains("<TR")) {
                    String[] arColumnsSplit2 = arColumnsSplit[x].replace("<TR>", "").split("<TD");
                    for (int y = 0; y < arColumnsSplit2.length; y++) {
                        //Log.debug(arColumnsSplit2[y]);
                        pushHistoryTableToMap(arColumnsSplit2[y], totalRows);
                    }
                } else {
                    //Log.debug(arColumnsSplit[x]);
                    pushHistoryTableToMap(arColumnsSplit[x], totalRows);
                }
            }
        }
        tableMap.put("totalrows", String.valueOf(totalRows));
    }

    private void pushHistoryTableToMap(String input, int row) {
        if (input.contains("date")) {
            tableMap.put("date" + row, input.split("date>", -1)[1].trim());
            tableMap.remove("lastdate", input.split("date>", -1)[1].trim());
            tableMap.put("lastdate", input.split("date>", -1)[1].trim());
        }
        if (input.contains("time")) {
            tableMap.put("time" + row, input.split("time>", -1)[1].trim());
        }
        if (input.contains("transaction")) {
            tableMap.put("transaction" + row, input.split("transaction>", -1)[1].trim());
        }
        if (input.contains("walletId")) {
            tableMap.put("walletId" + row, input.split("walletId>", -1)[1].trim());
        }
        if (input.contains("bankingmachineid")) {
            tableMap.put("bankingmachineid" + row, input.split("bankingmachineid>", -1)[1].trim());
        }
        if (input.contains("receipt")) {
            tableMap.put("receipt" + row, input.split("receipt>", -1)[1].trim());
        }
        if (input.contains("authorizedbyerrorcode")) {
            tableMap.put("authorizedbyerrorcode" + row, input.split("authorizedbyerrorcode>", -1)[1].trim());
        }
        if (input.contains("issue")) {
            tableMap.put("issue" + row, input.split("issue>", -1)[1].trim().substring(0, 2));
        }
        if (input.contains("fromacct")) {
            tableMap.put("fromacct" + row, input.split("fromacct>", -1)[1].trim());
        }
        if (input.contains("toacct")) {
            tableMap.put("toacct" + row, input.split("toacct>", -1)[1].trim());
        }
        if (input.contains("branchtransit")) {
            tableMap.put("branchtransit" + row, input.split("branchtransit>", -1)[1].trim());
        }
        if (input.contains("authorization")) {
            tableMap.put("authorization" + row, input.split("authorization>", -1)[1].trim());
        }
        if (input.contains("cta")) {
            tableMap.put("cta" + row, input.split("cta>", -1)[1].trim());
        }
        if (input.contains("amount")) {
            tableMap.put("amount" + row, input.split("amount>", -1)[1].trim());
        }
    }

    String columns = "date,time,transaction,receipt,bankingmachineid,authorizedbyerrorcode,issue,fromacct,toacct,branchtransit,authorization,cta,amount";

    public HashMap<String, String> getTransactionTableValues2(String date, String transactionCode, String reportNumber, String machineID, Scenario scenario) throws GeneralLeanFtException {
        HashMap<String, String> transactions = new HashMap<String, String>();
        int rowCounter = 0;
        try {
            //loop to check if date is available click next if not
            while (getNextLink().exists(1)) {
                putTransactionTableToMap();
                int ssFlag = 0;
                for (int j = 0; j <= Integer.parseInt(tableMap.get("totalrows")); j++) {
                    int foundFlag = 0;
                    if (tableMap.get("date" + j).toLowerCase().contains(date.toLowerCase())) {
                        //take screenshot when found
                        if (ssFlag == 0) {
                            try {
                                Log.takeScreenshotWeb(scenario, new InquiryPage().getMainPage(), transactionCode + "_History");
                            } catch (Exception e) {

                            }
                            ssFlag = 1;
                        }
                        //Report 700
                        if (reportNumber.equals("700") && tableMap.get("date" + j).toLowerCase().contains(date.toLowerCase()) &&
                                tableMap.get("transaction" + j).toLowerCase().contains(transactionCode.toLowerCase()) &&
                                tableMap.get("bankingmachineid" + j).toLowerCase().contains(machineID.toLowerCase())) {
                            String[] arCols = columns.split(",");
                            for (int i = 0; i < arCols.length; i++) {
                                String value = tableMap.get(arCols[i] + j);
                                String column = arCols[i] + rowCounter;
                                Log.debug("UI Column: " + column + " was added with value: " + value);
                                transactions.put(column, value);
                            }
                            foundFlag = 1;
                            transactions.put("cardholdername" + rowCounter, getClientName().getValue().trim());
                            transactions.put("cardholdernumber" + rowCounter, getCardHolderNumber().getValue().trim());
                        }

                        //HISTORY -- Just get the first page
                        if (reportNumber.equals("HISTORY") && tableMap.get("date" + j).toLowerCase().contains(date.toLowerCase()) &&
                                tableMap.get("transaction" + j).toLowerCase().contains(transactionCode.toLowerCase())) {
                            String[] arCols = columns.split(",");
                            for (int i = 0; i < arCols.length; i++) {
                                String value = tableMap.get(arCols[i] + j);
                                String column = arCols[i] + rowCounter;
                                Log.debug("UI Column: " + column + " was added with value: " + value);
                                transactions.put(column, value);
                            }
                            foundFlag = 1;
                            transactions.put("cardholdername" + rowCounter, getClientName().getValue().trim());
                            transactions.put("cardholdernumber" + rowCounter, getCardHolderNumber().getValue().trim());
                            transactions.put("transactionscount", String.valueOf(rowCounter));
                            if (rowCounter >= 3) {
                                return transactions;
                            }
                        }

                        //Report 710 - applies to UI with error code 000 and 999
                        if (reportNumber.equals("710") && tableMap.get("date" + j).toLowerCase().contains(date.toLowerCase()) &&
                                (tableMap.get("authorizedbyerrorcode" + j).toLowerCase().contains("000") ||
                                        tableMap.get("authorizedbyerrorcode" + j).toLowerCase().contains("999"))) {
                            String[] arCols = columns.split(",");
                            for (int i = 0; i < arCols.length; i++) {
                                String value = tableMap.get(arCols[i] + j);
                                String column = arCols[i] + rowCounter;
                                Log.debug("UI Column: " + column + " was added with value: " + value);
                                transactions.put(column, value);
                            }
                            foundFlag = 1;
                            transactions.put("cardholdername" + rowCounter, getClientName().getValue().trim());
                            transactions.put("cardholdernumber" + rowCounter, getCardHolderNumber().getValue().trim());
                        }
                    }
                    if (foundFlag == 1) {
                        rowCounter++;
                    }
                }
                //stop when date is less than the searched date
                if (checkDateIsLess(tableMap.get("lastdate"), date)) {
                    transactions.put("transactionscount", String.valueOf(rowCounter));
                    return transactions;
                }
                getNextLink().click();
            }
        } catch (Exception e) {
            //place holder
            String a = "3";
        }
        if (rowCounter == 0) {
            Report.reportStatusThenExit("No records found for date:" + date + " with transaction code:" + transactionCode + " From CIS ALP UI");
        } else {
            transactions.put("transactionscount", String.valueOf(rowCounter));
        }

        return transactions;
    }


    public HashMap<String, String> getTransactionTableValues(String date, String transactionCode, Scenario scenario) throws GeneralLeanFtException {
        List<TableRow> tblRows = getTransactionTable().getRows();
        HashMap<String, String> transactions = new HashMap<String, String>();
        int rowCounter = 0;
        try {
            //loop to check if date is available click next if not
            while (getNextLink().exists()) {
                int foundFlag = 0;
                for (int j = 3; j + 1 <= tblRows.size() - 1; j = j + 2) {
                    List<TableCell> tblCells1Temp = tblRows.get(j).getCells();
                    if (tblCells1Temp.get(0).getText().toLowerCase().contains(date.toLowerCase()) && foundFlag == 0) {
                        //take screenshot when found
                        Log.takeScreenshotWeb(scenario, new InquiryPage().getMainPage(), transactionCode + "_History");
                        for (int i = 3; i + 1 <= tblRows.size() - 1; i = i + 2) {
                            int flag = 0;
                            List<TableCell> tblCells1 = tblRows.get(i).getCells();
                            List<TableCell> tblCells2 = tblRows.get(i + 1).getCells();
                            for (int x = 0; x <= tblCells1.size() - 1; x++) {
                                if (tblCells1.get(0).getText().toLowerCase().contains(date.toLowerCase()) &&
                                        tblCells1.get(2).getText().toLowerCase().contains(transactionCode.toLowerCase())) {
                                    String column1 = CISALPHelper.stripStringWithSpecialCharacters(tblRows.get(0).getCells().get(x).getText()).toLowerCase() + rowCounter;
                                    String column2 = CISALPHelper.stripStringWithSpecialCharacters(tblRows.get(1).getCells().get(x).getText()).toLowerCase() + rowCounter;
                                    String value1 = tblCells1.get(x).getText();
                                    String value2 = tblCells2.get(x).getText();
                                    if (column1.length() > 1) {
                                        Log.debug("UI Column: " + column1 + " was added with value: " + value1);
                                        transactions.put(column1, value1);
                                    }
                                    if (column2.length() > 1) {
                                        Log.debug("UI Column: " + column2 + " was added with value: " + value2);
                                        transactions.put(column2, value2);
                                    }
                                    flag = 1;
                                    foundFlag = 1;
                                    transactions.put("cardholdername" + rowCounter, getClientName().getValue().trim());
                                    transactions.put("cardholdernumber" + rowCounter, getCardHolderNumber().getValue().trim());
                                }
                            }
                            if (flag == 1) {
                                rowCounter++;
                            }
                        }

                    } else if (getDate(date).after(getDate(tblCells1Temp.get(0).getText().toUpperCase()))) {
                        break;
                    }
                }
                getNextLink().click();
            }
        } catch (Exception e) {
            //place holder
            String a = "3";
        }
        if (rowCounter == 0) {
            Report.reportStatusThenExit("No records found for date:" + date + " with transaction code:" + transactionCode + " From CIS ALP UI");
        } else {
            transactions.put("transactionscount", String.valueOf(rowCounter));
        }

        getCancelButton().click();
        return transactions;
    }


    public HashMap<String, String> getElectronicAccessLimits() throws GeneralLeanFtException {
        HashMap<String, String> electronicAccessLimits = new HashMap<>();

        electronicAccessLimits.put("ReleaseAmount1", getReleaseAmountEditField().getValue().replace(",", "").trim());
        electronicAccessLimits.put("AtmWithdrawalAmount1", getATMWithdrawalEditField().getValue().replace(",", "").trim());
        electronicAccessLimits.put("POSTransactionAmount1", getPOSTransactionEditField().getValue().replace(",", "").trim());
        electronicAccessLimits.put("3PPAmount1", get3PPEditField().getValue().replace(",", "").trim());
        electronicAccessLimits.put("ForeignCashPurchaseAmount1", getForeignCashPurchaseEditField().getValue().replace(",", "").trim());

        return electronicAccessLimits;
    }

    public HashMap<String, String> getResultsSection() throws GeneralLeanFtException {
        HashMap<String, String> resultsSection = new HashMap<>();

        resultsSection.put("AccountPackageEntitlement1", getAccountPackageEntitlementEditField().getValue().trim());

        return resultsSection;
    }


    public void cancelInquiry() throws GeneralLeanFtException {
        ClickWeb.click(getCancelButton());
    }
    //** Get Objects **/

    //Electronic Access Limists Section
    private EditField getReleaseAmountEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("releaseAmountCurrent").build());
    }

    private EditField getATMWithdrawalEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("currentWithdraw").build());
    }

    private EditField getPOSTransactionEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("currentPos").build());
    }

    private EditField get3PPEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("current3PP").build());
    }

    private EditField getForeignCashPurchaseEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("fcoCurrentLimit").build());
    }


    //Button
    private Image getCancelButton() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .alt("Cancel Button").type(ImageType.LINK).tagName("IMG").build());
    }

    private Image getRepeatButton() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .alt("Repeat Button").type(ImageType.LINK).tagName("IMG").build());
    }

    //Table
    private Table getTransactionTable() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty("DateTimeTransactionWallet.*")).build());
    }

    private EditField getClientName() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clientName").build());
    }

    private EditField getCardHolderNumber() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("displayCardNumber").index(1).build());
    }


    //Results Section
    private EditField getAccountPackageEntitlementEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("accountPackageEntitlement").build());
    }

    private EditField getDailyAccessLimitsEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("dailyAccessLimits").build());
    }

    private EditField getIssueNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("issueNumber").build());
    }

    private EditField getTactileIndicatorEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("tactileIndicator").build());
    }


    private EditField getHomeBranchTransitEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("homeBranchTransit").build());
    }

    //Link
    private Link getNextLink() {
        return GetObjectWeb.getLinkObject(mainPage, new LinkDescription.Builder()
                .tagName("A").innerText("Next").build());
    }

    //helper class
    private Date getDate(String dateInput) throws Exception {
        DateFormat df = new SimpleDateFormat("yyMMMdd");
        try {
            return df.parse(dateInput.toUpperCase());
        } catch (Exception e) {
            return df.parse("18JAN01");
        }

    }


    private static boolean checkDateIsLess(String lastDate, String searchDate) {
        String newLastDate = "20" + lastDate.substring(0, 2) + "-" + lastDate.substring(2, 5) + "-" + lastDate.substring(5, 7);
        String newSearchDate = "20" + searchDate.substring(0, 2) + "-" + searchDate.substring(2, 5) + "-" + searchDate.substring(5, 7);

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MMM-dd");

        try {

            Date dLastDate = formatter.parse(newLastDate);
            Date dSearchDate = formatter.parse(newSearchDate);
            if (dLastDate.before(dSearchDate)) {
                return true;
            } else {
                return false;
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }

        return false;
    }

}
