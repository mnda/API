package cis.common.library.interfaces.mobilizer.olbjmeter;


import cis.common.library.helper.CISALPHelper;
import org.apache.commons.io.FileUtils;
import pcb.auto.pom.core.helper.CoreFrameworkHelper;
import pcb.auto.pom.core.helper.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Scanner;

/**
 * Created by angmark on 6/5/2017.
 */
public class OLBJmeter {
    public static void main(String[] argv) throws Exception {
        System.setProperty("logDebug", "true");
        new OLBJmeter().runOLBTransferJmeter("3pp", "", "s3w04688irule", "4519035697934588", "discovery", "TODAY", "1.02", "02342-5006788", "02342-1002815");
        //new OLBJmeter().getTransValues();
    }

    public static HashMap<String, String> runOLBTransferJmeter(String transactionType, String transferType, String server, String clientCard, String clientCardPassword, String date, String amount, String fromAccount, String toAccount) throws Exception {
        String dateEncoded = CISALPHelper.getDateCode(date);
        String[] arDateEncoded = dateEncoded.split("/", -1);

        String month = String.valueOf(Integer.parseInt(arDateEncoded[0]));
        String day = String.valueOf(Integer.parseInt(arDateEncoded[1]));
        String year = String.valueOf(Integer.parseInt(arDateEncoded[2]));
        String jmeterScriptLocation = "";
        switch (transactionType.toLowerCase()) {
            case "transfer":
                jmeterScriptLocation = "C:/LeanFTTests/CISALP/jmeterscripts/OLB_Transfer.jmx";
                break;
            case "3pp":
                jmeterScriptLocation = "C:/LeanFTTests/CISALP/jmeterscripts/OLB_3PP.jmx";
                break;
            case "bp":
                jmeterScriptLocation = "C:/LeanFTTests/CISALP/jmeterscripts/OLB_Bill_Payments.jmx";
                break;

        }


        String cmd = "jmeter -n -t " + jmeterScriptLocation +
                " -Jserver=" + server + " " +
                "-JclientCardNumber=" + clientCard + " " +
                "-JclientCardNumberPassword=" + clientCardPassword + " " +
                "-Jday=" + day + " " +
                "-Jmonth=" + month + " " +
                "-Jyear=" + year + " " +
                "-Jamount=" + amount + " " +
                "-JfromAccount=" + fromAccount + " " +
                "-JtoAccount=" + toAccount;

        Log.info("Running command in Jmeter:" + cmd.replace("-J", "\n-J"));
        ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/c", cmd);
        builder.directory(new File(CoreFrameworkHelper.getValuesFromProperties("testsettings.properties", "jmeterhome")));
        builder.redirectErrorStream(true);
        Process p = builder.start();
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while (true) {
            line = r.readLine();
            if (line == null) {
                break;
            }
            Log.debug(line);
        }
        String transactionData = getTransValues();
        String[] arTransactionData = transactionData.trim().split(",", -1);

        if (transferType.toLowerCase().contains("negative")) {
            pushDateAndTime();
            return transferFundsForNegative;
        } else {
            HashMap<String, String> transferReturnValues = new HashMap<>();
            try {
                transferReturnValues.put("confirmationNumber1", arTransactionData[0]);

                String[] arCONF_DATE = arTransactionData[1].split(" ", -1);

                String formattedDate = arCONF_DATE[1] + " " + String.format("%02d", Integer.parseInt(arCONF_DATE[0])) + " " + arCONF_DATE[2];

                transferReturnValues.put("currentDate1", formattedDate);
                transferReturnValues.put("currentTime1", arTransactionData[2]);
            } catch (Exception e) {
                Log.error("OLB Jmeter Transfer Failed. No confirmation number generated.");
            }

            return transferReturnValues;
        }
    }

    private static String getTransValues() throws Exception {
        Scanner scanner = new Scanner(new File("C:\\LFTTempReports\\jmeterresult.csv"));
        scanner.useDelimiter(",");
        String temp = "";
        while (scanner.hasNext()) {
            temp = temp + scanner.next() + "|";
        }
        scanner.close();
        temp = temp.replace("CONF_DATE:", ",").replace("CONF_NUMBER:", "").replace("CONF_TIME:", ",").replace("|", "").replace("\r\n", "");
        Log.debug("Returning Jmeter transaction output: " + temp);
        FileUtils.deleteQuietly(new File("C:\\LFTTempReports\\jmeterresult.csv"));
        return temp;
    }

    private static HashMap<String, String> transferFundsForNegative = new HashMap<String, String>();

    private static void pushDateAndTime() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyMMMdd-HH:mm");
        LocalDateTime now = LocalDateTime.now();
        String dateNow = dtf.format(now);

        transferFundsForNegative.put("confirmationNumber1", "");
        Log.debug("Getting request timing for negative TCs: " + dateNow);
        transferFundsForNegative.put("currentDate1", dateNow.split("-", -1)[0]);
        transferFundsForNegative.put("currentTime1", dateNow.split("-", -1)[1]);

    }

}
