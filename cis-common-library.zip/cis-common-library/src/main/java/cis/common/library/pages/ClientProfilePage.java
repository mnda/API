package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class ClientProfilePage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public ClientProfilePage() throws GeneralLeanFtException, InterruptedException {
        mainPage = getMainPage2();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing ClientProfilePage...");
        SyncHelperWeb.waitForElementToAppear(getContinueButton(mainPage));
        Log.debug("ClientProfilePage successfully initialized");
    }

    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        System.setProperty("logDebug", "true");
        ClientProfilePage page = new ClientProfilePage();
        page.clickContinue();
        CoreFrameworkWeb.cleanupSDK();
    }

    public void clickContinue() throws GeneralLeanFtException {
        CoreFrameworkWeb.click(getContinueButton(mainPage));
    }


    //    /* -- Get Objects --*/
}
