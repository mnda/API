package cis.common.library.testdata;

/**
 * Created by angmark on 5/25/2017.
 */

public enum TradeOptions {
    NEW_CASH_COLLATERAL_RECEIVE("new_cash_receive"),
    NEW_CASH_COLLATERAL_DELIVER("new_cash_deliver"),
    NEW_COLLATERAL_RECEIVE("new_sec_receive"),
    NEW_COLLATERAL_DELIVER("new_sec_deliver"),
    EDIT_TRADE("edit_trade"),
    COPY_TRADE("copy_trade");


    private String tradeOptions;

    TradeOptions(String tradeOptions) {
        this.tradeOptions = tradeOptions;
    }

    public String getValue() {
        return tradeOptions;
    }
}
