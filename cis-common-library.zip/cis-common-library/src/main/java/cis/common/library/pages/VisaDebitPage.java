package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import cis.common.library.helper.CISALPHelper;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.Table;
import com.hp.lft.sdk.web.TableCell;
import com.hp.lft.sdk.web.TableDescription;
import com.hp.lft.sdk.web.TableRow;
import pcb.auto.pom.core.helper.CoreFrameworkHelper;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.Report;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;

import java.util.HashMap;
import java.util.List;


/**
 * Created by angmark on 5/25/2017.
 */
public class VisaDebitPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public VisaDebitPage() {
        mainPage = getMainPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing VisaDebitPage...");
        //SyncHelperWeb.waitForElementToAppear(getVisaDebitInquiryFunctionsRadioGroup());
        Log.debug("VisaDebitPage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        VisaDebitPage visaDebitPage = new VisaDebitPage();
        System.setProperty("logDebug", "true");
        visaDebitPage.getVisaDebitNumbersTableContent(1);

        CoreFrameworkWeb.cleanupSDK();
    }


    public HashMap<String, String> getVisaDebitNumbersTableContent() throws GeneralLeanFtException {
        return CISALPHelper.getWebTableContents(getVisaNumbersTable(), "Visa Debit Number List");
    }

    public HashMap<String, String> getVisaDebitNumbersTableContent(int rows) throws GeneralLeanFtException {
        return getVisaDebitTableContents(getVisaNumbersTable(), "Visa Debit Number List", rows);
    }


    public static HashMap<String, String> getVisaDebitTableContents(Table table, String tableDesc, int rows) throws GeneralLeanFtException {
        List<TableRow> tblRows = table.getRows();
        List<TableCell> tblCells1 = null;
        HashMap<String, String> tableContent = new HashMap<String, String>();
        int rowCounter = 1;
        String latestVisaDebit = getLatestVisaDebit(table, tableDesc);

        try {
            for (int i = 1; i <= tblRows.size(); i++) {
                int flag = 0;
                tblCells1 = tblRows.get(i).getCells();
                if (tblRows.get(i).getCells().get(0).getText().equals(latestVisaDebit)) {
                    for (int x = 0; x <= tblCells1.size() - 1; x++) {
                        String column1 = CISALPHelper.stripStringWithSpecialCharacters(tblRows.get(0).getCells().get(x).getText()).toLowerCase() + rowCounter;
                        String value1 = tblCells1.get(x).getText();
                        if (column1.length() > 1) {
                            Log.debug("UI Column: " + column1 + " was added with value: " + value1);
                            tableContent.put(column1, value1);
                        }
                        flag = 1;
                    }
                }
                if (flag == 1) {
                    rowCounter++;
                    if (rowCounter == rows - 1) {
                        break;
                    }
                }
            }
        } catch (Exception e) {
            //place holder
        }
        if (rowCounter == 0) {
            Report.reportStatusThenExit("No records found under " + tableDesc + " Table");
        } else {
            tableContent.put("rowscount", String.valueOf(rowCounter));
            tableContent.put("colscount", String.valueOf(tblCells1.size()));
        }
        return tableContent;
    }

    public static String getLatestVisaDebit(Table table, String tableDesc) throws GeneralLeanFtException {
        List<TableRow> tblRows = table.getRows();

        int rows = tblRows.size();
        long temp = 0;
        try {

            for (int i = 1; i <= rows; i++) {
                String visaNumber = tblRows.get(i).getCells().get(0).getText();
                if (!visaNumber.equals("")) {
                    long cardNumber = Long.parseLong(tblRows.get(i).getCells().get(0).getText());
                    if (cardNumber > temp) {
                        temp = cardNumber;
                    }
                }
            }
        } catch (Exception e) {
            //place holder
        }
        Log.debug("Latest card number:" + temp);
        return String.valueOf(temp);

    }


    public static String getTranslationFromLanguageMap(String language, String term) {
        if (language.toLowerCase().equals("english")) {
            return term;
        } else {
            return CoreFrameworkHelper.getValuesFromProperties("languagemap.properties", term);
        }
    }


    //    /* -- Get Objects --*/

    private Table getVisaNumbersTable() {
        return GetObjectWeb.getTableObject(mainPage, new TableDescription.Builder()
                .tagName("TABLE").innerText(new RegExpProperty(".*Visa Debit NumberStatusExpiry.*|.*Numéro de carte Visa DébitÉtat.*")).index(2).build());
    }
}
