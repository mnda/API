package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.web.*;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class VisaDebitInquiryDialogsPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public VisaDebitInquiryDialogsPage() {
        mainPage = getDialogPage();
        waitUntilVisible();
    }

    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing VisaDebitInquiryDialogsPage...");
        //SyncHelperWeb.waitForElementToAppear(getVisaDebitCardNumberEditField());
        Log.debug("VisaDebitInquiryDialogsPage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        VisaDebitInquiryDialogsPage visaDebitInquiryDialogsPage = new VisaDebitInquiryDialogsPage();
        visaDebitInquiryDialogsPage.enterClientNumber("client", "1234");
        CoreFrameworkWeb.cleanupSDK();
    }

    public void enterClientNumber(String numberType, String number) throws GeneralLeanFtException {
        CoreFrameworkWeb.click(getClearButtonImage());
        if (numberType.toLowerCase().contains("client")) {
            CoreFrameworkWeb.set(getClientCardNumberEditField(), number);
        } else {
            CoreFrameworkWeb.set(getVisaDebitCardNumberEditField(), number);
        }
        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }


    //    /* -- Get Objects --*/

    private Image getClearButtonImage() {
        return GetObjectWeb.getImageObject(mainPage, new ImageDescription.Builder()
                .alt(new RegExpProperty("Clear Button|Bouton Effacer")).type(ImageType.LINK).tagName("IMG").build());
    }

    private EditField getVisaDebitCardNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("visaDebitCardNumber").build());
    }

    private EditField getClientCardNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("clientCardNumber").build());
    }

    private WebElement getCardErroWebElement() {
        return GetObjectWeb.getWebElementObject(mainPage, new WebElementDescription.Builder()
                .tagName("H2").innerText("CIS101E - Invalid Card Entered").build());
    }

}
