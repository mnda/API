package cis.common.library.pages;


import cis.common.library.BasePageWeb;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.EditField;
import com.hp.lft.sdk.web.EditFieldDescription;
import com.hp.lft.sdk.web.RadioGroup;
import com.hp.lft.sdk.web.RadioGroupDescription;
import pcb.auto.pom.core.helper.Log;
import pcb.auto.pom.core.helper.SyncHelperWeb;
import pcb.auto.pom.core.web.CoreFrameworkWeb;
import pcb.auto.pom.core.web.GetObjectWeb;


/**
 * Created by angmark on 5/25/2017.
 */
public class MobileDebitInquiryPage extends BasePageWeb {

    /**
     * Ensures page has loaded before
     *
     * @throws GeneralLeanFtException
     * @throws InterruptedException
     */
    public MobileDebitInquiryPage() throws GeneralLeanFtException, InterruptedException {
        mainPage = getMainPage();
        waitUntilVisible();
    }


    @Override
    protected void waitUntilVisible() {
        Log.debug("Initializing MobileDebitInquiryPage...");
        SyncHelperWeb.waitForElementToAppear(getDisplayCardNumberEditField());
        Log.debug("MobileDebitInquiryPage successfully initialized");
    }


    public static void main(String[] args) throws Exception {
        CoreFrameworkWeb.instantiateSDK();
        CoreFrameworkWeb.cleanupSDK();
    }


    public void searchCardNumber(String cardNumber, String printIndicator) throws GeneralLeanFtException {
        CoreFrameworkWeb.set(getDisplayCardNumberEditField(), cardNumber);
        if (!printIndicator.toLowerCase().contains("na")) {
            if (printIndicator.toLowerCase().contains("yes")) {
                CoreFrameworkWeb.set(getPrintIndicatorRadioGroup(), 0);
            } else {
                CoreFrameworkWeb.set(getPrintIndicatorRadioGroup(), 1);
            }
        }

        CoreFrameworkWeb.click(getSubmitButton(mainPage));
    }

    //    /* -- Get Objects --*/

    private EditField getDisplayCardNumberEditField() {
        return GetObjectWeb.getEditFieldObject(mainPage, new EditFieldDescription.Builder()
                .type("text").tagName("INPUT").name("displayCardNumber").build());
    }

    private RadioGroup getPrintIndicatorRadioGroup() {
        return GetObjectWeb.getRadioGroupObject(getMainPage(), new RadioGroupDescription.Builder()
                .tagName("INPUT").name("printIndicator").build());
    }

}
